using System.Windows.Forms;

namespace InvAcc.Controls
{
    public partial class OrderStatusConrtol : UserControl
    {
        public OrderStatusConrtol()
        {
            InitializeComponent();//
        }
    }
}
