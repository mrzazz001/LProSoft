﻿using System;

namespace InvAcc.Controls
{
    public partial class XtraSchedulerReport1 : DevExpress.XtraScheduler.Reporting.XtraSchedulerReport
    {
        public XtraSchedulerReport1()
        {
            InitializeComponent();
        }
    }
}
