namespace InvAcc
{
    partial class toolbar
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        ///
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(toolbar));
            this.panelControl1 = new System.Windows.Forms.Panel();
            this.BTN_PREV = new DevComponents.DotNetBar.ButtonX();
            this.BTN_FIRST = new DevComponents.DotNetBar.ButtonX();
            this.panelControl3 = new System.Windows.Forms.Panel();
          
            this.labelControl3 = new   DevComponents.DotNetBar.LabelX();
            this.labelControl1 = new   DevComponents.DotNetBar.LabelX();
            this.lbl_DisplayRecord = new   DevComponents.DotNetBar.LabelX();
            this.panelControl2 = new System.Windows.Forms.Panel();
            this.BTN_NEXT = new DevComponents.DotNetBar.ButtonX();
            this.BTN_LAST = new DevComponents.DotNetBar.ButtonX();
            this.panelControl4 = new System.Windows.Forms.Panel();
            this.BTN_DELETE = new DevComponents.DotNetBar.ButtonX();
            this.BTN_SAVE = new DevComponents.DotNetBar.ButtonX();
            this.BTN_NEW = new DevComponents.DotNetBar.ButtonX();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).BeginInit();
            this.panelControl4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.BTN_PREV);
            this.panelControl1.Controls.Add(this.BTN_FIRST);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelControl1.Location = new System.Drawing.Point(652, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(106, 52);
            this.panelControl1.TabIndex = 19;
            // 
            // BTN_PREV
            // 
            //this.BTN_PREV.BackColor = System.Drawing.Color.Transparent;
            //this.BTN_PREV.BackColor2 = System.Drawing.Color.Transparent;
            //this.BTN_PREV.BorderColor = System.Drawing.Color.Transparent;
            //this.BTN_PREV.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            //this.BTN_PREV.ForeColor = System.Drawing.SystemColors.ButtonFace;
            //this.BTN_PREV.Options.UseBackColor = true;
            //this.BTN_PREV.Options.UseBorderColor = true;
            //this.BTN_PREV.Options.UseFont = true;
            //this.BTN_PREV.Options.UseForeColor = true;
            //this.BTN_PREV.AppearanceDisabled.BorderColor = System.Drawing.Color.Silver;
            //this.BTN_PREV.AppearanceDisabled.Options.UseBorderColor = true;
            //this.BTN_PREV.AppearanceHovered.BackColor = System.Drawing.Color.Gold;
            //this.BTN_PREV.AppearanceHovered.BorderColor = System.Drawing.Color.Transparent;
            //this.BTN_PREV.AppearanceHovered.Options.UseBackColor = true;
            //this.BTN_PREV.AppearanceHovered.Options.UseBorderColor = true;
            //this.BTN_PREV.AppearancePressed.BackColor = System.Drawing.Color.Orange;
            //this.BTN_PREV.AppearancePressed.BorderColor = System.Drawing.Color.Transparent;
            //this.BTN_PREV.AppearancePressed.Options.UseBackColor = true;
            //this.BTN_PREV.AppearancePressed.Options.UseBorderColor = true;
            this.BTN_PREV.Dock = System.Windows.Forms.DockStyle.Right;
            this.BTN_PREV.Location = new System.Drawing.Point(2, 2);
            this.BTN_PREV.Name = "BTN_PREV";
            this.BTN_PREV.Size = new System.Drawing.Size(48, 48);
            this.BTN_PREV.TabIndex = 11;
            this.BTN_PREV.Text = "السابق";
            this.BTN_PREV.Click += new System.EventHandler(this.BTN_PREV_Click);
            // 
            // BTN_FIRST
            // 
            this.BTN_FIRST.BackColor = System.Drawing.Color.Transparent;
            this.BTN_FIRST.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.BTN_FIRST.ForeColor = System.Drawing.Color.Azure;
        
            this.BTN_FIRST.Dock = System.Windows.Forms.DockStyle.Right;
            this.BTN_FIRST.Location = new System.Drawing.Point(50, 2);
            this.BTN_FIRST.Name = "BTN_FIRST";
            this.BTN_FIRST.Size = new System.Drawing.Size(54, 48);
            this.BTN_FIRST.TabIndex = 12;
            this.BTN_FIRST.Text = "الأول";
            this.BTN_FIRST.Click += new System.EventHandler(this.BTN_FIRST_Click);
            // 
            // panelControl3
            // 
            this.panelControl3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(235)))), ((int)(((byte)(247)))));
            this.panelControl3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
        //    this.panelControl3.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.panelControl3.Controls.Add(this.labelControl3);
            this.panelControl3.Controls.Add(this.labelControl1);
            this.panelControl3.Controls.Add(this.lbl_DisplayRecord);
            this.panelControl3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelControl3.Location = new System.Drawing.Point(559, 0);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(93, 52);
            this.panelControl3.TabIndex = 20;
            this.panelControl3.Paint += new System.Windows.Forms.PaintEventHandler(this.panelControl3_Paint_1);
            // 
            // labelControl3
            // 
            this.labelControl3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
           // this.labelControl3.Options.UseFont = true;
            this.labelControl3.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl3.Location = new System.Drawing.Point(0, 13);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(3, 13);
            this.labelControl3.TabIndex = 8;
            this.labelControl3.Text = " ";
            // 
            // labelControl1
            // 
            this.labelControl1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
          //  this.labelControl1.Options.UseFont = true;
            this.labelControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl1.Location = new System.Drawing.Point(0, 0);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(3, 13);
            this.labelControl1.TabIndex = 6;
            this.labelControl1.Text = " ";
            // 
            // lbl_DisplayRecord
            // 
         
            this.lbl_DisplayRecord.Location = new System.Drawing.Point(2, 13);
            this.lbl_DisplayRecord.Name = "lbl_DisplayRecord";
            this.lbl_DisplayRecord.Size = new System.Drawing.Size(85, 24);
            this.lbl_DisplayRecord.TabIndex = 7;
            this.lbl_DisplayRecord.Click += new System.EventHandler(this.lbl_DisplayRecord_Click);
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.BTN_NEXT);
            this.panelControl2.Controls.Add(this.BTN_LAST);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelControl2.Location = new System.Drawing.Point(469, 0);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(90, 52);
            this.panelControl2.TabIndex = 21;
            // 
            // BTN_NEXT
            // 
            this.BTN_NEXT.BackColor = System.Drawing.Color.Transparent;
            this.BTN_NEXT.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.BTN_NEXT.ForeColor = System.Drawing.SystemColors.ButtonFace;
             this.BTN_NEXT.Dock = System.Windows.Forms.DockStyle.Right;
            this.BTN_NEXT.Location = new System.Drawing.Point(48, 2);
            this.BTN_NEXT.Name = "BTN_NEXT";
            this.BTN_NEXT.Size = new System.Drawing.Size(40, 48);
            this.BTN_NEXT.TabIndex = 16;
            this.BTN_NEXT.Text = "التالي";
            this.BTN_NEXT.Click += new System.EventHandler(this.BTN_NEXT_Click);
            // 
            // BTN_LAST
            // 
            this.BTN_LAST.BackColor = System.Drawing.Color.Transparent;
            this.BTN_LAST.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.BTN_LAST.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BTN_LAST.Dock = System.Windows.Forms.DockStyle.Left;
            this.BTN_LAST.Location = new System.Drawing.Point(2, 2);
            this.BTN_LAST.Name = "BTN_LAST";
            this.BTN_LAST.Size = new System.Drawing.Size(49, 48);
            this.BTN_LAST.TabIndex = 15;
            this.BTN_LAST.Text = "الأخير";
            this.BTN_LAST.Click += new System.EventHandler(this.BTN_LAST_Click);
            // 
            // panelControl4
            // 
            this.panelControl4.Controls.Add(this.BTN_DELETE);
            this.panelControl4.Controls.Add(this.BTN_SAVE);
            this.panelControl4.Controls.Add(this.BTN_NEW);
            this.panelControl4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelControl4.Location = new System.Drawing.Point(0, 0);
            this.panelControl4.Name = "panelControl4";
            this.panelControl4.Size = new System.Drawing.Size(131, 52);
            this.panelControl4.TabIndex = 17;
            this.panelControl4.Paint += new System.Windows.Forms.PaintEventHandler(this.panelControl4_Paint);
            // 
            // BTN_DELETE
            // 
            this.BTN_DELETE.BackColor = System.Drawing.Color.Transparent;
            this.BTN_DELETE.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.BTN_DELETE.ForeColor = System.Drawing.SystemColors.ButtonFace;
             this.BTN_DELETE.Dock = System.Windows.Forms.DockStyle.Left;
            this.BTN_DELETE.Location = new System.Drawing.Point(44, 2);
            this.BTN_DELETE.Name = "BTN_DELETE";
            this.BTN_DELETE.Size = new System.Drawing.Size(42, 48);
            this.BTN_DELETE.TabIndex = 20;
            this.BTN_DELETE.Text = "حذف";
            this.BTN_DELETE.Click += new System.EventHandler(this.BTN_DELETE_Click_1);
            // 
            // BTN_SAVE
            // 
            this.BTN_SAVE.BackColor = System.Drawing.Color.Transparent;
            this.BTN_SAVE.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.BTN_SAVE.ForeColor = System.Drawing.SystemColors.ButtonFace;
             this.BTN_SAVE.Dock = System.Windows.Forms.DockStyle.Left;
            this.BTN_SAVE.Name = "BTN_SAVE";
            this.BTN_SAVE.Size = new System.Drawing.Size(42, 48);
            this.BTN_SAVE.TabIndex = 19;
            this.BTN_SAVE.Text = "حفظ";
            this.BTN_SAVE.Click += new System.EventHandler(this.BTN_SAVE_Click_1);
            // 
            // BTN_NEW
            // 
            this.BTN_NEW.BackColor = System.Drawing.Color.Transparent;
            this.BTN_NEW.Font = new System.Drawing.Font("Tahoma", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.BTN_NEW.ForeColor = System.Drawing.SystemColors.ButtonFace;
           this.BTN_NEW.Dock = System.Windows.Forms.DockStyle.Right;
            this.BTN_NEW.Location = new System.Drawing.Point(87, 2);
           this.BTN_NEW.Name = "BTN_NEW";
            this.BTN_NEW.Size = new System.Drawing.Size(42, 48);
            this.BTN_NEW.TabIndex = 18;
            this.BTN_NEW.Text = "اضافة";
            this.BTN_NEW.Click += new System.EventHandler(this.BTN_NEW_Click_1);
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(131, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(338, 52);
            this.panel1.TabIndex = 22;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // toolbar
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(235)))), ((int)(((byte)(247)))));
         //   this.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelControl4);
            this.Controls.Add(this.panelControl2);
            this.Controls.Add(this.panelControl3);
            this.Controls.Add(this.panelControl1);
            this.Name = "toolbar";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Size = new System.Drawing.Size(758, 52);
            this.Load += new System.EventHandler(this.toolbar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).EndInit();
            this.panelControl4.ResumeLayout(false);
        //    this.Icon = ((System.Drawing.Icon)(InvAcc.Properties.Resources.favicon));
this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.ButtonX BTN_PREV;
        private DevComponents.DotNetBar.ButtonX BTN_FIRST;
        private DevComponents.DotNetBar.ButtonX BTN_NEXT;
        private DevComponents.DotNetBar.ButtonX BTN_LAST;
        private System.Windows.Forms.Panel panelControl1;
        private System.Windows.Forms.Panel panelControl3;
        private   DevComponents.DotNetBar.LabelX labelControl3;
        private   DevComponents.DotNetBar.LabelX lbl_DisplayRecord;
        private   DevComponents.DotNetBar.LabelX labelControl1;
        private System.Windows.Forms.Panel panelControl2;
        private System.Windows.Forms.Panel panelControl4;
        private DevComponents.DotNetBar.ButtonX BTN_DELETE;
        private DevComponents.DotNetBar.ButtonX BTN_SAVE;
        private DevComponents.DotNetBar.ButtonX BTN_NEW;
        private System.Windows.Forms.Panel panel1;
    }
}
