﻿namespace InvAcc.Controls
{
    public class FirmenDatenContext
    {
    }
}