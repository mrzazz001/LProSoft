﻿namespace InvAcc.Controls.POS
{
    partial class POS_ItemsGride
    {

        #region Component Designer generated code

        #endregion
        private System.Windows.Forms.TableLayoutPanel ItemsGride;
#pragma warning disable CS0169 // The field 'POS_ItemsGride.arrowButton2' is never used
        private ArrowButton.ArrowButton arrowButton2;
#pragma warning restore CS0169 // The field 'POS_ItemsGride.arrowButton2' is never used
#pragma warning disable CS0169 // The field 'POS_ItemsGride.arrowButton1' is never used
        private ArrowButton.ArrowButton arrowButton1;
#pragma warning restore CS0169 // The field 'POS_ItemsGride.arrowButton1' is never used
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button But_Back;
    }
}
