﻿namespace InvAcc.Controls.POS
{
    partial class POS_ItemsGride
    {

        #region Component Designer generated code

        #endregion
        private System.Windows.Forms.TableLayoutPanel ItemGried;
        private ArrowButton.ArrowButton arrowButton2;
        private ArrowButton.ArrowButton arrowButton1;
        private System.Windows.Forms.Panel panel2;
    }
}
