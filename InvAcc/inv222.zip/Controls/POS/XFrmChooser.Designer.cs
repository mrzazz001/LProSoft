﻿namespace InvAcc.Controls.POS
{
    partial class Xfrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraEditors.TileItemElement tileItemElement5 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement4 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement3 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement2 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement1 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.Utils.ContextButton contextButton2 = new DevExpress.Utils.ContextButton();
            DevExpress.Utils.ContextButton contextButton1 = new DevExpress.Utils.ContextButton();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.navigationPage2 = new DevExpress.XtraBars.Navigation.NavigationPage();
            this.navigationFrame1 = new DevExpress.XtraBars.Navigation.NavigationFrame();
            this.navigationPage1 = new DevExpress.XtraBars.Navigation.NavigationPage();
            this.tileBarItem6 = new DevExpress.XtraBars.Navigation.TileBarItem();
            this.tileBarItem5 = new DevExpress.XtraBars.Navigation.TileBarItem();
            this.tileBarItem4 = new DevExpress.XtraBars.Navigation.TileBarItem();
            this.tileBarItem3 = new DevExpress.XtraBars.Navigation.TileBarItem();
            this.tileBarItem2 = new DevExpress.XtraBars.Navigation.TileBarItem();
            this.tileBarGroup1 = new DevExpress.XtraBars.Navigation.TileBarGroup();
            this.tileBar2 = new DevExpress.XtraBars.Navigation.TileBar();
            this.navigationPage3 = new DevExpress.XtraBars.Navigation.NavigationPage();
            this.navigationPage4 = new DevExpress.XtraBars.Navigation.NavigationPage();
            this.navigationPage5 = new DevExpress.XtraBars.Navigation.NavigationPage();
            this.tileBar1 = new DevExpress.XtraBars.Navigation.TileBar();
            this.tileBarGroup2 = new DevExpress.XtraBars.Navigation.TileBarGroup();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.navigationFrame1)).BeginInit();
            this.navigationFrame1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.navigationFrame1);
            this.panelControl1.Controls.Add(this.tileBar1);
            this.panelControl1.Controls.Add(this.tileBar2);
            this.panelControl1.Location = new System.Drawing.Point(-1, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.panelControl1.Size = new System.Drawing.Size(881, 430);
            this.panelControl1.TabIndex = 0;
            // 
            // navigationPage2
            // 
            this.navigationPage2.Name = "navigationPage2";
            this.navigationPage2.Size = new System.Drawing.Size(621, 316);
            // 
            // navigationFrame1
            // 
            this.navigationFrame1.Controls.Add(this.navigationPage2);
            this.navigationFrame1.Controls.Add(this.navigationPage3);
            this.navigationFrame1.Controls.Add(this.navigationPage4);
            this.navigationFrame1.Controls.Add(this.navigationPage5);
            this.navigationFrame1.Controls.Add(this.navigationPage1);
            this.navigationFrame1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.navigationFrame1.Location = new System.Drawing.Point(2, 112);
            this.navigationFrame1.Name = "navigationFrame1";
            this.navigationFrame1.Pages.AddRange(new DevExpress.XtraBars.Navigation.NavigationPageBase[] {
            this.navigationPage1,
            this.navigationPage2,
            this.navigationPage3,
            this.navigationPage4,
            this.navigationPage5});
            this.navigationFrame1.SelectedPage = this.navigationPage1;
            this.navigationFrame1.Size = new System.Drawing.Size(621, 316);
            this.navigationFrame1.TabIndex = 47;
            this.navigationFrame1.Text = "navigationFrame1";
            // 
            // navigationPage1
            // 
            this.navigationPage1.Name = "navigationPage1";
            this.navigationPage1.Size = new System.Drawing.Size(621, 316);
            this.navigationPage1.Paint += new System.Windows.Forms.PaintEventHandler(this.navigationPage1_Paint);
            // 
            // tileBarItem6
            // 
            this.tileBarItem6.DropDownOptions.BeakColor = System.Drawing.Color.Empty;
            tileItemElement5.Text = "الوحدة الخامسة";
            this.tileBarItem6.Elements.Add(tileItemElement5);
            this.tileBarItem6.Id = 7;
            this.tileBarItem6.ItemSize = DevExpress.XtraBars.Navigation.TileBarItemSize.Wide;
            this.tileBarItem6.Name = "tileBarItem6";
            this.tileBarItem6.Tag = "5";
            // 
            // tileBarItem5
            // 
            this.tileBarItem5.DropDownOptions.BeakColor = System.Drawing.Color.Empty;
            tileItemElement4.Text = "الوحدة الرابعه";
            this.tileBarItem5.Elements.Add(tileItemElement4);
            this.tileBarItem5.Id = 6;
            this.tileBarItem5.ItemSize = DevExpress.XtraBars.Navigation.TileBarItemSize.Wide;
            this.tileBarItem5.Name = "tileBarItem5";
            this.tileBarItem5.Tag = "4";
            // 
            // tileBarItem4
            // 
            this.tileBarItem4.DropDownOptions.BeakColor = System.Drawing.Color.Empty;
            tileItemElement3.Text = "الوحدة الثالثه";
            this.tileBarItem4.Elements.Add(tileItemElement3);
            this.tileBarItem4.Id = 5;
            this.tileBarItem4.ItemSize = DevExpress.XtraBars.Navigation.TileBarItemSize.Wide;
            this.tileBarItem4.Name = "tileBarItem4";
            this.tileBarItem4.Tag = "3";
            // 
            // tileBarItem3
            // 
            this.tileBarItem3.DropDownOptions.BeakColor = System.Drawing.Color.Empty;
            tileItemElement2.Text = "الوحدة الثانية";
            this.tileBarItem3.Elements.Add(tileItemElement2);
            this.tileBarItem3.Id = 4;
            this.tileBarItem3.ItemSize = DevExpress.XtraBars.Navigation.TileBarItemSize.Wide;
            this.tileBarItem3.Name = "tileBarItem3";
            this.tileBarItem3.Tag = "2";
            // 
            // tileBarItem2
            // 
            this.tileBarItem2.AppearanceItem.Selected.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.tileBarItem2.AppearanceItem.Selected.Options.UseBackColor = true;
            this.tileBarItem2.DropDownOptions.BeakColor = System.Drawing.Color.Empty;
            tileItemElement1.Text = "الوحدة الاولى";
            this.tileBarItem2.Elements.Add(tileItemElement1);
            this.tileBarItem2.Id = 3;
            this.tileBarItem2.ItemSize = DevExpress.XtraBars.Navigation.TileBarItemSize.Wide;
            this.tileBarItem2.Name = "tileBarItem2";
            this.tileBarItem2.Tag = "1";
            // 
            // tileBarGroup1
            // 
            this.tileBarGroup1.Items.Add(this.tileBarItem2);
            this.tileBarGroup1.Items.Add(this.tileBarItem3);
            this.tileBarGroup1.Items.Add(this.tileBarItem4);
            this.tileBarGroup1.Items.Add(this.tileBarItem5);
            this.tileBarGroup1.Items.Add(this.tileBarItem6);
            this.tileBarGroup1.Name = "tileBarGroup1";
            // 
            // tileBar2
            // 
            this.tileBar2.BackColor = System.Drawing.Color.Gray;
            contextButton2.Id = new System.Guid("9229176d-3366-4e65-adba-10e80c70acd9");
            contextButton2.ImageOptionsCollection.ItemNormal.UseDefaultImage = true;
            contextButton2.Name = "contextButton1";
            this.tileBar2.ContextButtons.Add(contextButton2);
            this.tileBar2.Dock = System.Windows.Forms.DockStyle.Right;
            this.tileBar2.DropDownOptions.BeakColor = System.Drawing.Color.Empty;
            this.tileBar2.Groups.Add(this.tileBarGroup1);
            this.tileBar2.HorizontalContentAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tileBar2.Location = new System.Drawing.Point(623, 2);
            this.tileBar2.MaxId = 8;
            this.tileBar2.Name = "tileBar2";
            this.tileBar2.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tileBar2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tileBar2.ScrollMode = DevExpress.XtraEditors.TileControlScrollMode.ScrollButtons;
            this.tileBar2.Size = new System.Drawing.Size(256, 426);
            this.tileBar2.TabIndex = 46;
            this.tileBar2.Text = "tileBar2";
            this.tileBar2.VerticalContentAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tileBar2.ItemClick += new DevExpress.XtraEditors.TileItemClickEventHandler(this.tileBar2_ItemClick);
            // 
            // navigationPage3
            // 
            this.navigationPage3.Name = "navigationPage3";
            this.navigationPage3.Size = new System.Drawing.Size(621, 316);
            // 
            // navigationPage4
            // 
            this.navigationPage4.Name = "navigationPage4";
            this.navigationPage4.Size = new System.Drawing.Size(621, 316);
            // 
            // navigationPage5
            // 
            this.navigationPage5.Name = "navigationPage5";
            this.navigationPage5.Size = new System.Drawing.Size(621, 316);
            // 
            // tileBar1
            // 
            this.tileBar1.BackColor = System.Drawing.Color.Gray;
            contextButton1.Id = new System.Guid("9229176d-3366-4e65-adba-10e80c70acd9");
            contextButton1.ImageOptionsCollection.ItemNormal.UseDefaultImage = true;
            contextButton1.Name = "contextButton1";
            this.tileBar1.ContextButtons.Add(contextButton1);
            this.tileBar1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tileBar1.DropDownOptions.BeakColor = System.Drawing.Color.Empty;
            this.tileBar1.Groups.Add(this.tileBarGroup2);
            this.tileBar1.HorizontalContentAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tileBar1.Location = new System.Drawing.Point(2, 2);
            this.tileBar1.MaxId = 4;
            this.tileBar1.Name = "tileBar1";
            this.tileBar1.ScrollMode = DevExpress.XtraEditors.TileControlScrollMode.ScrollButtons;
            this.tileBar1.Size = new System.Drawing.Size(621, 110);
            this.tileBar1.TabIndex = 50;
            this.tileBar1.Text = "tileBar1";
            this.tileBar1.VerticalContentAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tileBar1.ItemDoubleClick += new DevExpress.XtraEditors.TileItemClickEventHandler(this.tileBar1_ItemDoubleClick);
            this.tileBar1.DoubleClick += new System.EventHandler(this.tileBar1_DoubleClick);
            // 
            // tileBarGroup2
            // 
            this.tileBarGroup2.Name = "tileBarGroup2";
            // 
            // Xfrm
            // 
            this.Appearance.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 430);
            this.Controls.Add(this.panelControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Xfrm";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "X";
            this.Load += new System.EventHandler(this.Xfrm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.navigationFrame1)).EndInit();
            this.navigationFrame1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraBars.Navigation.NavigationFrame navigationFrame1;
        private DevExpress.XtraBars.Navigation.NavigationPage navigationPage1;
        private DevExpress.XtraBars.Navigation.NavigationPage navigationPage2;
        private DevExpress.XtraBars.Navigation.TileBar tileBar2;
        private DevExpress.XtraBars.Navigation.TileBarGroup tileBarGroup1;
        private DevExpress.XtraBars.Navigation.TileBarItem tileBarItem2;
        private DevExpress.XtraBars.Navigation.TileBarItem tileBarItem3;
        private DevExpress.XtraBars.Navigation.TileBarItem tileBarItem4;
        private DevExpress.XtraBars.Navigation.TileBarItem tileBarItem5;
        private DevExpress.XtraBars.Navigation.TileBarItem tileBarItem6;
        private DevExpress.XtraBars.Navigation.NavigationPage navigationPage3;
        private DevExpress.XtraBars.Navigation.NavigationPage navigationPage4;
        private DevExpress.XtraBars.Navigation.NavigationPage navigationPage5;
        private DevExpress.XtraBars.Navigation.TileBar tileBar1;
        private DevExpress.XtraBars.Navigation.TileBarGroup tileBarGroup2;
    }
}