﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

public  class OvalPictureBox : PictureBox
{
    public OvalPictureBox()
    {
        this.BackColor = Color.White;
    }
   
}