using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace InvAcc.Forms
{
    public partial  class Frmsaveoverbills : Form
    { void avs(int arln)

{ 
 Text = "Frmsaveoverbills";this.Text=   (arln == 0 ? "  Frmsaveoverbills  " : "  Frmsaveoverbills") ;}
        private void langloads(object sender, EventArgs e)
        {
             avs(GeneralM.VarGeneral.currentintlanguage);
        }
   
        public Frmsaveoverbills()
        {
            InitializeComponent();this.Load += langloads;
        }
    }
}
