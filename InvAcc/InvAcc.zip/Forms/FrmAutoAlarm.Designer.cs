   

namespace InvAcc.Forms
{
partial class FrmAutoAlarm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
    
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PanelSpecialContainer = new System.Windows.Forms.Panel();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn1 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn2 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn3 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn4 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn5 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn6 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn7 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background1 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background2 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background3 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn8 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn9 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn10 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn11 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn12 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn13 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn14 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background4 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background5 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background6 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn15 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn16 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn17 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn18 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn19 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn20 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn21 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background7 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background8 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background9 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn22 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn23 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn24 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn25 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn26 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn27 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn28 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background10 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background11 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background12 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn29 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn30 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn31 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn32 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn33 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn34 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn35 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background13 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background14 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background15 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn36 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn37 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn38 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn39 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn40 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn41 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn42 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background16 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background17 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background18 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn43 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn44 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn45 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn46 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn47 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn48 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn49 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background19 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background20 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background21 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn50 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn51 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn52 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn53 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn54 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn55 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn56 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background22 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background23 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background24 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn57 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn58 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn59 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn60 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn61 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn62 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn63 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background25 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background26 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background27 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn64 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn65 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn66 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn67 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn68 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn69 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn70 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background28 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background29 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background30 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn71 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn72 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn73 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn74 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn75 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn76 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn77 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background31 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background32 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background33 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn78 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn79 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn80 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn81 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn82 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn83 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn84 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background34 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background35 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background36 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn85 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn86 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn87 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn88 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn89 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn90 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn91 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background37 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background38 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background39 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn92 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn93 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn94 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn95 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn96 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn97 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn98 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background40 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background41 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background42 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn99 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn100 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn101 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn102 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn103 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn104 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn105 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background43 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background44 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background45 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAutoAlarm));
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn106 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn107 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn108 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn109 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn110 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn111 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.GridColumn gridColumn112 = new DevComponents.DotNetBar.SuperGrid.GridColumn();
            DevComponents.DotNetBar.SuperGrid.Style.Background background46 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background47 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background48 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            this.ribbonBar1 = new DevComponents.DotNetBar.RibbonBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl1 = new DevComponents.DotNetBar.TabControl();
            this.tabControlPanel2 = new DevComponents.DotNetBar.TabControlPanel();
            this.tabControl2 = new DevComponents.DotNetBar.TabControl();
            this.tabControlPanel6 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_Id = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_ID = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel10 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_Passport = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_Passport = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel7 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_Allownc = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_EmpAllownce = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel8 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_Forms = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_EmpForms = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel9 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_Lisnese = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_License = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabItem_EmployeeDoc = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel28 = new DevComponents.DotNetBar.TabControlPanel();
            this.tabControl6 = new DevComponents.DotNetBar.TabControl();
            this.tabControlPanel29 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_AllownceDept = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_DeptAllownce = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel32 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_ZakaaDept = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_DeptZakaa = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabItem_DeptDoc = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel23 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_VisaGoBack = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_Visa = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel5 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_EmployeeVac = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_VacDoc = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel22 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_Secretariats = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_Secretariats = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel13 = new DevComponents.DotNetBar.TabControlPanel();
            this.tabControl5 = new DevComponents.DotNetBar.TabControl();
            this.tabControlPanel17 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_CarForms = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_CarForms = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel18 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_CarAllownces = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_CarAllownce = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabItem_CarsDoc = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel4 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_FamilyPassport = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_FamilyDoc = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel3 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_Contract = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_EmployeeContract = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel1 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_BossRecord = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.tabItem_BossDoc = new DevComponents.DotNetBar.TabItem(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSplitButton_Print = new System.Windows.Forms.ToolStripSplitButton();
            this.ToolStripMenuItem_DocEmp = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_PrintEmpID = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_PrintEmpPassport = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_PrintEmpLicense = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_PrintEmpForms = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_PrintEmpAllownce = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_PrintContract = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_PrintVac = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_PrintFamilyPassport = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_BossRecord = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_DeptDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_DeptAllownce = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_DeptZakaa = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_CarDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_CarsForms = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_CarsAllownce = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_SecretariatsDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_VisaGoBack = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton_Close = new System.Windows.Forms.ToolStripButton();
            this.tabControlPanel16 = new DevComponents.DotNetBar.TabControlPanel();
            this.superGridControl_RecordBranch = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.netResize1 = new Softgroup.NetResize.NetResize(this.components);  this.netResize1.LabelsAutoEllipse = false;
            this.netResize1.AfterControlResize += new Softgroup.NetResize.NetResize.AfterControlResizeEventHandler(this.netResize1_AfterControlResize);
            this.Shown += new System.EventHandler(this.FrmInvSale_Shown);
            this.SizeChanged += new System.EventHandler(this.FrmInvSale_SizeChanged);
            ((System.ComponentModel.ISupportInitialize)(this.netResize1)).BeginInit();
            this.ribbonBar1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabControl1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabControlPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabControl2)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.tabControlPanel6.SuspendLayout();
            this.tabControlPanel10.SuspendLayout();
            this.tabControlPanel7.SuspendLayout();
            this.tabControlPanel8.SuspendLayout();
            this.tabControlPanel9.SuspendLayout();
            this.tabControlPanel28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabControl6)).BeginInit();
            this.tabControl6.SuspendLayout();
            this.tabControlPanel29.SuspendLayout();
            this.tabControlPanel32.SuspendLayout();
            this.tabControlPanel23.SuspendLayout();
            this.tabControlPanel5.SuspendLayout();
            this.tabControlPanel22.SuspendLayout();
            this.tabControlPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabControl5)).BeginInit();
            this.tabControl5.SuspendLayout();
            this.tabControlPanel17.SuspendLayout();
            this.tabControlPanel18.SuspendLayout();
            this.tabControlPanel4.SuspendLayout();
            this.tabControlPanel3.SuspendLayout();
            this.tabControlPanel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tabControlPanel16.SuspendLayout();
            this.PanelSpecialContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelSpecialContainer.Location = new System.Drawing.Point(0, 0);
            this.PanelSpecialContainer.Name = "PanelSpecialContainer";
            this.PanelSpecialContainer.Size = new System.Drawing.Size(1278, 514);
            this.PanelSpecialContainer.TabIndex = 1220;
            this.Controls.Add(this.PanelSpecialContainer);
            // 
            // ribbonBar1
            // 
            this.ribbonBar1.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundStyle.BackColor = System.Drawing.Color.AliceBlue;
            this.ribbonBar1.BackgroundStyle.BackColor2 = System.Drawing.SystemColors.GradientActiveCaption;
            this.ribbonBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar1.ContainerControlProcessDialogKey = true;
            this.ribbonBar1.Controls.Add(this.panel1);
            this.ribbonBar1.Controls.Add(this.toolStrip1);
            this.ribbonBar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonBar1.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.ribbonBar1.Location = new System.Drawing.Point(0, 0);
            this.ribbonBar1.Name = "ribbonBar1";
            this.ribbonBar1.Size = new System.Drawing.Size(783, 551);
            this.ribbonBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.OfficeXP;
            this.ribbonBar1.TabIndex = 1104;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.ribbonBar1.TitleStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(147)))), ((int)(((byte)(207)))));
            this.ribbonBar1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(783, 509);
            this.panel1.TabIndex = 1104;
            // 
            // tabControl1
            // 
            this.tabControl1.BackColor = System.Drawing.Color.Transparent;
            this.tabControl1.CanReorderTabs = true;
            this.tabControl1.ColorScheme.TabBackground2 = System.Drawing.Color.Gainsboro;
            this.tabControl1.Controls.Add(this.tabControlPanel2);
            this.tabControl1.Controls.Add(this.tabControlPanel28);
            this.tabControl1.Controls.Add(this.tabControlPanel23);
            this.tabControl1.Controls.Add(this.tabControlPanel5);
            this.tabControl1.Controls.Add(this.tabControlPanel22);
            this.tabControl1.Controls.Add(this.tabControlPanel13);
            this.tabControl1.Controls.Add(this.tabControlPanel4);
            this.tabControl1.Controls.Add(this.tabControlPanel3);
            this.tabControl1.Controls.Add(this.tabControlPanel1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tabControl1.SelectedTabFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.tabControl1.SelectedTabIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(783, 509);
            this.tabControl1.Style = DevComponents.DotNetBar.eTabStripStyle.Metro;
            this.tabControl1.TabIndex = 855;
            this.tabControl1.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.MultilineNoNavigationBox;
            this.tabControl1.Tabs.Add(this.tabItem_EmployeeDoc);
            this.tabControl1.Tabs.Add(this.tabItem_EmployeeContract);
            this.tabControl1.Tabs.Add(this.tabItem_FamilyDoc);
            this.tabControl1.Tabs.Add(this.tabItem_VacDoc);
            this.tabControl1.Tabs.Add(this.tabItem_BossDoc);
            this.tabControl1.Tabs.Add(this.tabItem_CarsDoc);
            this.tabControl1.Tabs.Add(this.tabItem_Secretariats);
            this.tabControl1.Tabs.Add(this.tabItem_Visa);
            this.tabControl1.Tabs.Add(this.tabItem_DeptDoc);
            this.tabControl1.Text = "tabControl1";
            // 
            // tabControlPanel2
            // 
            this.tabControlPanel2.Controls.Add(this.tabControl2);
            this.tabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel2.Location = new System.Drawing.Point(0, 27);
            this.tabControlPanel2.Name = "tabControlPanel2";
            this.tabControlPanel2.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel2.Size = new System.Drawing.Size(783, 482);
            this.tabControlPanel2.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.tabControlPanel2.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(210)))), ((int)(((byte)(255)))));
            this.tabControlPanel2.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel2.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanel2.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel2.Style.GradientAngle = 90;
            this.tabControlPanel2.TabIndex = 2;
            this.tabControlPanel2.TabItem = this.tabItem_EmployeeDoc;
            // 
            // tabControl2
            // 
            this.tabControl2.BackColor = System.Drawing.Color.Transparent;
            this.tabControl2.CanReorderTabs = true;
            this.tabControl2.ColorScheme.TabItemBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(220)))), ((int)(((byte)(244))))), 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(210)))), ((int)(((byte)(254))))), 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(191)))), ((int)(((byte)(243))))), 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(204)))), ((int)(((byte)(233))))), 1F)});
            this.tabControl2.ColorScheme.TabItemHotBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(237)))), ((int)(((byte)(255))))), 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(232)))), ((int)(((byte)(255))))), 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(210)))), ((int)(((byte)(255))))), 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(218)))), ((int)(((byte)(255))))), 1F)});
            this.tabControl2.ColorScheme.TabItemHotText = System.Drawing.Color.Black;
            this.tabControl2.ColorScheme.TabItemSelectedBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(227)))), ((int)(((byte)(217))))), 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(189)))), ((int)(((byte)(116))))), 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(180)))), ((int)(((byte)(89))))), 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), 1F)});
            this.tabControl2.ColorScheme.TabItemSelectedText = System.Drawing.Color.Black;
            this.tabControl2.ColorScheme.TabItemText = System.Drawing.Color.Black;
            this.tabControl2.Controls.Add(this.tabControlPanel6);
            this.tabControl2.Controls.Add(this.tabControlPanel10);
            this.tabControl2.Controls.Add(this.tabControlPanel7);
            this.tabControl2.Controls.Add(this.tabControlPanel8);
            this.tabControl2.Controls.Add(this.tabControlPanel9);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.tabControl2.ForeColor = System.Drawing.Color.White;
            this.tabControl2.Location = new System.Drawing.Point(1, 1);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tabControl2.SelectedTabFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.tabControl2.SelectedTabIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(781, 480);
            this.tabControl2.Style = DevComponents.DotNetBar.eTabStripStyle.RoundHeader;
            this.tabControl2.TabIndex = 852;
            this.tabControl2.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.tabControl2.Tabs.Add(this.tabItem_ID);
            this.tabControl2.Tabs.Add(this.tabItem_Passport);
            this.tabControl2.Tabs.Add(this.tabItem_EmpAllownce);
            this.tabControl2.Tabs.Add(this.tabItem_License);
            this.tabControl2.Tabs.Add(this.tabItem_EmpForms);
            this.tabControl2.Text = "tabControl2";
            // 
            // tabControlPanel6
            // 
            this.tabControlPanel6.Controls.Add(this.superGridControl_Id);
            this.tabControlPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel6.Location = new System.Drawing.Point(0, 25);
            this.tabControlPanel6.Name = "tabControlPanel6";
            this.tabControlPanel6.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel6.Size = new System.Drawing.Size(781, 455);
            this.tabControlPanel6.Style.BackColor1.Color = System.Drawing.Color.White;
            this.tabControlPanel6.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(215)))));
            this.tabControlPanel6.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel6.Style.BorderColor.Color = System.Drawing.SystemColors.ControlDarkDark;
            this.tabControlPanel6.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel6.Style.GradientAngle = 90;
            this.tabControlPanel6.TabIndex = 7;
            this.tabControlPanel6.TabItem = this.tabItem_ID;
            // 
            // superGridControl_Id
            // 
            this.superGridControl_Id.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_Id.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_Id.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_Id.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_Id.HScrollBarVisible = false;
            this.superGridControl_Id.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_Id.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_Id.Name = "superGridControl_Id";
            this.superGridControl_Id.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_Id.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_Id.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_Id.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn1.Name = "";
            gridColumn1.Visible = false;
            gridColumn1.Width = 60;
            gridColumn2.Name = "EndDate";
            gridColumn2.Width = 90;
            gridColumn3.Name = "IssDate";
            gridColumn3.Width = 90;
            gridColumn4.Name = "Place";
            gridColumn4.Width = 120;
            gridColumn5.Name = "No";
            gridColumn5.Width = 120;
            gridColumn6.Name = "EmpName";
            gridColumn6.Width = 260;
            gridColumn7.Name = "EmpNo";
            this.superGridControl_Id.PrimaryGrid.Columns.Add(gridColumn1);
            this.superGridControl_Id.PrimaryGrid.Columns.Add(gridColumn2);
            this.superGridControl_Id.PrimaryGrid.Columns.Add(gridColumn3);
            this.superGridControl_Id.PrimaryGrid.Columns.Add(gridColumn4);
            this.superGridControl_Id.PrimaryGrid.Columns.Add(gridColumn5);
            this.superGridControl_Id.PrimaryGrid.Columns.Add(gridColumn6);
            this.superGridControl_Id.PrimaryGrid.Columns.Add(gridColumn7);
            this.superGridControl_Id.PrimaryGrid.DefaultRowHeight = 24;
            background1.Color1 = System.Drawing.Color.White;
            background1.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Id.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background1;
            background2.Color1 = System.Drawing.Color.White;
            background2.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Id.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background2;
            this.superGridControl_Id.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background3.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background3.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_Id.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background3;
            this.superGridControl_Id.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_Id.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_Id.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_Id.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_Id.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_Id.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_Id.PrimaryGrid.MultiSelect = false;
            this.superGridControl_Id.PrimaryGrid.NullString = "-----";
            this.superGridControl_Id.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_Id.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_Id.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_Id.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_Id.Size = new System.Drawing.Size(779, 453);
            this.superGridControl_Id.TabIndex = 485;
            // 
            // tabItem_ID
            // 
            this.tabItem_ID.AttachedControl = this.tabControlPanel6;
            this.tabItem_ID.Name = "tabItem_ID";
            this.tabItem_ID.Text = "الهويات";
            // 
            // tabControlPanel10
            // 
            this.tabControlPanel10.Controls.Add(this.superGridControl_Passport);
            this.tabControlPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel10.Location = new System.Drawing.Point(0, 25);
            this.tabControlPanel10.Name = "tabControlPanel10";
            this.tabControlPanel10.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel10.Size = new System.Drawing.Size(781, 455);
            this.tabControlPanel10.Style.BackColor1.Color = System.Drawing.Color.White;
            this.tabControlPanel10.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(215)))));
            this.tabControlPanel10.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel10.Style.BorderColor.Color = System.Drawing.SystemColors.ControlDarkDark;
            this.tabControlPanel10.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel10.Style.GradientAngle = 90;
            this.tabControlPanel10.TabIndex = 3;
            this.tabControlPanel10.TabItem = this.tabItem_Passport;
            // 
            // superGridControl_Passport
            // 
            this.superGridControl_Passport.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_Passport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_Passport.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_Passport.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_Passport.HScrollBarVisible = false;
            this.superGridControl_Passport.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_Passport.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_Passport.Name = "superGridControl_Passport";
            this.superGridControl_Passport.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_Passport.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_Passport.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_Passport.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn8.Name = "";
            gridColumn8.Visible = false;
            gridColumn8.Width = 60;
            gridColumn9.Name = "EndDate";
            gridColumn9.Width = 90;
            gridColumn10.Name = "IssDate";
            gridColumn10.Width = 90;
            gridColumn11.Name = "Place";
            gridColumn11.Width = 120;
            gridColumn12.Name = "No";
            gridColumn12.Width = 120;
            gridColumn13.Name = "EmpName";
            gridColumn13.Width = 260;
            gridColumn14.Name = "EmpNo";
            this.superGridControl_Passport.PrimaryGrid.Columns.Add(gridColumn8);
            this.superGridControl_Passport.PrimaryGrid.Columns.Add(gridColumn9);
            this.superGridControl_Passport.PrimaryGrid.Columns.Add(gridColumn10);
            this.superGridControl_Passport.PrimaryGrid.Columns.Add(gridColumn11);
            this.superGridControl_Passport.PrimaryGrid.Columns.Add(gridColumn12);
            this.superGridControl_Passport.PrimaryGrid.Columns.Add(gridColumn13);
            this.superGridControl_Passport.PrimaryGrid.Columns.Add(gridColumn14);
            this.superGridControl_Passport.PrimaryGrid.DefaultRowHeight = 24;
            background4.Color1 = System.Drawing.Color.White;
            background4.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Passport.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background4;
            background5.Color1 = System.Drawing.Color.White;
            background5.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Passport.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background5;
            this.superGridControl_Passport.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background6.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background6.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_Passport.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background6;
            this.superGridControl_Passport.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_Passport.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_Passport.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_Passport.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_Passport.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_Passport.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_Passport.PrimaryGrid.MultiSelect = false;
            this.superGridControl_Passport.PrimaryGrid.NullString = "-----";
            this.superGridControl_Passport.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_Passport.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_Passport.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_Passport.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_Passport.Size = new System.Drawing.Size(779, 453);
            this.superGridControl_Passport.TabIndex = 486;
            // 
            // tabItem_Passport
            // 
            this.tabItem_Passport.AttachedControl = this.tabControlPanel10;
            this.tabItem_Passport.Name = "tabItem_Passport";
            this.tabItem_Passport.Text = "حوازات السفر";
            // 
            // tabControlPanel7
            // 
            this.tabControlPanel7.Controls.Add(this.superGridControl_Allownc);
            this.tabControlPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel7.Location = new System.Drawing.Point(0, 25);
            this.tabControlPanel7.Name = "tabControlPanel7";
            this.tabControlPanel7.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel7.Size = new System.Drawing.Size(781, 455);
            this.tabControlPanel7.Style.BackColor1.Color = System.Drawing.Color.White;
            this.tabControlPanel7.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(215)))));
            this.tabControlPanel7.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel7.Style.BorderColor.Color = System.Drawing.SystemColors.ControlDarkDark;
            this.tabControlPanel7.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel7.Style.GradientAngle = 90;
            this.tabControlPanel7.TabIndex = 6;
            this.tabControlPanel7.TabItem = this.tabItem_EmpAllownce;
            // 
            // superGridControl_Allownc
            // 
            this.superGridControl_Allownc.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_Allownc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_Allownc.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_Allownc.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_Allownc.HScrollBarVisible = false;
            this.superGridControl_Allownc.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_Allownc.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_Allownc.Name = "superGridControl_Allownc";
            this.superGridControl_Allownc.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_Allownc.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_Allownc.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_Allownc.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn15.Name = "";
            gridColumn15.Visible = false;
            gridColumn15.Width = 60;
            gridColumn16.Name = "EndDate";
            gridColumn16.Width = 90;
            gridColumn17.Name = "IssDate";
            gridColumn17.Width = 90;
            gridColumn18.Name = "Place";
            gridColumn18.Width = 120;
            gridColumn19.Name = "No";
            gridColumn19.Width = 120;
            gridColumn20.Name = "EmpName";
            gridColumn20.Width = 260;
            gridColumn21.Name = "EmpNo";
            this.superGridControl_Allownc.PrimaryGrid.Columns.Add(gridColumn15);
            this.superGridControl_Allownc.PrimaryGrid.Columns.Add(gridColumn16);
            this.superGridControl_Allownc.PrimaryGrid.Columns.Add(gridColumn17);
            this.superGridControl_Allownc.PrimaryGrid.Columns.Add(gridColumn18);
            this.superGridControl_Allownc.PrimaryGrid.Columns.Add(gridColumn19);
            this.superGridControl_Allownc.PrimaryGrid.Columns.Add(gridColumn20);
            this.superGridControl_Allownc.PrimaryGrid.Columns.Add(gridColumn21);
            this.superGridControl_Allownc.PrimaryGrid.DefaultRowHeight = 24;
            background7.Color1 = System.Drawing.Color.White;
            background7.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Allownc.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background7;
            background8.Color1 = System.Drawing.Color.White;
            background8.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Allownc.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background8;
            this.superGridControl_Allownc.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background9.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background9.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_Allownc.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background9;
            this.superGridControl_Allownc.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_Allownc.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_Allownc.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_Allownc.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_Allownc.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_Allownc.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_Allownc.PrimaryGrid.MultiSelect = false;
            this.superGridControl_Allownc.PrimaryGrid.NullString = "-----";
            this.superGridControl_Allownc.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_Allownc.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_Allownc.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_Allownc.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_Allownc.Size = new System.Drawing.Size(779, 453);
            this.superGridControl_Allownc.TabIndex = 487;
            // 
            // tabItem_EmpAllownce
            // 
            this.tabItem_EmpAllownce.AttachedControl = this.tabControlPanel7;
            this.tabItem_EmpAllownce.Name = "tabItem_EmpAllownce";
            this.tabItem_EmpAllownce.Text = "التأمينات الصحية";
            // 
            // tabControlPanel8
            // 
            this.tabControlPanel8.Controls.Add(this.superGridControl_Forms);
            this.tabControlPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel8.Location = new System.Drawing.Point(0, 25);
            this.tabControlPanel8.Name = "tabControlPanel8";
            this.tabControlPanel8.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel8.Size = new System.Drawing.Size(781, 455);
            this.tabControlPanel8.Style.BackColor1.Color = System.Drawing.Color.White;
            this.tabControlPanel8.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(215)))));
            this.tabControlPanel8.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel8.Style.BorderColor.Color = System.Drawing.SystemColors.ControlDarkDark;
            this.tabControlPanel8.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel8.Style.GradientAngle = 90;
            this.tabControlPanel8.TabIndex = 5;
            this.tabControlPanel8.TabItem = this.tabItem_EmpForms;
            // 
            // superGridControl_Forms
            // 
            this.superGridControl_Forms.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_Forms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_Forms.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_Forms.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_Forms.HScrollBarVisible = false;
            this.superGridControl_Forms.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_Forms.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_Forms.Name = "superGridControl_Forms";
            this.superGridControl_Forms.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_Forms.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_Forms.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_Forms.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn22.Name = "";
            gridColumn22.Visible = false;
            gridColumn22.Width = 60;
            gridColumn23.Name = "EndDate";
            gridColumn23.Width = 90;
            gridColumn24.Name = "IssDate";
            gridColumn24.Width = 90;
            gridColumn25.Name = "Place";
            gridColumn25.Width = 120;
            gridColumn26.Name = "No";
            gridColumn26.Width = 120;
            gridColumn27.Name = "EmpName";
            gridColumn27.Width = 260;
            gridColumn28.Name = "EmpNo";
            this.superGridControl_Forms.PrimaryGrid.Columns.Add(gridColumn22);
            this.superGridControl_Forms.PrimaryGrid.Columns.Add(gridColumn23);
            this.superGridControl_Forms.PrimaryGrid.Columns.Add(gridColumn24);
            this.superGridControl_Forms.PrimaryGrid.Columns.Add(gridColumn25);
            this.superGridControl_Forms.PrimaryGrid.Columns.Add(gridColumn26);
            this.superGridControl_Forms.PrimaryGrid.Columns.Add(gridColumn27);
            this.superGridControl_Forms.PrimaryGrid.Columns.Add(gridColumn28);
            this.superGridControl_Forms.PrimaryGrid.DefaultRowHeight = 24;
            background10.Color1 = System.Drawing.Color.White;
            background10.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Forms.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background10;
            background11.Color1 = System.Drawing.Color.White;
            background11.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Forms.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background11;
            this.superGridControl_Forms.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background12.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background12.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_Forms.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background12;
            this.superGridControl_Forms.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_Forms.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_Forms.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_Forms.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_Forms.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_Forms.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_Forms.PrimaryGrid.MultiSelect = false;
            this.superGridControl_Forms.PrimaryGrid.NullString = "-----";
            this.superGridControl_Forms.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_Forms.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_Forms.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_Forms.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_Forms.Size = new System.Drawing.Size(779, 453);
            this.superGridControl_Forms.TabIndex = 489;
            // 
            // tabItem_EmpForms
            // 
            this.tabItem_EmpForms.AttachedControl = this.tabControlPanel8;
            this.tabItem_EmpForms.Name = "tabItem_EmpForms";
            this.tabItem_EmpForms.Text = "إستمارات السيارات";
            this.tabItem_EmpForms.Visible = false;
            // 
            // tabControlPanel9
            // 
            this.tabControlPanel9.Controls.Add(this.superGridControl_Lisnese);
            this.tabControlPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel9.Location = new System.Drawing.Point(0, 25);
            this.tabControlPanel9.Name = "tabControlPanel9";
            this.tabControlPanel9.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel9.Size = new System.Drawing.Size(781, 455);
            this.tabControlPanel9.Style.BackColor1.Color = System.Drawing.Color.White;
            this.tabControlPanel9.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(215)))));
            this.tabControlPanel9.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel9.Style.BorderColor.Color = System.Drawing.SystemColors.ControlDarkDark;
            this.tabControlPanel9.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel9.Style.GradientAngle = 90;
            this.tabControlPanel9.TabIndex = 8;
            this.tabControlPanel9.TabItem = this.tabItem_License;
            // 
            // superGridControl_Lisnese
            // 
            this.superGridControl_Lisnese.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_Lisnese.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_Lisnese.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_Lisnese.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_Lisnese.HScrollBarVisible = false;
            this.superGridControl_Lisnese.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_Lisnese.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_Lisnese.Name = "superGridControl_Lisnese";
            this.superGridControl_Lisnese.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_Lisnese.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_Lisnese.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_Lisnese.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn29.Name = "";
            gridColumn29.Visible = false;
            gridColumn29.Width = 60;
            gridColumn30.Name = "EndDate";
            gridColumn30.Width = 90;
            gridColumn31.Name = "IssDate";
            gridColumn31.Width = 90;
            gridColumn32.Name = "Place";
            gridColumn32.Width = 120;
            gridColumn33.Name = "No";
            gridColumn33.Width = 120;
            gridColumn34.Name = "EmpName";
            gridColumn34.Width = 260;
            gridColumn35.Name = "EmpNo";
            this.superGridControl_Lisnese.PrimaryGrid.Columns.Add(gridColumn29);
            this.superGridControl_Lisnese.PrimaryGrid.Columns.Add(gridColumn30);
            this.superGridControl_Lisnese.PrimaryGrid.Columns.Add(gridColumn31);
            this.superGridControl_Lisnese.PrimaryGrid.Columns.Add(gridColumn32);
            this.superGridControl_Lisnese.PrimaryGrid.Columns.Add(gridColumn33);
            this.superGridControl_Lisnese.PrimaryGrid.Columns.Add(gridColumn34);
            this.superGridControl_Lisnese.PrimaryGrid.Columns.Add(gridColumn35);
            this.superGridControl_Lisnese.PrimaryGrid.DefaultRowHeight = 24;
            background13.Color1 = System.Drawing.Color.White;
            background13.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Lisnese.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background13;
            background14.Color1 = System.Drawing.Color.White;
            background14.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Lisnese.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background14;
            this.superGridControl_Lisnese.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background15.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background15.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_Lisnese.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background15;
            this.superGridControl_Lisnese.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_Lisnese.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_Lisnese.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_Lisnese.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_Lisnese.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_Lisnese.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_Lisnese.PrimaryGrid.MultiSelect = false;
            this.superGridControl_Lisnese.PrimaryGrid.NullString = "-----";
            this.superGridControl_Lisnese.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_Lisnese.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_Lisnese.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_Lisnese.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_Lisnese.Size = new System.Drawing.Size(779, 453);
            this.superGridControl_Lisnese.TabIndex = 488;
            // 
            // tabItem_License
            // 
            this.tabItem_License.AttachedControl = this.tabControlPanel9;
            this.tabItem_License.Name = "tabItem_License";
            this.tabItem_License.Text = "رخص القيادة";
            // 
            // tabItem_EmployeeDoc
            // 
            this.tabItem_EmployeeDoc.AttachedControl = this.tabControlPanel2;
            this.tabItem_EmployeeDoc.Name = "tabItem_EmployeeDoc";
            this.tabItem_EmployeeDoc.Text = "وثائق الموظفين";
            // 
            // tabControlPanel28
            // 
            this.tabControlPanel28.Controls.Add(this.tabControl6);
            this.tabControlPanel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel28.Location = new System.Drawing.Point(0, 27);
            this.tabControlPanel28.Name = "tabControlPanel28";
            this.tabControlPanel28.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel28.Size = new System.Drawing.Size(783, 482);
            this.tabControlPanel28.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.tabControlPanel28.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(210)))), ((int)(((byte)(255)))));
            this.tabControlPanel28.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel28.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanel28.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel28.Style.GradientAngle = 90;
            this.tabControlPanel28.TabIndex = 11;
            this.tabControlPanel28.TabItem = this.tabItem_DeptDoc;
            // 
            // tabControl6
            // 
            this.tabControl6.BackColor = System.Drawing.Color.Transparent;
            this.tabControl6.CanReorderTabs = true;
            this.tabControl6.CloseButtonPosition = DevComponents.DotNetBar.eTabCloseButtonPosition.Right;
            this.tabControl6.Controls.Add(this.tabControlPanel29);
            this.tabControl6.Controls.Add(this.tabControlPanel32);
            this.tabControl6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl6.Font = new System.Drawing.Font("Tahoma", 8F);
            this.tabControl6.Location = new System.Drawing.Point(1, 1);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tabControl6.SelectedTabFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.tabControl6.SelectedTabIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(781, 480);
            this.tabControl6.Style = DevComponents.DotNetBar.eTabStripStyle.RoundHeader;
            this.tabControl6.TabIndex = 858;
            this.tabControl6.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.tabControl6.Tabs.Add(this.tabItem_DeptAllownce);
            this.tabControl6.Tabs.Add(this.tabItem_DeptZakaa);
            // 
            // tabControlPanel29
            // 
            this.tabControlPanel29.Controls.Add(this.superGridControl_AllownceDept);
            this.tabControlPanel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel29.Location = new System.Drawing.Point(0, 25);
            this.tabControlPanel29.Name = "tabControlPanel29";
            this.tabControlPanel29.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel29.Size = new System.Drawing.Size(781, 455);
            this.tabControlPanel29.Style.BackColor1.Color = System.Drawing.Color.White;
            this.tabControlPanel29.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(215)))));
            this.tabControlPanel29.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel29.Style.BorderColor.Color = System.Drawing.SystemColors.ControlDarkDark;
            this.tabControlPanel29.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel29.Style.GradientAngle = 90;
            this.tabControlPanel29.TabIndex = 4;
            this.tabControlPanel29.TabItem = this.tabItem_DeptAllownce;
            // 
            // superGridControl_AllownceDept
            // 
            this.superGridControl_AllownceDept.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_AllownceDept.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_AllownceDept.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_AllownceDept.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_AllownceDept.HScrollBarVisible = false;
            this.superGridControl_AllownceDept.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_AllownceDept.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_AllownceDept.Name = "superGridControl_AllownceDept";
            this.superGridControl_AllownceDept.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_AllownceDept.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_AllownceDept.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_AllownceDept.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn36.Name = "";
            gridColumn36.Visible = false;
            gridColumn36.Width = 60;
            gridColumn37.Name = "EndDate";
            gridColumn37.Width = 90;
            gridColumn38.Name = "IssDate";
            gridColumn38.Width = 90;
            gridColumn39.Name = "Place";
            gridColumn39.Width = 120;
            gridColumn40.Name = "No";
            gridColumn40.Width = 120;
            gridColumn41.Name = "EmpName";
            gridColumn41.Width = 260;
            gridColumn42.Name = "EmpNo";
            this.superGridControl_AllownceDept.PrimaryGrid.Columns.Add(gridColumn36);
            this.superGridControl_AllownceDept.PrimaryGrid.Columns.Add(gridColumn37);
            this.superGridControl_AllownceDept.PrimaryGrid.Columns.Add(gridColumn38);
            this.superGridControl_AllownceDept.PrimaryGrid.Columns.Add(gridColumn39);
            this.superGridControl_AllownceDept.PrimaryGrid.Columns.Add(gridColumn40);
            this.superGridControl_AllownceDept.PrimaryGrid.Columns.Add(gridColumn41);
            this.superGridControl_AllownceDept.PrimaryGrid.Columns.Add(gridColumn42);
            this.superGridControl_AllownceDept.PrimaryGrid.DefaultRowHeight = 24;
            background16.Color1 = System.Drawing.Color.White;
            background16.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_AllownceDept.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background16;
            background17.Color1 = System.Drawing.Color.White;
            background17.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_AllownceDept.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background17;
            this.superGridControl_AllownceDept.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background18.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background18.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_AllownceDept.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background18;
            this.superGridControl_AllownceDept.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_AllownceDept.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_AllownceDept.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_AllownceDept.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_AllownceDept.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_AllownceDept.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_AllownceDept.PrimaryGrid.MultiSelect = false;
            this.superGridControl_AllownceDept.PrimaryGrid.NullString = "-----";
            this.superGridControl_AllownceDept.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_AllownceDept.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_AllownceDept.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_AllownceDept.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_AllownceDept.Size = new System.Drawing.Size(779, 453);
            this.superGridControl_AllownceDept.TabIndex = 494;
            // 
            // tabItem_DeptAllownce
            // 
            this.tabItem_DeptAllownce.AttachedControl = this.tabControlPanel29;
            this.tabItem_DeptAllownce.Name = "tabItem_DeptAllownce";
            this.tabItem_DeptAllownce.Text = "التأمينات الإجتماعية";
            // 
            // tabControlPanel32
            // 
            this.tabControlPanel32.Controls.Add(this.superGridControl_ZakaaDept);
            this.tabControlPanel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel32.Location = new System.Drawing.Point(0, 25);
            this.tabControlPanel32.Name = "tabControlPanel32";
            this.tabControlPanel32.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel32.Size = new System.Drawing.Size(781, 455);
            this.tabControlPanel32.Style.BackColor1.Color = System.Drawing.Color.White;
            this.tabControlPanel32.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(215)))));
            this.tabControlPanel32.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel32.Style.BorderColor.Color = System.Drawing.SystemColors.ControlDarkDark;
            this.tabControlPanel32.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel32.Style.GradientAngle = 90;
            this.tabControlPanel32.TabIndex = 3;
            this.tabControlPanel32.TabItem = this.tabItem_DeptZakaa;
            // 
            // superGridControl_ZakaaDept
            // 
            this.superGridControl_ZakaaDept.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_ZakaaDept.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_ZakaaDept.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_ZakaaDept.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_ZakaaDept.HScrollBarVisible = false;
            this.superGridControl_ZakaaDept.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_ZakaaDept.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_ZakaaDept.Name = "superGridControl_ZakaaDept";
            this.superGridControl_ZakaaDept.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_ZakaaDept.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_ZakaaDept.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_ZakaaDept.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn43.Name = "";
            gridColumn43.Visible = false;
            gridColumn43.Width = 60;
            gridColumn44.Name = "EndDate";
            gridColumn44.Width = 90;
            gridColumn45.Name = "IssDate";
            gridColumn45.Width = 90;
            gridColumn46.Name = "Place";
            gridColumn46.Width = 120;
            gridColumn47.Name = "No";
            gridColumn47.Width = 120;
            gridColumn48.Name = "EmpName";
            gridColumn48.Width = 260;
            gridColumn49.Name = "EmpNo";
            this.superGridControl_ZakaaDept.PrimaryGrid.Columns.Add(gridColumn43);
            this.superGridControl_ZakaaDept.PrimaryGrid.Columns.Add(gridColumn44);
            this.superGridControl_ZakaaDept.PrimaryGrid.Columns.Add(gridColumn45);
            this.superGridControl_ZakaaDept.PrimaryGrid.Columns.Add(gridColumn46);
            this.superGridControl_ZakaaDept.PrimaryGrid.Columns.Add(gridColumn47);
            this.superGridControl_ZakaaDept.PrimaryGrid.Columns.Add(gridColumn48);
            this.superGridControl_ZakaaDept.PrimaryGrid.Columns.Add(gridColumn49);
            this.superGridControl_ZakaaDept.PrimaryGrid.DefaultRowHeight = 24;
            background19.Color1 = System.Drawing.Color.White;
            background19.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_ZakaaDept.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background19;
            background20.Color1 = System.Drawing.Color.White;
            background20.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_ZakaaDept.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background20;
            this.superGridControl_ZakaaDept.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background21.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background21.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_ZakaaDept.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background21;
            this.superGridControl_ZakaaDept.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_ZakaaDept.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_ZakaaDept.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_ZakaaDept.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_ZakaaDept.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_ZakaaDept.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_ZakaaDept.PrimaryGrid.MultiSelect = false;
            this.superGridControl_ZakaaDept.PrimaryGrid.NullString = "-----";
            this.superGridControl_ZakaaDept.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_ZakaaDept.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_ZakaaDept.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_ZakaaDept.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_ZakaaDept.Size = new System.Drawing.Size(779, 453);
            this.superGridControl_ZakaaDept.TabIndex = 493;
            // 
            // tabItem_DeptZakaa
            // 
            this.tabItem_DeptZakaa.AttachedControl = this.tabControlPanel32;
            this.tabItem_DeptZakaa.Name = "tabItem_DeptZakaa";
            this.tabItem_DeptZakaa.Text = "مصلحة الزكاة";
            // 
            // tabItem_DeptDoc
            // 
            this.tabItem_DeptDoc.AttachedControl = this.tabControlPanel28;
            this.tabItem_DeptDoc.Name = "tabItem_DeptDoc";
            this.tabItem_DeptDoc.Text = "وثائق الإدارات";
            // 
            // tabControlPanel23
            // 
            this.tabControlPanel23.Controls.Add(this.superGridControl_VisaGoBack);
            this.tabControlPanel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel23.Location = new System.Drawing.Point(0, 27);
            this.tabControlPanel23.Name = "tabControlPanel23";
            this.tabControlPanel23.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel23.Size = new System.Drawing.Size(783, 482);
            this.tabControlPanel23.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.tabControlPanel23.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(210)))), ((int)(((byte)(255)))));
            this.tabControlPanel23.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel23.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanel23.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel23.Style.GradientAngle = 90;
            this.tabControlPanel23.TabIndex = 10;
            this.tabControlPanel23.TabItem = this.tabItem_Visa;
            // 
            // superGridControl_VisaGoBack
            // 
            this.superGridControl_VisaGoBack.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_VisaGoBack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_VisaGoBack.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_VisaGoBack.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_VisaGoBack.HScrollBarVisible = false;
            this.superGridControl_VisaGoBack.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_VisaGoBack.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_VisaGoBack.Name = "superGridControl_VisaGoBack";
            this.superGridControl_VisaGoBack.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_VisaGoBack.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_VisaGoBack.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_VisaGoBack.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn50.Name = "";
            gridColumn50.Visible = false;
            gridColumn50.Width = 60;
            gridColumn51.Name = "EndDate";
            gridColumn51.Width = 90;
            gridColumn52.Name = "IssDate";
            gridColumn52.Width = 90;
            gridColumn53.Name = "Place";
            gridColumn53.Width = 120;
            gridColumn54.Name = "No";
            gridColumn54.Width = 120;
            gridColumn55.Name = "EmpName";
            gridColumn55.Width = 260;
            gridColumn56.Name = "EmpNo";
            this.superGridControl_VisaGoBack.PrimaryGrid.Columns.Add(gridColumn50);
            this.superGridControl_VisaGoBack.PrimaryGrid.Columns.Add(gridColumn51);
            this.superGridControl_VisaGoBack.PrimaryGrid.Columns.Add(gridColumn52);
            this.superGridControl_VisaGoBack.PrimaryGrid.Columns.Add(gridColumn53);
            this.superGridControl_VisaGoBack.PrimaryGrid.Columns.Add(gridColumn54);
            this.superGridControl_VisaGoBack.PrimaryGrid.Columns.Add(gridColumn55);
            this.superGridControl_VisaGoBack.PrimaryGrid.Columns.Add(gridColumn56);
            this.superGridControl_VisaGoBack.PrimaryGrid.DefaultRowHeight = 24;
            background22.Color1 = System.Drawing.Color.White;
            background22.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_VisaGoBack.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background22;
            background23.Color1 = System.Drawing.Color.White;
            background23.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_VisaGoBack.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background23;
            this.superGridControl_VisaGoBack.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background24.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background24.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_VisaGoBack.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background24;
            this.superGridControl_VisaGoBack.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_VisaGoBack.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_VisaGoBack.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_VisaGoBack.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_VisaGoBack.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_VisaGoBack.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_VisaGoBack.PrimaryGrid.MultiSelect = false;
            this.superGridControl_VisaGoBack.PrimaryGrid.NullString = "-----";
            this.superGridControl_VisaGoBack.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_VisaGoBack.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_VisaGoBack.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_VisaGoBack.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_VisaGoBack.Size = new System.Drawing.Size(781, 480);
            this.superGridControl_VisaGoBack.TabIndex = 493;
            // 
            // tabItem_Visa
            // 
            this.tabItem_Visa.AttachedControl = this.tabControlPanel23;
            this.tabItem_Visa.Name = "tabItem_Visa";
            this.tabItem_Visa.Text = "التأشيرات";
            // 
            // tabControlPanel5
            // 
            this.tabControlPanel5.Controls.Add(this.superGridControl_EmployeeVac);
            this.tabControlPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel5.Location = new System.Drawing.Point(0, 27);
            this.tabControlPanel5.Name = "tabControlPanel5";
            this.tabControlPanel5.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel5.Size = new System.Drawing.Size(783, 482);
            this.tabControlPanel5.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.tabControlPanel5.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(210)))), ((int)(((byte)(255)))));
            this.tabControlPanel5.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel5.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanel5.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel5.Style.GradientAngle = 90;
            this.tabControlPanel5.TabIndex = 6;
            this.tabControlPanel5.TabItem = this.tabItem_VacDoc;
            // 
            // superGridControl_EmployeeVac
            // 
            this.superGridControl_EmployeeVac.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_EmployeeVac.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_EmployeeVac.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_EmployeeVac.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_EmployeeVac.HScrollBarVisible = false;
            this.superGridControl_EmployeeVac.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_EmployeeVac.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_EmployeeVac.Name = "superGridControl_EmployeeVac";
            this.superGridControl_EmployeeVac.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_EmployeeVac.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_EmployeeVac.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_EmployeeVac.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn57.Name = "";
            gridColumn57.Visible = false;
            gridColumn57.Width = 60;
            gridColumn58.Name = "EndDate";
            gridColumn58.Width = 90;
            gridColumn59.Name = "IssDate";
            gridColumn59.Width = 90;
            gridColumn60.Name = "Place";
            gridColumn60.Width = 120;
            gridColumn61.Name = "No";
            gridColumn61.Width = 120;
            gridColumn62.Name = "EmpName";
            gridColumn62.Width = 260;
            gridColumn63.Name = "EmpNo";
            this.superGridControl_EmployeeVac.PrimaryGrid.Columns.Add(gridColumn57);
            this.superGridControl_EmployeeVac.PrimaryGrid.Columns.Add(gridColumn58);
            this.superGridControl_EmployeeVac.PrimaryGrid.Columns.Add(gridColumn59);
            this.superGridControl_EmployeeVac.PrimaryGrid.Columns.Add(gridColumn60);
            this.superGridControl_EmployeeVac.PrimaryGrid.Columns.Add(gridColumn61);
            this.superGridControl_EmployeeVac.PrimaryGrid.Columns.Add(gridColumn62);
            this.superGridControl_EmployeeVac.PrimaryGrid.Columns.Add(gridColumn63);
            this.superGridControl_EmployeeVac.PrimaryGrid.DefaultRowHeight = 24;
            background25.Color1 = System.Drawing.Color.White;
            background25.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_EmployeeVac.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background25;
            background26.Color1 = System.Drawing.Color.White;
            background26.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_EmployeeVac.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background26;
            this.superGridControl_EmployeeVac.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background27.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background27.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_EmployeeVac.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background27;
            this.superGridControl_EmployeeVac.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_EmployeeVac.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_EmployeeVac.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_EmployeeVac.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_EmployeeVac.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_EmployeeVac.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_EmployeeVac.PrimaryGrid.MultiSelect = false;
            this.superGridControl_EmployeeVac.PrimaryGrid.NullString = "-----";
            this.superGridControl_EmployeeVac.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_EmployeeVac.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_EmployeeVac.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_EmployeeVac.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_EmployeeVac.Size = new System.Drawing.Size(781, 480);
            this.superGridControl_EmployeeVac.TabIndex = 486;
            // 
            // tabItem_VacDoc
            // 
            this.tabItem_VacDoc.AttachedControl = this.tabControlPanel5;
            this.tabItem_VacDoc.Name = "tabItem_VacDoc";
            this.tabItem_VacDoc.Text = "الإجازات المنتهية";
            // 
            // tabControlPanel22
            // 
            this.tabControlPanel22.Controls.Add(this.superGridControl_Secretariats);
            this.tabControlPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel22.Location = new System.Drawing.Point(0, 27);
            this.tabControlPanel22.Name = "tabControlPanel22";
            this.tabControlPanel22.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel22.Size = new System.Drawing.Size(783, 482);
            this.tabControlPanel22.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.tabControlPanel22.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(210)))), ((int)(((byte)(255)))));
            this.tabControlPanel22.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel22.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanel22.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel22.Style.GradientAngle = 90;
            this.tabControlPanel22.TabIndex = 9;
            this.tabControlPanel22.TabItem = this.tabItem_Secretariats;
            // 
            // superGridControl_Secretariats
            // 
            this.superGridControl_Secretariats.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_Secretariats.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_Secretariats.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_Secretariats.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_Secretariats.HScrollBarVisible = false;
            this.superGridControl_Secretariats.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_Secretariats.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_Secretariats.Name = "superGridControl_Secretariats";
            this.superGridControl_Secretariats.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_Secretariats.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_Secretariats.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_Secretariats.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn64.Name = "";
            gridColumn64.Visible = false;
            gridColumn64.Width = 60;
            gridColumn65.Name = "EndDate";
            gridColumn65.Width = 90;
            gridColumn66.Name = "IssDate";
            gridColumn66.Width = 90;
            gridColumn67.Name = "Place";
            gridColumn67.Width = 120;
            gridColumn68.Name = "No";
            gridColumn68.Width = 120;
            gridColumn69.Name = "EmpName";
            gridColumn69.Width = 260;
            gridColumn70.Name = "EmpNo";
            this.superGridControl_Secretariats.PrimaryGrid.Columns.Add(gridColumn64);
            this.superGridControl_Secretariats.PrimaryGrid.Columns.Add(gridColumn65);
            this.superGridControl_Secretariats.PrimaryGrid.Columns.Add(gridColumn66);
            this.superGridControl_Secretariats.PrimaryGrid.Columns.Add(gridColumn67);
            this.superGridControl_Secretariats.PrimaryGrid.Columns.Add(gridColumn68);
            this.superGridControl_Secretariats.PrimaryGrid.Columns.Add(gridColumn69);
            this.superGridControl_Secretariats.PrimaryGrid.Columns.Add(gridColumn70);
            this.superGridControl_Secretariats.PrimaryGrid.DefaultRowHeight = 24;
            background28.Color1 = System.Drawing.Color.White;
            background28.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Secretariats.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background28;
            background29.Color1 = System.Drawing.Color.White;
            background29.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Secretariats.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background29;
            this.superGridControl_Secretariats.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background30.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background30.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_Secretariats.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background30;
            this.superGridControl_Secretariats.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_Secretariats.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_Secretariats.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_Secretariats.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_Secretariats.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_Secretariats.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_Secretariats.PrimaryGrid.MultiSelect = false;
            this.superGridControl_Secretariats.PrimaryGrid.NullString = "-----";
            this.superGridControl_Secretariats.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_Secretariats.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_Secretariats.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_Secretariats.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_Secretariats.Size = new System.Drawing.Size(781, 480);
            this.superGridControl_Secretariats.TabIndex = 491;
            // 
            // tabItem_Secretariats
            // 
            this.tabItem_Secretariats.AttachedControl = this.tabControlPanel22;
            this.tabItem_Secretariats.Name = "tabItem_Secretariats";
            this.tabItem_Secretariats.Text = "وثائق الأمانات";
            // 
            // tabControlPanel13
            // 
            this.tabControlPanel13.Controls.Add(this.tabControl5);
            this.tabControlPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel13.Location = new System.Drawing.Point(0, 27);
            this.tabControlPanel13.Name = "tabControlPanel13";
            this.tabControlPanel13.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel13.Size = new System.Drawing.Size(783, 482);
            this.tabControlPanel13.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.tabControlPanel13.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(210)))), ((int)(((byte)(255)))));
            this.tabControlPanel13.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel13.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanel13.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel13.Style.GradientAngle = 90;
            this.tabControlPanel13.TabIndex = 8;
            this.tabControlPanel13.TabItem = this.tabItem_CarsDoc;
            // 
            // tabControl5
            // 
            this.tabControl5.BackColor = System.Drawing.Color.Transparent;
            this.tabControl5.CanReorderTabs = true;
            this.tabControl5.CloseButtonPosition = DevComponents.DotNetBar.eTabCloseButtonPosition.Right;
            this.tabControl5.Controls.Add(this.tabControlPanel17);
            this.tabControl5.Controls.Add(this.tabControlPanel18);
            this.tabControl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl5.Font = new System.Drawing.Font("Tahoma", 8F);
            this.tabControl5.Location = new System.Drawing.Point(1, 1);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tabControl5.SelectedTabFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.tabControl5.SelectedTabIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(781, 480);
            this.tabControl5.Style = DevComponents.DotNetBar.eTabStripStyle.RoundHeader;
            this.tabControl5.TabIndex = 855;
            this.tabControl5.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.tabControl5.Tabs.Add(this.tabItem_CarForms);
            this.tabControl5.Tabs.Add(this.tabItem_CarAllownce);
            this.tabControl5.Text = "كروت التشغيل";
            // 
            // tabControlPanel17
            // 
            this.tabControlPanel17.Controls.Add(this.superGridControl_CarForms);
            this.tabControlPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel17.Location = new System.Drawing.Point(0, 25);
            this.tabControlPanel17.Name = "tabControlPanel17";
            this.tabControlPanel17.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel17.Size = new System.Drawing.Size(781, 455);
            this.tabControlPanel17.Style.BackColor1.Color = System.Drawing.Color.White;
            this.tabControlPanel17.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(215)))));
            this.tabControlPanel17.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel17.Style.BorderColor.Color = System.Drawing.SystemColors.ControlDarkDark;
            this.tabControlPanel17.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel17.Style.GradientAngle = 90;
            this.tabControlPanel17.TabIndex = 2;
            this.tabControlPanel17.TabItem = this.tabItem_CarForms;
            // 
            // superGridControl_CarForms
            // 
            this.superGridControl_CarForms.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_CarForms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_CarForms.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_CarForms.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_CarForms.HScrollBarVisible = false;
            this.superGridControl_CarForms.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_CarForms.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_CarForms.Name = "superGridControl_CarForms";
            this.superGridControl_CarForms.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_CarForms.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_CarForms.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_CarForms.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn71.Name = "";
            gridColumn71.Visible = false;
            gridColumn71.Width = 60;
            gridColumn72.Name = "EndDate";
            gridColumn72.Width = 90;
            gridColumn73.Name = "IssDate";
            gridColumn73.Width = 90;
            gridColumn74.Name = "Place";
            gridColumn74.Width = 120;
            gridColumn75.Name = "No";
            gridColumn75.Width = 120;
            gridColumn76.Name = "EmpName";
            gridColumn76.Width = 260;
            gridColumn77.Name = "EmpNo";
            this.superGridControl_CarForms.PrimaryGrid.Columns.Add(gridColumn71);
            this.superGridControl_CarForms.PrimaryGrid.Columns.Add(gridColumn72);
            this.superGridControl_CarForms.PrimaryGrid.Columns.Add(gridColumn73);
            this.superGridControl_CarForms.PrimaryGrid.Columns.Add(gridColumn74);
            this.superGridControl_CarForms.PrimaryGrid.Columns.Add(gridColumn75);
            this.superGridControl_CarForms.PrimaryGrid.Columns.Add(gridColumn76);
            this.superGridControl_CarForms.PrimaryGrid.Columns.Add(gridColumn77);
            this.superGridControl_CarForms.PrimaryGrid.DefaultRowHeight = 24;
            background31.Color1 = System.Drawing.Color.White;
            background31.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_CarForms.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background31;
            background32.Color1 = System.Drawing.Color.White;
            background32.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_CarForms.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background32;
            this.superGridControl_CarForms.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background33.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background33.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_CarForms.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background33;
            this.superGridControl_CarForms.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_CarForms.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_CarForms.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_CarForms.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_CarForms.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_CarForms.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_CarForms.PrimaryGrid.MultiSelect = false;
            this.superGridControl_CarForms.PrimaryGrid.NullString = "-----";
            this.superGridControl_CarForms.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_CarForms.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_CarForms.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_CarForms.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_CarForms.Size = new System.Drawing.Size(779, 453);
            this.superGridControl_CarForms.TabIndex = 492;
            // 
            // tabItem_CarForms
            // 
            this.tabItem_CarForms.AttachedControl = this.tabControlPanel17;
            this.tabItem_CarForms.Name = "tabItem_CarForms";
            this.tabItem_CarForms.Text = "الإستمارات";
            // 
            // tabControlPanel18
            // 
            this.tabControlPanel18.Controls.Add(this.superGridControl_CarAllownces);
            this.tabControlPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel18.Location = new System.Drawing.Point(0, 25);
            this.tabControlPanel18.Name = "tabControlPanel18";
            this.tabControlPanel18.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel18.Size = new System.Drawing.Size(781, 455);
            this.tabControlPanel18.Style.BackColor1.Color = System.Drawing.Color.White;
            this.tabControlPanel18.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(215)))));
            this.tabControlPanel18.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel18.Style.BorderColor.Color = System.Drawing.SystemColors.ControlDarkDark;
            this.tabControlPanel18.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel18.Style.GradientAngle = 90;
            this.tabControlPanel18.TabIndex = 3;
            this.tabControlPanel18.TabItem = this.tabItem_CarAllownce;
            // 
            // superGridControl_CarAllownces
            // 
            this.superGridControl_CarAllownces.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_CarAllownces.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_CarAllownces.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_CarAllownces.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_CarAllownces.HScrollBarVisible = false;
            this.superGridControl_CarAllownces.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_CarAllownces.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_CarAllownces.Name = "superGridControl_CarAllownces";
            this.superGridControl_CarAllownces.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_CarAllownces.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_CarAllownces.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_CarAllownces.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn78.Name = "";
            gridColumn78.Visible = false;
            gridColumn78.Width = 60;
            gridColumn79.Name = "EndDate";
            gridColumn79.Width = 90;
            gridColumn80.Name = "IssDate";
            gridColumn80.Width = 90;
            gridColumn81.Name = "Place";
            gridColumn81.Width = 120;
            gridColumn82.Name = "No";
            gridColumn82.Width = 120;
            gridColumn83.Name = "EmpName";
            gridColumn83.Width = 260;
            gridColumn84.Name = "EmpNo";
            this.superGridControl_CarAllownces.PrimaryGrid.Columns.Add(gridColumn78);
            this.superGridControl_CarAllownces.PrimaryGrid.Columns.Add(gridColumn79);
            this.superGridControl_CarAllownces.PrimaryGrid.Columns.Add(gridColumn80);
            this.superGridControl_CarAllownces.PrimaryGrid.Columns.Add(gridColumn81);
            this.superGridControl_CarAllownces.PrimaryGrid.Columns.Add(gridColumn82);
            this.superGridControl_CarAllownces.PrimaryGrid.Columns.Add(gridColumn83);
            this.superGridControl_CarAllownces.PrimaryGrid.Columns.Add(gridColumn84);
            this.superGridControl_CarAllownces.PrimaryGrid.DefaultRowHeight = 24;
            background34.Color1 = System.Drawing.Color.White;
            background34.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_CarAllownces.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background34;
            background35.Color1 = System.Drawing.Color.White;
            background35.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_CarAllownces.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background35;
            this.superGridControl_CarAllownces.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background36.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background36.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_CarAllownces.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background36;
            this.superGridControl_CarAllownces.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_CarAllownces.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_CarAllownces.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_CarAllownces.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_CarAllownces.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_CarAllownces.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_CarAllownces.PrimaryGrid.MultiSelect = false;
            this.superGridControl_CarAllownces.PrimaryGrid.NullString = "-----";
            this.superGridControl_CarAllownces.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_CarAllownces.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_CarAllownces.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_CarAllownces.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_CarAllownces.Size = new System.Drawing.Size(779, 453);
            this.superGridControl_CarAllownces.TabIndex = 493;
            // 
            // tabItem_CarAllownce
            // 
            this.tabItem_CarAllownce.AttachedControl = this.tabControlPanel18;
            this.tabItem_CarAllownce.Name = "tabItem_CarAllownce";
            this.tabItem_CarAllownce.Text = "التأمينات";
            // 
            // tabItem_CarsDoc
            // 
            this.tabItem_CarsDoc.AttachedControl = this.tabControlPanel13;
            this.tabItem_CarsDoc.Name = "tabItem_CarsDoc";
            this.tabItem_CarsDoc.Text = "وثائق السيارات";
            this.tabItem_CarsDoc.Visible = false;
            // 
            // tabControlPanel4
            // 
            this.tabControlPanel4.Controls.Add(this.superGridControl_FamilyPassport);
            this.tabControlPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel4.Location = new System.Drawing.Point(0, 27);
            this.tabControlPanel4.Name = "tabControlPanel4";
            this.tabControlPanel4.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel4.Size = new System.Drawing.Size(783, 482);
            this.tabControlPanel4.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.tabControlPanel4.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(210)))), ((int)(((byte)(255)))));
            this.tabControlPanel4.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel4.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanel4.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel4.Style.GradientAngle = 90;
            this.tabControlPanel4.TabIndex = 4;
            this.tabControlPanel4.TabItem = this.tabItem_FamilyDoc;
            // 
            // superGridControl_FamilyPassport
            // 
            this.superGridControl_FamilyPassport.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_FamilyPassport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_FamilyPassport.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_FamilyPassport.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_FamilyPassport.HScrollBarVisible = false;
            this.superGridControl_FamilyPassport.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_FamilyPassport.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_FamilyPassport.Name = "superGridControl_FamilyPassport";
            this.superGridControl_FamilyPassport.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_FamilyPassport.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_FamilyPassport.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_FamilyPassport.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn85.Name = "";
            gridColumn85.Visible = false;
            gridColumn85.Width = 60;
            gridColumn86.Name = "EndDate";
            gridColumn86.Width = 90;
            gridColumn87.Name = "IssDate";
            gridColumn87.Width = 90;
            gridColumn88.Name = "Place";
            gridColumn88.Width = 120;
            gridColumn89.Name = "No";
            gridColumn89.Width = 120;
            gridColumn90.Name = "EmpName";
            gridColumn90.Width = 260;
            gridColumn91.Name = "EmpNo";
            this.superGridControl_FamilyPassport.PrimaryGrid.Columns.Add(gridColumn85);
            this.superGridControl_FamilyPassport.PrimaryGrid.Columns.Add(gridColumn86);
            this.superGridControl_FamilyPassport.PrimaryGrid.Columns.Add(gridColumn87);
            this.superGridControl_FamilyPassport.PrimaryGrid.Columns.Add(gridColumn88);
            this.superGridControl_FamilyPassport.PrimaryGrid.Columns.Add(gridColumn89);
            this.superGridControl_FamilyPassport.PrimaryGrid.Columns.Add(gridColumn90);
            this.superGridControl_FamilyPassport.PrimaryGrid.Columns.Add(gridColumn91);
            this.superGridControl_FamilyPassport.PrimaryGrid.DefaultRowHeight = 24;
            background37.Color1 = System.Drawing.Color.White;
            background37.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_FamilyPassport.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background37;
            background38.Color1 = System.Drawing.Color.White;
            background38.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_FamilyPassport.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background38;
            this.superGridControl_FamilyPassport.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background39.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background39.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_FamilyPassport.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background39;
            this.superGridControl_FamilyPassport.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_FamilyPassport.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_FamilyPassport.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_FamilyPassport.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_FamilyPassport.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_FamilyPassport.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_FamilyPassport.PrimaryGrid.MultiSelect = false;
            this.superGridControl_FamilyPassport.PrimaryGrid.NullString = "-----";
            this.superGridControl_FamilyPassport.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_FamilyPassport.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_FamilyPassport.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_FamilyPassport.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_FamilyPassport.Size = new System.Drawing.Size(781, 480);
            this.superGridControl_FamilyPassport.TabIndex = 487;
            // 
            // tabItem_FamilyDoc
            // 
            this.tabItem_FamilyDoc.AttachedControl = this.tabControlPanel4;
            this.tabItem_FamilyDoc.Name = "tabItem_FamilyDoc";
            this.tabItem_FamilyDoc.Text = "جوازات المرافقين";
            // 
            // tabControlPanel3
            // 
            this.tabControlPanel3.Controls.Add(this.superGridControl_Contract);
            this.tabControlPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel3.Location = new System.Drawing.Point(0, 27);
            this.tabControlPanel3.Name = "tabControlPanel3";
            this.tabControlPanel3.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel3.Size = new System.Drawing.Size(783, 482);
            this.tabControlPanel3.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.tabControlPanel3.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(210)))), ((int)(((byte)(255)))));
            this.tabControlPanel3.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel3.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanel3.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel3.Style.GradientAngle = 90;
            this.tabControlPanel3.TabIndex = 3;
            this.tabControlPanel3.TabItem = this.tabItem_EmployeeContract;
            // 
            // superGridControl_Contract
            // 
            this.superGridControl_Contract.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_Contract.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_Contract.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_Contract.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_Contract.HScrollBarVisible = false;
            this.superGridControl_Contract.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_Contract.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_Contract.Name = "superGridControl_Contract";
            this.superGridControl_Contract.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_Contract.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_Contract.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_Contract.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn92.Name = "";
            gridColumn92.Visible = false;
            gridColumn92.Width = 60;
            gridColumn93.Name = "EndDate";
            gridColumn93.Width = 90;
            gridColumn94.Name = "IssDate";
            gridColumn94.Width = 90;
            gridColumn95.Name = "Place";
            gridColumn95.Width = 120;
            gridColumn96.Name = "No";
            gridColumn96.Width = 120;
            gridColumn97.Name = "EmpName";
            gridColumn97.Width = 260;
            gridColumn98.Name = "EmpNo";
            this.superGridControl_Contract.PrimaryGrid.Columns.Add(gridColumn92);
            this.superGridControl_Contract.PrimaryGrid.Columns.Add(gridColumn93);
            this.superGridControl_Contract.PrimaryGrid.Columns.Add(gridColumn94);
            this.superGridControl_Contract.PrimaryGrid.Columns.Add(gridColumn95);
            this.superGridControl_Contract.PrimaryGrid.Columns.Add(gridColumn96);
            this.superGridControl_Contract.PrimaryGrid.Columns.Add(gridColumn97);
            this.superGridControl_Contract.PrimaryGrid.Columns.Add(gridColumn98);
            this.superGridControl_Contract.PrimaryGrid.DefaultRowHeight = 24;
            background40.Color1 = System.Drawing.Color.White;
            background40.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Contract.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background40;
            background41.Color1 = System.Drawing.Color.White;
            background41.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_Contract.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background41;
            this.superGridControl_Contract.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background42.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background42.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_Contract.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background42;
            this.superGridControl_Contract.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_Contract.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_Contract.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_Contract.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_Contract.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_Contract.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_Contract.PrimaryGrid.MultiSelect = false;
            this.superGridControl_Contract.PrimaryGrid.NullString = "-----";
            this.superGridControl_Contract.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_Contract.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_Contract.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_Contract.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_Contract.Size = new System.Drawing.Size(781, 480);
            this.superGridControl_Contract.TabIndex = 486;
            // 
            // tabItem_EmployeeContract
            // 
            this.tabItem_EmployeeContract.AttachedControl = this.tabControlPanel3;
            this.tabItem_EmployeeContract.Name = "tabItem_EmployeeContract";
            this.tabItem_EmployeeContract.Text = "العقود المنتهية";
            // 
            // tabControlPanel1
            // 
            this.tabControlPanel1.Controls.Add(this.superGridControl_BossRecord);
            this.tabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel1.Location = new System.Drawing.Point(0, 27);
            this.tabControlPanel1.Name = "tabControlPanel1";
            this.tabControlPanel1.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel1.Size = new System.Drawing.Size(783, 482);
            this.tabControlPanel1.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.tabControlPanel1.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(210)))), ((int)(((byte)(255)))));
            this.tabControlPanel1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel1.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanel1.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel1.Style.GradientAngle = 90;
            this.tabControlPanel1.TabIndex = 5;
            this.tabControlPanel1.TabItem = this.tabItem_BossDoc;
            // 
            // superGridControl_BossRecord
            // 
            this.superGridControl_BossRecord.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_BossRecord.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_BossRecord.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_BossRecord.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_BossRecord.HScrollBarVisible = false;
            this.superGridControl_BossRecord.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_BossRecord.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_BossRecord.Name = "superGridControl_BossRecord";
            this.superGridControl_BossRecord.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_BossRecord.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_BossRecord.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_BossRecord.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn99.Name = "";
            gridColumn99.Visible = false;
            gridColumn99.Width = 60;
            gridColumn100.Name = "EndDate";
            gridColumn100.Width = 90;
            gridColumn101.Name = "IssDate";
            gridColumn101.Width = 90;
            gridColumn102.Name = "Place";
            gridColumn102.Width = 120;
            gridColumn103.Name = "No";
            gridColumn103.Width = 120;
            gridColumn104.Name = "EmpName";
            gridColumn104.Width = 260;
            gridColumn105.Name = "EmpNo";
            this.superGridControl_BossRecord.PrimaryGrid.Columns.Add(gridColumn99);
            this.superGridControl_BossRecord.PrimaryGrid.Columns.Add(gridColumn100);
            this.superGridControl_BossRecord.PrimaryGrid.Columns.Add(gridColumn101);
            this.superGridControl_BossRecord.PrimaryGrid.Columns.Add(gridColumn102);
            this.superGridControl_BossRecord.PrimaryGrid.Columns.Add(gridColumn103);
            this.superGridControl_BossRecord.PrimaryGrid.Columns.Add(gridColumn104);
            this.superGridControl_BossRecord.PrimaryGrid.Columns.Add(gridColumn105);
            this.superGridControl_BossRecord.PrimaryGrid.DefaultRowHeight = 24;
            background43.Color1 = System.Drawing.Color.White;
            background43.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_BossRecord.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background43;
            background44.Color1 = System.Drawing.Color.White;
            background44.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_BossRecord.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background44;
            this.superGridControl_BossRecord.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background45.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background45.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_BossRecord.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background45;
            this.superGridControl_BossRecord.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_BossRecord.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_BossRecord.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_BossRecord.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_BossRecord.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_BossRecord.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_BossRecord.PrimaryGrid.MultiSelect = false;
            this.superGridControl_BossRecord.PrimaryGrid.NullString = "-----";
            this.superGridControl_BossRecord.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_BossRecord.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_BossRecord.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_BossRecord.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_BossRecord.Size = new System.Drawing.Size(781, 480);
            this.superGridControl_BossRecord.TabIndex = 494;
            // 
            // tabItem_BossDoc
            // 
            this.tabItem_BossDoc.AttachedControl = this.tabControlPanel10;
            this.tabItem_BossDoc.Name = "tabItem_BossDoc";
            this.tabItem_BossDoc.Text = "السجل المدني للكفلاء";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSplitButton_Print,
            this.toolStripButton_Close});
            this.toolStrip1.Location = new System.Drawing.Point(0, 509);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(783, 25);
            this.toolStrip1.Stretch = true;
            this.toolStrip1.TabIndex = 1105;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSplitButton_Print
            // 
            this.toolStripSplitButton_Print.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_DocEmp,
            this.toolStripSeparator4,
            this.ToolStripMenuItem_PrintContract,
            this.ToolStripMenuItem_PrintVac,
            this.ToolStripMenuItem_PrintFamilyPassport,
            this.toolStripSeparator1,
            this.ToolStripMenuItem_BossRecord,
            this.toolStripSeparator18,
            this.ToolStripMenuItem_DeptDoc,
            this.toolStripSeparator3,
            this.ToolStripMenuItem_CarDoc,
            this.toolStripSeparator13,
            this.ToolStripMenuItem_SecretariatsDoc,
            this.toolStripSeparator19,
            this.ToolStripMenuItem_VisaGoBack});
            this.toolStripSplitButton_Print.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton_Print.Name = "toolStripSplitButton_Print";
            this.toolStripSplitButton_Print.Size = new System.Drawing.Size(63, 22);
            this.toolStripSplitButton_Print.Text = "طبـــــاعة";
            this.toolStripSplitButton_Print.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.toolStripSplitButton_Print.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // ToolStripMenuItem_DocEmp
            // 
            this.ToolStripMenuItem_DocEmp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_PrintEmpID,
            this.toolStripSeparator5,
            this.ToolStripMenuItem_PrintEmpPassport,
            this.toolStripSeparator6,
            this.ToolStripMenuItem_PrintEmpLicense,
            this.toolStripSeparator7,
            this.ToolStripMenuItem_PrintEmpForms,
            this.toolStripSeparator8,
            this.ToolStripMenuItem_PrintEmpAllownce});
            this.ToolStripMenuItem_DocEmp.Name = "ToolStripMenuItem_DocEmp";
            this.ToolStripMenuItem_DocEmp.Size = new System.Drawing.Size(230, 22);
            this.ToolStripMenuItem_DocEmp.Text = "وثائق الموظفين";
            // 
            // ToolStripMenuItem_PrintEmpID
            // 
            this.ToolStripMenuItem_PrintEmpID.Name = "ToolStripMenuItem_PrintEmpID";
            this.ToolStripMenuItem_PrintEmpID.Size = new System.Drawing.Size(197, 22);
            this.ToolStripMenuItem_PrintEmpID.Text = "طباعة الهويات";
            this.ToolStripMenuItem_PrintEmpID.Click += new System.EventHandler(this.ToolStripMenuItem_PrintEmpID_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(194, 6);
            // 
            // ToolStripMenuItem_PrintEmpPassport
            // 
            this.ToolStripMenuItem_PrintEmpPassport.Name = "ToolStripMenuItem_PrintEmpPassport";
            this.ToolStripMenuItem_PrintEmpPassport.Size = new System.Drawing.Size(197, 22);
            this.ToolStripMenuItem_PrintEmpPassport.Text = "طباعة جوازات السفر";
            this.ToolStripMenuItem_PrintEmpPassport.Click += new System.EventHandler(this.ToolStripMenuItem_PrintEmpPassport_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(194, 6);
            // 
            // ToolStripMenuItem_PrintEmpLicense
            // 
            this.ToolStripMenuItem_PrintEmpLicense.Name = "ToolStripMenuItem_PrintEmpLicense";
            this.ToolStripMenuItem_PrintEmpLicense.Size = new System.Drawing.Size(197, 22);
            this.ToolStripMenuItem_PrintEmpLicense.Text = "طباعة رخص القيادة";
            this.ToolStripMenuItem_PrintEmpLicense.Click += new System.EventHandler(this.ToolStripMenuItem_PrintEmpLicense_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(194, 6);
            // 
            // ToolStripMenuItem_PrintEmpForms
            // 
            this.ToolStripMenuItem_PrintEmpForms.Name = "ToolStripMenuItem_PrintEmpForms";
            this.ToolStripMenuItem_PrintEmpForms.Size = new System.Drawing.Size(197, 22);
            this.ToolStripMenuItem_PrintEmpForms.Text = "طباعة إستمارات السيارات";
            this.ToolStripMenuItem_PrintEmpForms.Click += new System.EventHandler(this.ToolStripMenuItem_PrintEmpForms_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(194, 6);
            // 
            // ToolStripMenuItem_PrintEmpAllownce
            // 
            this.ToolStripMenuItem_PrintEmpAllownce.Name = "ToolStripMenuItem_PrintEmpAllownce";
            this.ToolStripMenuItem_PrintEmpAllownce.Size = new System.Drawing.Size(197, 22);
            this.ToolStripMenuItem_PrintEmpAllownce.Text = "طباعة التأمينات الصحية";
            this.ToolStripMenuItem_PrintEmpAllownce.Click += new System.EventHandler(this.ToolStripMenuItem_PrintEmpAllownce_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(227, 6);
            // 
            // ToolStripMenuItem_PrintContract
            // 
            this.ToolStripMenuItem_PrintContract.Name = "ToolStripMenuItem_PrintContract";
            this.ToolStripMenuItem_PrintContract.Size = new System.Drawing.Size(230, 22);
            this.ToolStripMenuItem_PrintContract.Text = "طباعة العقود المنتهية";
            this.ToolStripMenuItem_PrintContract.Click += new System.EventHandler(this.ToolStripMenuItem_PrintContract_Click);
            // 
            // ToolStripMenuItem_PrintVac
            // 
            this.ToolStripMenuItem_PrintVac.Name = "ToolStripMenuItem_PrintVac";
            this.ToolStripMenuItem_PrintVac.Size = new System.Drawing.Size(230, 22);
            this.ToolStripMenuItem_PrintVac.Text = "طباعة الاجازات المنتهية";
            this.ToolStripMenuItem_PrintVac.Click += new System.EventHandler(this.ToolStripMenuItem_PrintVac_Click);
            // 
            // ToolStripMenuItem_PrintFamilyPassport
            // 
            this.ToolStripMenuItem_PrintFamilyPassport.Name = "ToolStripMenuItem_PrintFamilyPassport";
            this.ToolStripMenuItem_PrintFamilyPassport.Size = new System.Drawing.Size(230, 22);
            this.ToolStripMenuItem_PrintFamilyPassport.Text = "طباعة جوازات المرافقين المنتهية";
            this.ToolStripMenuItem_PrintFamilyPassport.Click += new System.EventHandler(this.ToolStripMenuItem_PrintFamilyPassport_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(227, 6);
            // 
            // ToolStripMenuItem_BossRecord
            // 
            this.ToolStripMenuItem_BossRecord.Name = "ToolStripMenuItem_BossRecord";
            this.ToolStripMenuItem_BossRecord.Size = new System.Drawing.Size(230, 22);
            this.ToolStripMenuItem_BossRecord.Text = "السجل المدني للكفلاء";
            this.ToolStripMenuItem_BossRecord.Click += new System.EventHandler(this.ToolStripMenuItem_BossRecord_Click);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(227, 6);
            // 
            // ToolStripMenuItem_DeptDoc
            // 
            this.ToolStripMenuItem_DeptDoc.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_DeptAllownce,
            this.toolStripSeparator16,
            this.ToolStripMenuItem_DeptZakaa,
            this.toolStripSeparator17});
            this.ToolStripMenuItem_DeptDoc.Name = "ToolStripMenuItem_DeptDoc";
            this.ToolStripMenuItem_DeptDoc.Size = new System.Drawing.Size(230, 22);
            this.ToolStripMenuItem_DeptDoc.Text = "وثائق الإدارات";
            // 
            // ToolStripMenuItem_DeptAllownce
            // 
            this.ToolStripMenuItem_DeptAllownce.Name = "ToolStripMenuItem_DeptAllownce";
            this.ToolStripMenuItem_DeptAllownce.Size = new System.Drawing.Size(209, 22);
            this.ToolStripMenuItem_DeptAllownce.Text = "التأمينات الإجتماعية للإدارات";
            this.ToolStripMenuItem_DeptAllownce.Click += new System.EventHandler(this.ToolStripMenuItem_DeptAllownce_Click);
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(206, 6);
            // 
            // ToolStripMenuItem_DeptZakaa
            // 
            this.ToolStripMenuItem_DeptZakaa.Name = "ToolStripMenuItem_DeptZakaa";
            this.ToolStripMenuItem_DeptZakaa.Size = new System.Drawing.Size(209, 22);
            this.ToolStripMenuItem_DeptZakaa.Text = "مصلحة الزكاة";
            this.ToolStripMenuItem_DeptZakaa.Click += new System.EventHandler(this.ToolStripMenuItem_DeptZakaa_Click);
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(206, 6);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(227, 6);
            // 
            // ToolStripMenuItem_CarDoc
            // 
            this.ToolStripMenuItem_CarDoc.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_CarsForms,
            this.toolStripSeparator11,
            this.ToolStripMenuItem_CarsAllownce,
            this.toolStripSeparator12});
            this.ToolStripMenuItem_CarDoc.Name = "ToolStripMenuItem_CarDoc";
            this.ToolStripMenuItem_CarDoc.Size = new System.Drawing.Size(230, 22);
            this.ToolStripMenuItem_CarDoc.Text = "وثائق السيارات";
            // 
            // ToolStripMenuItem_CarsForms
            // 
            this.ToolStripMenuItem_CarsForms.Name = "ToolStripMenuItem_CarsForms";
            this.ToolStripMenuItem_CarsForms.Size = new System.Drawing.Size(159, 22);
            this.ToolStripMenuItem_CarsForms.Text = "طباعة الإستمارات";
            this.ToolStripMenuItem_CarsForms.Click += new System.EventHandler(this.ToolStripMenuItem_CarsForms_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(156, 6);
            // 
            // ToolStripMenuItem_CarsAllownce
            // 
            this.ToolStripMenuItem_CarsAllownce.Name = "ToolStripMenuItem_CarsAllownce";
            this.ToolStripMenuItem_CarsAllownce.Size = new System.Drawing.Size(159, 22);
            this.ToolStripMenuItem_CarsAllownce.Text = "طباعة التأمينات";
            this.ToolStripMenuItem_CarsAllownce.Click += new System.EventHandler(this.ToolStripMenuItem_CarsAllownce_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(156, 6);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(227, 6);
            // 
            // ToolStripMenuItem_SecretariatsDoc
            // 
            this.ToolStripMenuItem_SecretariatsDoc.Name = "ToolStripMenuItem_SecretariatsDoc";
            this.ToolStripMenuItem_SecretariatsDoc.Size = new System.Drawing.Size(230, 22);
            this.ToolStripMenuItem_SecretariatsDoc.Text = "وثائق الأمانات";
            this.ToolStripMenuItem_SecretariatsDoc.Click += new System.EventHandler(this.ToolStripMenuItem_SecretariatsDoc_Click);
            // 
            // toolStripSeparator19
            // 
            this.toolStripSeparator19.Name = "toolStripSeparator19";
            this.toolStripSeparator19.Size = new System.Drawing.Size(227, 6);
            // 
            // ToolStripMenuItem_VisaGoBack
            // 
            this.ToolStripMenuItem_VisaGoBack.Name = "ToolStripMenuItem_VisaGoBack";
            this.ToolStripMenuItem_VisaGoBack.Size = new System.Drawing.Size(230, 22);
            this.ToolStripMenuItem_VisaGoBack.Text = "تأشيرات الخروج والعودة";
            this.ToolStripMenuItem_VisaGoBack.Click += new System.EventHandler(this.ToolStripMenuItem_VisaGoBack_Click);
            // 
            // toolStripButton_Close
            // 
            this.toolStripButton_Close.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton_Close.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_Close.Image")));
            this.toolStripButton_Close.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_Close.Name = "toolStripButton_Close";
            this.toolStripButton_Close.Size = new System.Drawing.Size(52, 22);
            this.toolStripButton_Close.Text = "خــــــــروج";
            this.toolStripButton_Close.Click += new System.EventHandler(this.toolStripButton_Close_Click);
            // 
            // tabControlPanel16
            // 
            this.tabControlPanel16.Controls.Add(this.superGridControl_RecordBranch);
            this.tabControlPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel16.Location = new System.Drawing.Point(0, 24);
            this.tabControlPanel16.Name = "tabControlPanel16";
            this.tabControlPanel16.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel16.Size = new System.Drawing.Size(950, 456);
            this.tabControlPanel16.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tabControlPanel16.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel16.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(157)))), ((int)(((byte)(189)))));
            this.tabControlPanel16.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel16.Style.GradientAngle = 90;
            this.tabControlPanel16.TabIndex = 3;
            // 
            // superGridControl_RecordBranch
            // 
            this.superGridControl_RecordBranch.BackColor = System.Drawing.SystemColors.ControlLight;
            this.superGridControl_RecordBranch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superGridControl_RecordBranch.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl_RecordBranch.ForeColor = System.Drawing.Color.Black;
            this.superGridControl_RecordBranch.HScrollBarVisible = false;
            this.superGridControl_RecordBranch.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl_RecordBranch.Location = new System.Drawing.Point(1, 1);
            this.superGridControl_RecordBranch.Name = "superGridControl_RecordBranch";
            this.superGridControl_RecordBranch.PrimaryGrid.AllowRowHeaderResize = true;
            this.superGridControl_RecordBranch.PrimaryGrid.AllowRowResize = true;
            this.superGridControl_RecordBranch.PrimaryGrid.ColumnHeader.RowHeight = 30;
            this.superGridControl_RecordBranch.PrimaryGrid.ColumnHeader.SortImageAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            gridColumn106.Name = "";
            gridColumn106.Width = 60;
            gridColumn107.Name = "EndDate";
            gridColumn107.Width = 90;
            gridColumn108.Name = "IssDate";
            gridColumn108.Width = 90;
            gridColumn109.Name = "Place";
            gridColumn109.Width = 120;
            gridColumn110.Name = "No";
            gridColumn110.Width = 120;
            gridColumn111.Name = "EmpName";
            gridColumn111.Width = 260;
            gridColumn112.Name = "EmpNo";
            this.superGridControl_RecordBranch.PrimaryGrid.Columns.Add(gridColumn106);
            this.superGridControl_RecordBranch.PrimaryGrid.Columns.Add(gridColumn107);
            this.superGridControl_RecordBranch.PrimaryGrid.Columns.Add(gridColumn108);
            this.superGridControl_RecordBranch.PrimaryGrid.Columns.Add(gridColumn109);
            this.superGridControl_RecordBranch.PrimaryGrid.Columns.Add(gridColumn110);
            this.superGridControl_RecordBranch.PrimaryGrid.Columns.Add(gridColumn111);
            this.superGridControl_RecordBranch.PrimaryGrid.Columns.Add(gridColumn112);
            this.superGridControl_RecordBranch.PrimaryGrid.DefaultRowHeight = 24;
            background46.Color1 = System.Drawing.Color.White;
            background46.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_RecordBranch.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.Background = background46;
            background47.Color1 = System.Drawing.Color.White;
            background47.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.superGridControl_RecordBranch.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.Background = background47;
            this.superGridControl_RecordBranch.PrimaryGrid.DefaultVisualStyles.CellStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            background48.Color1 = System.Drawing.SystemColors.ActiveCaption;
            background48.Color2 = System.Drawing.SystemColors.GradientInactiveCaption;
            this.superGridControl_RecordBranch.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Background = background48;
            this.superGridControl_RecordBranch.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.superGridControl_RecordBranch.PrimaryGrid.EnableColumnFiltering = true;
            this.superGridControl_RecordBranch.PrimaryGrid.EnableFiltering = true;
            this.superGridControl_RecordBranch.PrimaryGrid.EnableRowFiltering = true;
            this.superGridControl_RecordBranch.PrimaryGrid.FilterLevel = ((DevComponents.DotNetBar.SuperGrid.FilterLevel)((DevComponents.DotNetBar.SuperGrid.FilterLevel.Root | DevComponents.DotNetBar.SuperGrid.FilterLevel.Expanded)));
            this.superGridControl_RecordBranch.PrimaryGrid.FilterMatchType = DevComponents.DotNetBar.SuperGrid.FilterMatchType.RegularExpressions;
            this.superGridControl_RecordBranch.PrimaryGrid.MultiSelect = false;
            this.superGridControl_RecordBranch.PrimaryGrid.NullString = "-----";
            this.superGridControl_RecordBranch.PrimaryGrid.RowHeaderWidth = 45;
            this.superGridControl_RecordBranch.PrimaryGrid.ShowRowGridIndex = true;
            this.superGridControl_RecordBranch.PrimaryGrid.ShowRowHeaders = false;
            this.superGridControl_RecordBranch.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superGridControl_RecordBranch.Size = new System.Drawing.Size(948, 454);
            this.superGridControl_RecordBranch.TabIndex = 493;
            // 
            // FrmAutoAlarm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 551);
            this.PanelSpecialContainer.Controls.Add(this.ribbonBar1);
            this.ribbonBar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(InvAcc.Properties.Resources.favicon));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "FrmAutoAlarm";
            this.netResize1.AutoSaveLayout = true;
            this.netResize1.ParentControl = this;
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "تنبيهــات وثائــق شؤون الموظفـــين";
            this.Load += new System.EventHandler(this.FrmAutoAlarm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmAutoAlarm_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FrmAutoAlarm_KeyPress);
            this.ribbonBar1.ResumeLayout(false);
            this.ribbonBar1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabControl1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabControlPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabControl2)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.tabControlPanel6.ResumeLayout(false);
            this.tabControlPanel10.ResumeLayout(false);
            this.tabControlPanel7.ResumeLayout(false);
            this.tabControlPanel8.ResumeLayout(false);
            this.tabControlPanel9.ResumeLayout(false);
            this.tabControlPanel28.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabControl6)).EndInit();
            this.tabControl6.ResumeLayout(false);
            this.tabControlPanel29.ResumeLayout(false);
            this.tabControlPanel32.ResumeLayout(false);
            this.tabControlPanel23.ResumeLayout(false);
            this.tabControlPanel5.ResumeLayout(false);
            this.tabControlPanel22.ResumeLayout(false);
            this.tabControlPanel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabControl5)).EndInit();
            this.tabControl5.ResumeLayout(false);
            this.tabControlPanel17.ResumeLayout(false);
            this.tabControlPanel18.ResumeLayout(false);
            this.tabControlPanel4.ResumeLayout(false);
            this.tabControlPanel3.ResumeLayout(false);
            this.tabControlPanel1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabControlPanel16.ResumeLayout(false);
            this.Icon = ((System.Drawing.Icon)(InvAcc.Properties.Resources.favicon));
            ((System.ComponentModel.ISupportInitialize)(this.netResize1)).EndInit();
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
            this.MaximizeBox = true;
            this.ResumeLayout(false);
        }//###########&&&&&&&&&&

}
}
