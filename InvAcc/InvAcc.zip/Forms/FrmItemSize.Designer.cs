   

namespace InvAcc.Forms
{
partial class FrmItemSize
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
    
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

private void InitializeComponent()
        {
            this.ribbonBar1 = new DevComponents.DotNetBar.RibbonBar();
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.button_Unit2 = new DevComponents.DotNetBar.ButtonX();
            this.button_Unit3 = new DevComponents.DotNetBar.ButtonX();
            this.button_Unit4 = new DevComponents.DotNetBar.ButtonX();
            this.button_Unit5 = new DevComponents.DotNetBar.ButtonX();
            this.label5E = new System.Windows.Forms.Label();
            this.label4E = new System.Windows.Forms.Label();
            this.label3E = new System.Windows.Forms.Label();
            this.label1E = new System.Windows.Forms.Label();
            this.label2E = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_Close = new DevComponents.DotNetBar.ButtonX();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button_Unit1 = new DevComponents.DotNetBar.ButtonX();
            this.ribbonBar1.SuspendLayout();
            this.groupPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbonBar1
            // 
            this.ribbonBar1.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar1.ContainerControlProcessDialogKey = true;
            this.ribbonBar1.Controls.Add(this.groupPanel1);
            this.ribbonBar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonBar1.Tag= "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.ribbonBar1.Location = new System.Drawing.Point(0, 0);
            this.ribbonBar1.Name = "ribbonBar1";
            this.ribbonBar1.Size = new System.Drawing.Size(293, 375);
            this.ribbonBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.OfficeXP;
            this.ribbonBar1.TabIndex = 1143;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(239)))), ((int)(((byte)(255)))));
            this.ribbonBar1.TitleStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(147)))), ((int)(((byte)(207)))));
            this.ribbonBar1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // groupPanel1
            // 
            this.groupPanel1.BackColor = System.Drawing.Color.AliceBlue;
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.button_Unit2);
            this.groupPanel1.Controls.Add(this.button_Unit3);
            this.groupPanel1.Controls.Add(this.button_Unit4);
            this.groupPanel1.Controls.Add(this.button_Unit5);
            this.groupPanel1.Controls.Add(this.label5E);
            this.groupPanel1.Controls.Add(this.label4E);
            this.groupPanel1.Controls.Add(this.label3E);
            this.groupPanel1.Controls.Add(this.label1E);
            this.groupPanel1.Controls.Add(this.label2E);
            this.groupPanel1.Controls.Add(this.label5);
            this.groupPanel1.Controls.Add(this.label4);
            this.groupPanel1.Controls.Add(this.button_Close);
            this.groupPanel1.Controls.Add(this.label3);
            this.groupPanel1.Controls.Add(this.label1);
            this.groupPanel1.Controls.Add(this.label2);
            this.groupPanel1.Controls.Add(this.button_Unit1);
            this.groupPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupPanel1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.groupPanel1.Location = new System.Drawing.Point(0, 0);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(293, 358);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1.TabIndex = 0;
            this.groupPanel1.Text = "Units   -   الوحدات";
            this.groupPanel1.Click += new System.EventHandler(this.groupPanel1_Click);
            // 
            // button_Unit2
            // 
            this.button_Unit2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Unit2.Checked = true;
            this.button_Unit2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_Unit2.Location = new System.Drawing.Point(100, 73);
            this.button_Unit2.Name = "button_Unit2";
            this.button_Unit2.Size = new System.Drawing.Size(100, 48);
            this.button_Unit2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Unit2.Symbol = "";
            this.button_Unit2.TabIndex = 1174;
            this.button_Unit2.Click += new System.EventHandler(this.button_Unit2_Click);
            // 
            // button_Unit3
            // 
            this.button_Unit3.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Unit3.Checked = true;
            this.button_Unit3.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_Unit3.Location = new System.Drawing.Point(100, 129);
            this.button_Unit3.Name = "button_Unit3";
            this.button_Unit3.Size = new System.Drawing.Size(100, 48);
            this.button_Unit3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Unit3.Symbol = "";
            this.button_Unit3.TabIndex = 1173;
            this.button_Unit3.Click += new System.EventHandler(this.button_Unit3_Click);
            // 
            // button_Unit4
            // 
            this.button_Unit4.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Unit4.Checked = true;
            this.button_Unit4.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_Unit4.Location = new System.Drawing.Point(100, 185);
            this.button_Unit4.Name = "button_Unit4";
            this.button_Unit4.Size = new System.Drawing.Size(100, 48);
            this.button_Unit4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Unit4.Symbol = "";
            this.button_Unit4.TabIndex = 1172;
            this.button_Unit4.Click += new System.EventHandler(this.button_Unit4_Click);
            // 
            // button_Unit5
            // 
            this.button_Unit5.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Unit5.Checked = true;
            this.button_Unit5.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_Unit5.Location = new System.Drawing.Point(100, 241);
            this.button_Unit5.Name = "button_Unit5";
            this.button_Unit5.Size = new System.Drawing.Size(100, 48);
            this.button_Unit5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Unit5.Symbol = "";
            this.button_Unit5.TabIndex = 1171;
            this.button_Unit5.Click += new System.EventHandler(this.button_Unit5_Click);
            // 
            // label5E
            // 
            this.label5E.BackColor = System.Drawing.Color.Transparent;
            this.label5E.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label5E.ForeColor = System.Drawing.Color.Black;
            this.label5E.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5E.Location = new System.Drawing.Point(12, 241);
            this.label5E.Name = "label5E";
            this.label5E.Size = new System.Drawing.Size(82, 48);
            this.label5E.TabIndex = 1169;
            this.label5E.Text = "كبـــير";
            this.label5E.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4E
            // 
            this.label4E.BackColor = System.Drawing.Color.Transparent;
            this.label4E.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label4E.ForeColor = System.Drawing.Color.Black;
            this.label4E.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4E.Location = new System.Drawing.Point(12, 185);
            this.label4E.Name = "label4E";
            this.label4E.Size = new System.Drawing.Size(82, 48);
            this.label4E.TabIndex = 1168;
            this.label4E.Text = "وســـط";
            this.label4E.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3E
            // 
            this.label3E.BackColor = System.Drawing.Color.Transparent;
            this.label3E.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label3E.ForeColor = System.Drawing.Color.Black;
            this.label3E.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3E.Location = new System.Drawing.Point(12, 129);
            this.label3E.Name = "label3E";
            this.label3E.Size = new System.Drawing.Size(82, 48);
            this.label3E.TabIndex = 1167;
            this.label3E.Text = "كبـــير";
            this.label3E.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1E
            // 
            this.label1E.BackColor = System.Drawing.Color.Transparent;
            this.label1E.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label1E.ForeColor = System.Drawing.Color.Black;
            this.label1E.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1E.Location = new System.Drawing.Point(12, 17);
            this.label1E.Name = "label1E";
            this.label1E.Size = new System.Drawing.Size(82, 48);
            this.label1E.TabIndex = 1166;
            this.label1E.Text = "صغـــير";
            this.label1E.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2E
            // 
            this.label2E.BackColor = System.Drawing.Color.Transparent;
            this.label2E.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label2E.ForeColor = System.Drawing.Color.Black;
            this.label2E.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2E.Location = new System.Drawing.Point(12, 73);
            this.label2E.Name = "label2E";
            this.label2E.Size = new System.Drawing.Size(82, 48);
            this.label2E.TabIndex = 1165;
            this.label2E.Text = "وســـط";
            this.label2E.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(205, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 48);
            this.label5.TabIndex = 1164;
            this.label5.Text = "كبـــير";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(205, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 48);
            this.label4.TabIndex = 1163;
            this.label4.Text = "وســـط";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_Close
            // 
            this.button_Close.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Close.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.button_Close.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button_Close.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.button_Close.Location = new System.Drawing.Point(0, 290);
            this.button_Close.Name = "button_Close";
            this.button_Close.Size = new System.Drawing.Size(287, 45);
            this.button_Close.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Close.Symbol = "";
            this.button_Close.SymbolSize = 18F;
            this.button_Close.TabIndex = 1162;
            this.button_Close.Text = "تــــراجــــــع";
            this.button_Close.TextColor = System.Drawing.Color.White;
            this.button_Close.Click += new System.EventHandler(this.button_Close_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(205, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 48);
            this.label3.TabIndex = 1161;
            this.label3.Text = "كبـــير";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(205, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 48);
            this.label1.TabIndex = 1160;
            this.label1.Text = "صغـــير";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(205, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 48);
            this.label2.TabIndex = 1159;
            this.label2.Text = "وســـط";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_Unit1
            // 
            this.button_Unit1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Unit1.Checked = true;
            this.button_Unit1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_Unit1.Location = new System.Drawing.Point(100, 17);
            this.button_Unit1.Name = "button_Unit1";
            this.button_Unit1.Size = new System.Drawing.Size(100, 48);
            this.button_Unit1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Unit1.Symbol = "";
            this.button_Unit1.TabIndex = 1170;
            this.button_Unit1.Click += new System.EventHandler(this.button_Unit1_Click);
            // 
            // FrmItemSize
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(293, 375);
            this.ControlBox = false;
            this.Controls.Add(this.ribbonBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmItemSize";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FrmItemSize_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmItemSize_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FrmItemSize_KeyPress);
            this.ribbonBar1.ResumeLayout(false);
            this.groupPanel1.ResumeLayout(false);
            this.Icon = ((System.Drawing.Icon)(InvAcc.Properties.Resources.favicon));
            this.ResumeLayout(false);

        }//###########&&&&&&&&&&

}
}
