   

namespace InvAcc.Forms
{
partial class FrmInvSaleCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
    
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmInvSaleCar));
            DevComponents.DotNetBar.Rendering.SuperTabColorTable superTabColorTable1 = new DevComponents.DotNetBar.Rendering.SuperTabColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable1 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabControlBoxStateColorTable superTabControlBoxStateColorTable1 = new DevComponents.DotNetBar.Rendering.SuperTabControlBoxStateColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabPanelColorTable superTabPanelColorTable1 = new DevComponents.DotNetBar.Rendering.SuperTabPanelColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabPanelItemColorTable superTabPanelItemColorTable1 = new DevComponents.DotNetBar.Rendering.SuperTabPanelItemColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable2 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabItemColorTable superTabItemColorTable1 = new DevComponents.DotNetBar.Rendering.SuperTabItemColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabColorStates superTabColorStates1 = new DevComponents.DotNetBar.Rendering.SuperTabColorStates();
            DevComponents.DotNetBar.Rendering.SuperTabItemStateColorTable superTabItemStateColorTable1 = new DevComponents.DotNetBar.Rendering.SuperTabItemStateColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable3 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabPanelColorTable superTabPanelColorTable2 = new DevComponents.DotNetBar.Rendering.SuperTabPanelColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabPanelItemColorTable superTabPanelItemColorTable2 = new DevComponents.DotNetBar.Rendering.SuperTabPanelItemColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable4 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabItemColorTable superTabItemColorTable2 = new DevComponents.DotNetBar.Rendering.SuperTabItemColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabColorStates superTabColorStates2 = new DevComponents.DotNetBar.Rendering.SuperTabColorStates();
            DevComponents.DotNetBar.Rendering.SuperTabItemStateColorTable superTabItemStateColorTable2 = new DevComponents.DotNetBar.Rendering.SuperTabItemStateColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable5 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabPanelColorTable superTabPanelColorTable3 = new DevComponents.DotNetBar.Rendering.SuperTabPanelColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabPanelItemColorTable superTabPanelItemColorTable3 = new DevComponents.DotNetBar.Rendering.SuperTabPanelItemColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable6 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabItemColorTable superTabItemColorTable3 = new DevComponents.DotNetBar.Rendering.SuperTabItemColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabColorStates superTabColorStates3 = new DevComponents.DotNetBar.Rendering.SuperTabColorStates();
            DevComponents.DotNetBar.Rendering.SuperTabItemStateColorTable superTabItemStateColorTable3 = new DevComponents.DotNetBar.Rendering.SuperTabItemStateColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable7 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabPanelColorTable superTabPanelColorTable4 = new DevComponents.DotNetBar.Rendering.SuperTabPanelColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabPanelItemColorTable superTabPanelItemColorTable4 = new DevComponents.DotNetBar.Rendering.SuperTabPanelItemColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable8 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabItemColorTable superTabItemColorTable4 = new DevComponents.DotNetBar.Rendering.SuperTabItemColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabColorStates superTabColorStates4 = new DevComponents.DotNetBar.Rendering.SuperTabColorStates();
            DevComponents.DotNetBar.Rendering.SuperTabItemStateColorTable superTabItemStateColorTable4 = new DevComponents.DotNetBar.Rendering.SuperTabItemStateColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable9 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            DevComponents.DotNetBar.SuperGrid.Style.Background background1 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background2 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.Background background3 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.SuperGrid.Style.BorderColor borderColor1 = new DevComponents.DotNetBar.SuperGrid.Style.BorderColor();
            DevComponents.DotNetBar.SuperGrid.Style.BorderColor borderColor2 = new DevComponents.DotNetBar.SuperGrid.Style.BorderColor();
            DevComponents.DotNetBar.SuperGrid.Style.BaseTreeButtonVisualStyle baseTreeButtonVisualStyle1 = new DevComponents.DotNetBar.SuperGrid.Style.BaseTreeButtonVisualStyle();
            DevComponents.DotNetBar.SuperGrid.Style.BaseTreeButtonVisualStyle baseTreeButtonVisualStyle2 = new DevComponents.DotNetBar.SuperGrid.Style.BaseTreeButtonVisualStyle();
            DevComponents.DotNetBar.SuperGrid.Style.Background background4 = new DevComponents.DotNetBar.SuperGrid.Style.Background();
            DevComponents.DotNetBar.Rendering.SuperTabColorTable superTabColorTable2 = new DevComponents.DotNetBar.Rendering.SuperTabColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable10 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabColorTable superTabColorTable3 = new DevComponents.DotNetBar.Rendering.SuperTabColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable11 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            this.ToolStripMenuItem_Rep = new System.Windows.Forms.ToolStripMenuItem();
            this.ribbonBar1 = new DevComponents.DotNetBar.RibbonBar();
            this.FlxPrice = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.panelBalance = new System.Windows.Forms.Panel();
            this.textBox_AccBalance = new System.Windows.Forms.TextBox();
            this.labelBalance = new System.Windows.Forms.Label();
            this.switchButton_IfPrint = new DevComponents.DotNetBar.Controls.SwitchButton();
            this.switchButton_PointActiv = new DevComponents.DotNetBar.Controls.SwitchButton();
            this.FlxSerial = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.labelPharmacy3 = new System.Windows.Forms.Label();
            this.labelPharmacy2 = new System.Windows.Forms.Label();
            this.labelPharmacy1 = new System.Windows.Forms.Label();
            this.button_CreatMedical = new DevComponents.DotNetBar.ButtonX();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.superTabStrip_ORders = new DevComponents.DotNetBar.SuperTabStrip();
            this.superTabItem1 = new DevComponents.DotNetBar.SuperTabItem();
            this.c1BarCode1 = new C1.Win.C1BarCode.C1BarCode();
            this.button_GoodsDisbursedInv = new DevComponents.DotNetBar.ButtonX();
            this.txtInvCost = new DevComponents.Editors.DoubleInput();
            this.txtCustNet = new DevComponents.Editors.DoubleInput();
            this.txtCustRep = new DevComponents.Editors.DoubleInput();
            this.textBox2 = new DevComponents.Editors.DoubleInput();
            this.textBox1 = new DevComponents.Editors.DoubleInput();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.txtItemName = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtDiscountVal = new DevComponents.Editors.DoubleInput();
            this.txtTotTax = new DevComponents.Editors.DoubleInput();
            this.pictureBox_Credit = new System.Windows.Forms.PictureBox();
            this.pictureBox_Cash = new System.Windows.Forms.PictureBox();
            this.pictureBox_NetWord = new System.Windows.Forms.PictureBox();
            this.CmbUsers = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.controlContainerItem2 = new DevComponents.DotNetBar.ControlContainerItem();
            this.controlContainerItem3 = new DevComponents.DotNetBar.ControlContainerItem();
            this.checkBox_NetWork = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.checkBox_Chash = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.button_SrchCustADD = new DevComponents.DotNetBar.ButtonX();
            this.button_SrchCustPoints = new DevComponents.DotNetBar.ButtonX();
            this.txtDiscoundPointsLoc = new DevComponents.Editors.DoubleInput();
            this.txtDiscoundPoints = new DevComponents.Editors.DoubleInput();
            this.label40 = new System.Windows.Forms.Label();
            this.buttonItem_POSReturn = new DevComponents.DotNetBar.ButtonX();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDueAmountLoc = new DevComponents.Editors.DoubleInput();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBox_Credit = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.label33 = new System.Windows.Forms.Label();
            this.txtTotTaxLoc = new DevComponents.Editors.DoubleInput();
            this.label17 = new System.Windows.Forms.Label();
            this.txtTotalAm = new DevComponents.Editors.DoubleInput();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.MndobCommValue = new DevComponents.Editors.DoubleInput();
            this.label55 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.txtGDate = new System.Windows.Forms.MaskedTextBox();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.txtHDate = new System.Windows.Forms.MaskedTextBox();
            this.txtTime = new System.Windows.Forms.MaskedTextBox();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.CmbLegate = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.CmbInvSide = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.CmbCostC = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.label5 = new System.Windows.Forms.Label();
            this.CmbInvPrice = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.textBox_ID = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.switchButton_Lock = new DevComponents.DotNetBar.Controls.SwitchButton();
            this.button_SrchInvNoBarcod = new DevComponents.DotNetBar.ButtonX();
            this.splitContainer9 = new System.Windows.Forms.SplitContainer();
            this.txtRef = new System.Windows.Forms.TextBox();
            this.label_Pay = new DevComponents.DotNetBar.ButtonX();
            this.label18 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.txtCustNo = new System.Windows.Forms.TextBox();
            this.splitContainer13 = new System.Windows.Forms.SplitContainer();
            this.button_SrchCustNo = new DevComponents.DotNetBar.ButtonX();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Detials_CarPanel = new System.Windows.Forms.Panel();
            this.Txt_Email = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Label_Mobile = new System.Windows.Forms.Label();
            this.splitContainer11 = new System.Windows.Forms.SplitContainer();
            this.text_Mobile = new System.Windows.Forms.TextBox();
            this.splitContainer12 = new System.Windows.Forms.SplitContainer();
            this.label12 = new System.Windows.Forms.Label();
            this.txtTele = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.CmbCarComp = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.TxtPlateNo = new System.Windows.Forms.MaskedTextBox();
            this.splitContainer14 = new System.Windows.Forms.SplitContainer();
            this.cmbColors = new System.Windows.Forms.ComboBox();
            this.splitContainer15 = new System.Windows.Forms.SplitContainer();
            this.label53 = new System.Windows.Forms.Label();
            this.DeleveryDatePickers = new System.Windows.Forms.DateTimePicker();
            this.CmbCarType = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.label36 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.TxtChessNum = new System.Windows.Forms.TextBox();
            this.TxtCarModel = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.Label26 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.txtDiscountValLoc = new DevComponents.Editors.DoubleInput();
            this.txtDiscountP = new DevComponents.Editors.DoubleInput();
            this.CmbCurr = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.doubleInput_Rate = new DevComponents.Editors.DoubleInput();
            this.txtDueAmount = new DevComponents.Editors.DoubleInput();
            this.label3 = new System.Windows.Forms.Label();
            this.FlxDat = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.FlxInv = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.superTabControl_Info = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel3 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.label32 = new System.Windows.Forms.Label();
            this.txtVSerial = new System.Windows.Forms.TextBox();
            this.txtUnit = new System.Windows.Forms.TextBox();
            this.txtLPrice = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtLCost = new System.Windows.Forms.TextBox();
            this.txtVCost = new System.Windows.Forms.TextBox();
            this.FlxStkQty = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.txtLocItem = new System.Windows.Forms.TextBox();
            this.dataGridView_ItemDet = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.txtPointCount = new DevComponents.Editors.DoubleInput();
            this.superTabItem_items = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel1 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.superTabControlPanel9 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.superTabControlPanel5 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.superTabControl_CostSts = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel11 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.button_CustC1 = new DevComponents.DotNetBar.ButtonX();
            this.panelBalanceBottom = new System.Windows.Forms.Panel();
            this.textBox_AccBalanceBottom = new System.Windows.Forms.TextBox();
            this.labelBalanceBottom = new System.Windows.Forms.Label();
            this.button_CustC3 = new DevComponents.DotNetBar.ButtonX();
            this.button_CustC2 = new DevComponents.DotNetBar.ButtonX();
            this.txtDebit2 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtCredit1 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.doubleInput_NetWorkLoc = new DevComponents.Editors.DoubleInput();
            this.txtCredit2 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtPaymentLoc = new DevComponents.Editors.DoubleInput();
            this.txtCredit3 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelC1 = new System.Windows.Forms.Label();
            this.doubleInput_CreditLoc = new DevComponents.Editors.DoubleInput();
            this.label14 = new System.Windows.Forms.Label();
            this.labelC2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelC3 = new System.Windows.Forms.Label();
            this.txtDebit1 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.button_CustD1 = new DevComponents.DotNetBar.ButtonX();
            this.txtDebit3 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelD1 = new System.Windows.Forms.Label();
            this.labelD3 = new System.Windows.Forms.Label();
            this.button_CustD3 = new DevComponents.DotNetBar.ButtonX();
            this.button_CustD2 = new DevComponents.DotNetBar.ButtonX();
            this.labelD2 = new System.Windows.Forms.Label();
            this.superTabItem_Pay = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel7 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.switchButton_Dis = new DevComponents.DotNetBar.Controls.SwitchButton();
            this.label31 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.txtCredit6 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtDebit6 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.label39 = new System.Windows.Forms.Label();
            this.txtTotDis = new DevComponents.Editors.DoubleInput();
            this.txtTotDisLoc = new DevComponents.Editors.DoubleInput();
            this.checkBox_GaidDis = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.superTabItem_Dis = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel6 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.switchButton_Tax = new DevComponents.DotNetBar.Controls.SwitchButton();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.button_CustC5 = new DevComponents.DotNetBar.ButtonX();
            this.txtCredit5 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.button_CustD5 = new DevComponents.DotNetBar.ButtonX();
            this.txtDebit5 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.checkBox_CostGaidTax = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.superTabItem_Tax = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel8 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.label48 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.txtCredit7 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.label49 = new System.Windows.Forms.Label();
            this.txtTotBankComm = new DevComponents.Editors.DoubleInput();
            this.txtTotBankCommLoc = new DevComponents.Editors.DoubleInput();
            this.checkBox_GaidBankComm = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.switchButton_BankComm = new DevComponents.DotNetBar.Controls.SwitchButton();
            this.superTabItem_LocalComm = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel10 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.txtCredit8 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX4 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.label47 = new System.Windows.Forms.Label();
            this.switchButton_TaxLines = new DevComponents.DotNetBar.SwitchButtonItem();
            this.switchButton_TaxByTotal = new DevComponents.DotNetBar.SwitchButtonItem();
            this.switchButton_TaxByNet = new DevComponents.DotNetBar.SwitchButtonItem();
            this.textBoxItem_TaxByNetValue = new DevComponents.DotNetBar.TextBoxItem();
            this.labelItem_TaxByNetPer = new DevComponents.DotNetBar.LabelItem();
            this.ChkPriceIncludeTax = new DevComponents.DotNetBar.SwitchButtonItem();
            this.superTabItem_Gaids = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel2 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.txtSteel = new DevComponents.Editors.DoubleInput();
            this.txtPayment = new DevComponents.Editors.DoubleInput();
            this.label_LockeName = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.doubleInput_LostOrWin = new DevComponents.Editors.DoubleInput();
            this.label28 = new System.Windows.Forms.Label();
            this.txtTotalQ = new DevComponents.Editors.DoubleInput();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox_Usr = new System.Windows.Forms.TextBox();
            this.label_Curr = new System.Windows.Forms.Label();
            this.superTabItem_Detiles = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel4 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtDueDate = new System.Windows.Forms.MaskedTextBox();
            this.labelPharmcy4 = new System.Windows.Forms.Label();
            this.label_Pharmacy5 = new System.Windows.Forms.Label();
            this.txtAllExchanged = new DevComponents.Editors.DoubleInput();
            this.txtRemark = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.label_Due = new System.Windows.Forms.Label();
            this.superTabItem_Note = new DevComponents.DotNetBar.SuperTabItem();
            this.checkBoxItem_BarCode = new DevComponents.DotNetBar.CheckBoxItem();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ToolStripMenuItem_Det = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.timerInfoBallon = new System.Windows.Forms.Timer(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.panelEx3 = new DevComponents.DotNetBar.PanelEx();
            this.DGV_Main = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.ribbonBar_DGV = new DevComponents.DotNetBar.RibbonBar();
            this.superTabControl_DGV = new DevComponents.DotNetBar.SuperTabControl();
            this.textBox_search = new DevComponents.DotNetBar.TextBoxItem();
            this.Button_ExportTable2 = new DevComponents.DotNetBar.ButtonItem();
            this.Button_PrintTable = new DevComponents.DotNetBar.ButtonItem();
            this.Button_PrintTableMulti = new DevComponents.DotNetBar.ButtonItem();
            this.labelItem3 = new DevComponents.DotNetBar.LabelItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelEx2 = new DevComponents.DotNetBar.PanelEx();
            this.ribbonBar_Tasks = new DevComponents.DotNetBar.RibbonBar();
            this.superTabControl_Main1 = new DevComponents.DotNetBar.SuperTabControl();
            this.Button_BarcodPrint = new DevComponents.DotNetBar.ButtonItem();
            this.ButReturn = new DevComponents.DotNetBar.ButtonItem();
            this.ButReturnShow = new DevComponents.DotNetBar.ButtonItem();
            this.ButPurchaseShow = new DevComponents.DotNetBar.ButtonItem();
            this.ButOutGoodShow = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem1 = new DevComponents.DotNetBar.ButtonItem();
            this.ButEnterGoodShow = new DevComponents.DotNetBar.ButtonItem();
            this.button_Repetition = new DevComponents.DotNetBar.ButtonItem();
            this.Button_Close = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem_Print = new DevComponents.DotNetBar.ButtonItem();
            this.printerSetting = new DevComponents.DotNetBar.ButtonItem();
            this.Button_Search = new DevComponents.DotNetBar.ButtonItem();
            this.Button_Delete = new DevComponents.DotNetBar.ButtonItem();
            this.Button_Save = new DevComponents.DotNetBar.ButtonItem();
            this.Button_Add = new DevComponents.DotNetBar.ButtonItem();
            this.ChkA4Cahir = new DevComponents.DotNetBar.CheckBoxItem();
            this.buttonItem2 = new DevComponents.DotNetBar.ButtonItem();
            this.superTabControl_Main2 = new DevComponents.DotNetBar.SuperTabControl();
            this.buttonShowKiewd = new DevComponents.DotNetBar.ButtonItem();
            this.labelItem1 = new DevComponents.DotNetBar.LabelItem();
            this.Button_First = new DevComponents.DotNetBar.ButtonItem();
            this.Button_Prev = new DevComponents.DotNetBar.ButtonItem();
            this.TextBox_Index = new DevComponents.DotNetBar.TextBoxItem();
            this.Label_Count = new DevComponents.DotNetBar.LabelItem();
            this.lable_Records = new DevComponents.DotNetBar.LabelItem();
            this.Button_Next = new DevComponents.DotNetBar.ButtonItem();
            this.Button_Last = new DevComponents.DotNetBar.ButtonItem();
            this.expandableSplitter1 = new DevComponents.DotNetBar.ExpandableSplitter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_opendraft = new DevComponents.DotNetBar.ButtonX();
            this.button_Draft = new DevComponents.DotNetBar.ButtonX();
            this.prnt_prev = new System.Windows.Forms.PrintPreviewDialog();
            this.prnt_doc = new System.Drawing.Printing.PrintDocument();
            this.controlContainerItem1 = new DevComponents.DotNetBar.ControlContainerItem();
            this.prnt_doc2 = new System.Drawing.Printing.PrintDocument();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.FlxInvToCopy = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.CarPanelDet = new System.Windows.Forms.Panel();
            this.txtTotalAmLoc = new DevComponents.Editors.DoubleInput();
            this.InvDetailsPanel = new System.Windows.Forms.Panel();
            this.TableLayOutOFKewd = new System.Windows.Forms.TableLayoutPanel();
            this.kiewadbuttonspanel = new System.Windows.Forms.FlowLayoutPanel();
            this.TableLayoutOFALLControls = new System.Windows.Forms.TableLayoutPanel();
            this.ribbonBar1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FlxPrice)).BeginInit();
            this.panelBalance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FlxSerial)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.superTabStrip_ORders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInvCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCustNet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCustRep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiscountVal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotTax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Credit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Cash)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_NetWord)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiscoundPointsLoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiscoundPoints)).BeginInit();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDueAmountLoc)).BeginInit();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotTaxLoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalAm)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MndobCommValue)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.splitContainer9.Panel1.SuspendLayout();
            this.splitContainer9.Panel2.SuspendLayout();
            this.splitContainer9.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.splitContainer13.Panel1.SuspendLayout();
            this.splitContainer13.Panel2.SuspendLayout();
            this.splitContainer13.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Detials_CarPanel.SuspendLayout();
            this.splitContainer11.Panel1.SuspendLayout();
            this.splitContainer11.Panel2.SuspendLayout();
            this.splitContainer11.SuspendLayout();
            this.splitContainer12.Panel1.SuspendLayout();
            this.splitContainer12.Panel2.SuspendLayout();
            this.splitContainer12.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.splitContainer14.Panel1.SuspendLayout();
            this.splitContainer14.Panel2.SuspendLayout();
            this.splitContainer14.SuspendLayout();
            this.splitContainer15.Panel1.SuspendLayout();
            this.splitContainer15.Panel2.SuspendLayout();
            this.splitContainer15.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiscountValLoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiscountP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_Rate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDueAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FlxDat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FlxInv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_Info)).BeginInit();
            this.superTabControl_Info.SuspendLayout();
            this.superTabControlPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FlxStkQty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ItemDet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPointCount)).BeginInit();
            this.superTabControlPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_CostSts)).BeginInit();
            this.superTabControl_CostSts.SuspendLayout();
            this.superTabControlPanel11.SuspendLayout();
            this.panelBalanceBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_NetWorkLoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaymentLoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_CreditLoc)).BeginInit();
            this.superTabControlPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotDis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotDisLoc)).BeginInit();
            this.superTabControlPanel6.SuspendLayout();
            this.superTabControlPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotBankComm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotBankCommLoc)).BeginInit();
            this.superTabControlPanel10.SuspendLayout();
            this.superTabControlPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSteel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_LostOrWin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalQ)).BeginInit();
            this.superTabControlPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtAllExchanged)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            this.panelEx3.SuspendLayout();
            this.ribbonBar_DGV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_DGV)).BeginInit();
            this.panelEx2.SuspendLayout();
            this.ribbonBar_Tasks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_Main1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_Main2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FlxInvToCopy)).BeginInit();
            this.CarPanelDet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalAmLoc)).BeginInit();
            this.InvDetailsPanel.SuspendLayout();
            this.TableLayOutOFKewd.SuspendLayout();
            this.kiewadbuttonspanel.SuspendLayout();
            this.TableLayoutOFALLControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // ToolStripMenuItem_Rep
            // 
            this.ToolStripMenuItem_Rep.Checked = true;
            this.ToolStripMenuItem_Rep.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ToolStripMenuItem_Rep.Name = "ToolStripMenuItem_Rep";
            this.ToolStripMenuItem_Rep.Size = new System.Drawing.Size(148, 22);
            this.ToolStripMenuItem_Rep.Text = "إظهار التقرير";
            // 
            // ribbonBar1
            // 
            this.ribbonBar1.AutoOverflowEnabled = true;
            this.ribbonBar1.BackColor = System.Drawing.Color.Gainsboro;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundStyle.BackColor = System.Drawing.Color.Gainsboro;
            this.ribbonBar1.BackgroundStyle.BackColor2 = System.Drawing.Color.Gainsboro;
            this.ribbonBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar1.ContainerControlProcessDialogKey = true;
            this.ribbonBar1.Controls.Add(this.FlxPrice);
            this.ribbonBar1.Controls.Add(this.panelBalance);
            this.ribbonBar1.Controls.Add(this.switchButton_IfPrint);
            this.ribbonBar1.Controls.Add(this.switchButton_PointActiv);
            this.ribbonBar1.Controls.Add(this.FlxSerial);
            this.ribbonBar1.Controls.Add(this.labelPharmacy3);
            this.ribbonBar1.Controls.Add(this.labelPharmacy2);
            this.ribbonBar1.Controls.Add(this.labelPharmacy1);
            this.ribbonBar1.Controls.Add(this.button_CreatMedical);
            this.ribbonBar1.Controls.Add(this.groupBox5);
            this.ribbonBar1.Controls.Add(this.superTabStrip_ORders);
            this.ribbonBar1.Controls.Add(this.c1BarCode1);
            this.ribbonBar1.Controls.Add(this.button_GoodsDisbursedInv);
            this.ribbonBar1.Controls.Add(this.txtInvCost);
            this.ribbonBar1.Controls.Add(this.txtCustNet);
            this.ribbonBar1.Controls.Add(this.txtCustRep);
            this.ribbonBar1.Controls.Add(this.textBox2);
            this.ribbonBar1.Controls.Add(this.textBox1);
            this.ribbonBar1.Controls.Add(this.textBox3);
            this.ribbonBar1.Controls.Add(this.txtItemName);
            this.ribbonBar1.Controls.Add(this.groupBox1);
            this.ribbonBar1.Controls.Add(this.pictureBox_Credit);
            this.ribbonBar1.Controls.Add(this.pictureBox_Cash);
            this.ribbonBar1.Controls.Add(this.pictureBox_NetWord);
            this.ribbonBar1.Controls.Add(this.CmbUsers);
            this.ribbonBar1.DragDropSupport = true;
            this.ribbonBar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.controlContainerItem2,
            this.controlContainerItem3});
            this.ribbonBar1.Location = new System.Drawing.Point(0, 116);
            this.ribbonBar1.Name = "ribbonBar1";
            this.ribbonBar1.Size = new System.Drawing.Size(1261, 458);
            this.ribbonBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.OfficeXP;
            this.ribbonBar1.TabIndex = 867;
            this.ribbonBar1.Tag = "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            // 
            // 
            // 
            this.ribbonBar1.TitleStyle.BackColor = System.Drawing.Color.Black;
            this.ribbonBar1.TitleStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(147)))), ((int)(((byte)(207)))));
            this.ribbonBar1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar1.ItemClick += new System.EventHandler(this.ribbonBar1_ItemClick);
            // 
            // FlxPrice
            // 
            this.FlxPrice.AllowEditing = false;
            this.FlxPrice.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.FlxPrice.ColumnInfo = resources.GetString("FlxPrice.ColumnInfo");
            this.FlxPrice.Font = new System.Drawing.Font("Tahoma", 8F);
            this.FlxPrice.Location = new System.Drawing.Point(17, 217);
            this.FlxPrice.Name = "FlxPrice";
            this.FlxPrice.Rows.Count = 6;
            this.FlxPrice.Rows.DefaultSize = 19;
            this.FlxPrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.FlxPrice.Size = new System.Drawing.Size(176, 118);
            this.FlxPrice.StyleInfo = resources.GetString("FlxPrice.StyleInfo");
            this.FlxPrice.TabIndex = 1224;
            this.FlxPrice.Visible = false;
            this.FlxPrice.VisualStyle = C1.Win.C1FlexGrid.VisualStyle.Office2007Black;
            // 
            // panelBalance
            // 
            this.panelBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelBalance.Controls.Add(this.textBox_AccBalance);
            this.panelBalance.Controls.Add(this.labelBalance);
            this.panelBalance.Location = new System.Drawing.Point(352, 265);
            this.panelBalance.Name = "panelBalance";
            this.panelBalance.Size = new System.Drawing.Size(393, 51);
            this.panelBalance.TabIndex = 1223;
            this.panelBalance.Visible = false;
            // 
            // textBox_AccBalance
            // 
            this.textBox_AccBalance.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.textBox_AccBalance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_AccBalance.Font = new System.Drawing.Font("Tahoma", 15F);
            this.textBox_AccBalance.ForeColor = System.Drawing.Color.White;
            this.textBox_AccBalance.Location = new System.Drawing.Point(0, 0);
            this.textBox_AccBalance.Multiline = true;
            this.textBox_AccBalance.Name = "textBox_AccBalance";
            this.textBox_AccBalance.ReadOnly = true;
            this.textBox_AccBalance.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_AccBalance.Size = new System.Drawing.Size(306, 49);
            this.textBox_AccBalance.TabIndex = 1094;
            this.textBox_AccBalance.Text = "0";
            this.textBox_AccBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_AccBalance.TextChanged += new System.EventHandler(this.textBox_AccBalance_TextChanged);
            // 
            // labelBalance
            // 
            this.labelBalance.BackColor = System.Drawing.Color.Red;
            this.labelBalance.Dock = System.Windows.Forms.DockStyle.Right;
            this.labelBalance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelBalance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelBalance.ForeColor = System.Drawing.Color.White;
            this.labelBalance.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelBalance.Location = new System.Drawing.Point(306, 0);
            this.labelBalance.Name = "labelBalance";
            this.labelBalance.Size = new System.Drawing.Size(85, 49);
            this.labelBalance.TabIndex = 1093;
            this.labelBalance.Text = "الرصيـــــــد ";
            this.labelBalance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labelBalance.Click += new System.EventHandler(this.labelBalance_Click);
            // 
            // switchButton_IfPrint
            // 
            // 
            // 
            // 
            this.switchButton_IfPrint.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.switchButton_IfPrint.Font = new System.Drawing.Font("Tahoma", 7F);
            this.switchButton_IfPrint.Location = new System.Drawing.Point(-134, 86);
            this.switchButton_IfPrint.Name = "switchButton_IfPrint";
            this.switchButton_IfPrint.OffBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(80)))), ((int)(((byte)(77)))));
            this.switchButton_IfPrint.OffText = "غير جاهز";
            this.switchButton_IfPrint.OffTextColor = System.Drawing.Color.White;
            this.switchButton_IfPrint.OnText = "جاهز";
            this.switchButton_IfPrint.Size = new System.Drawing.Size(121, 20);
            this.switchButton_IfPrint.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.switchButton_IfPrint.SwitchWidth = 22;
            this.switchButton_IfPrint.TabIndex = 1225;
            this.switchButton_IfPrint.Visible = false;
            // 
            // switchButton_PointActiv
            // 
            // 
            // 
            // 
            this.switchButton_PointActiv.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.switchButton_PointActiv.Font = new System.Drawing.Font("Tahoma", 7F);
            this.switchButton_PointActiv.Location = new System.Drawing.Point(273, 191);
            this.switchButton_PointActiv.Name = "switchButton_PointActiv";
            this.switchButton_PointActiv.OffBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(80)))), ((int)(((byte)(77)))));
            this.switchButton_PointActiv.OffText = "النقاط";
            this.switchButton_PointActiv.OffTextColor = System.Drawing.Color.White;
            this.switchButton_PointActiv.OnText = "النقاط";
            this.switchButton_PointActiv.Size = new System.Drawing.Size(73, 21);
            this.switchButton_PointActiv.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.switchButton_PointActiv.SwitchWidth = 22;
            this.switchButton_PointActiv.TabIndex = 1222;
            this.switchButton_PointActiv.ValueChanged += new System.EventHandler(this.switchButton_PointActiv_ValueChanged);
            // 
            // FlxSerial
            // 
            this.FlxSerial.AllowEditing = false;
            this.FlxSerial.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.FlxSerial.ColumnInfo = resources.GetString("FlxSerial.ColumnInfo");
            this.FlxSerial.Font = new System.Drawing.Font("Tahoma", 8F);
            this.FlxSerial.Location = new System.Drawing.Point(179, 218);
            this.FlxSerial.Name = "FlxSerial";
            this.FlxSerial.Rows.DefaultSize = 19;
            this.FlxSerial.Size = new System.Drawing.Size(229, 96);
            this.FlxSerial.StyleInfo = resources.GetString("FlxSerial.StyleInfo");
            this.FlxSerial.TabIndex = 1213;
            this.FlxSerial.Visible = false;
            this.FlxSerial.VisualStyle = C1.Win.C1FlexGrid.VisualStyle.Office2007Black;
            // 
            // labelPharmacy3
            // 
            this.labelPharmacy3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelPharmacy3.AutoSize = true;
            this.labelPharmacy3.BackColor = System.Drawing.Color.Transparent;
            this.labelPharmacy3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPharmacy3.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelPharmacy3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelPharmacy3.Location = new System.Drawing.Point(601, -104);
            this.labelPharmacy3.Name = "labelPharmacy3";
            this.labelPharmacy3.Size = new System.Drawing.Size(22, 13);
            this.labelPharmacy3.TabIndex = 1212;
            this.labelPharmacy3.Text = "يوم";
            // 
            // labelPharmacy2
            // 
            this.labelPharmacy2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelPharmacy2.AutoSize = true;
            this.labelPharmacy2.BackColor = System.Drawing.Color.Transparent;
            this.labelPharmacy2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPharmacy2.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelPharmacy2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelPharmacy2.Location = new System.Drawing.Point(715, -88);
            this.labelPharmacy2.Name = "labelPharmacy2";
            this.labelPharmacy2.Size = new System.Drawing.Size(78, 13);
            this.labelPharmacy2.TabIndex = 1211;
            this.labelPharmacy2.Text = "يوم ,يصرف منها";
            // 
            // labelPharmacy1
            // 
            this.labelPharmacy1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelPharmacy1.AutoSize = true;
            this.labelPharmacy1.BackColor = System.Drawing.Color.Transparent;
            this.labelPharmacy1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPharmacy1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelPharmacy1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelPharmacy1.Location = new System.Drawing.Point(807, -104);
            this.labelPharmacy1.Name = "labelPharmacy1";
            this.labelPharmacy1.Size = new System.Drawing.Size(61, 13);
            this.labelPharmacy1.TabIndex = 1210;
            this.labelPharmacy1.Text = "مدة العلاج :";
            // 
            // button_CreatMedical
            // 
            this.button_CreatMedical.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.button_CreatMedical.Checked = true;
            this.button_CreatMedical.ColorTable = DevComponents.DotNetBar.eButtonColor.Office2007WithBackground;
            this.button_CreatMedical.Location = new System.Drawing.Point(6, 13);
            this.button_CreatMedical.Name = "button_CreatMedical";
            this.button_CreatMedical.Size = new System.Drawing.Size(0, 0);
            this.button_CreatMedical.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_CreatMedical.Symbol = "";
            this.button_CreatMedical.SymbolSize = 20F;
            this.button_CreatMedical.TabIndex = 1207;
            this.button_CreatMedical.TextColor = System.Drawing.Color.SteelBlue;
            this.button_CreatMedical.Click += new System.EventHandler(this.button_CreatMedical_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox5.Location = new System.Drawing.Point(-13, 191);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox5.Size = new System.Drawing.Size(263, 50);
            this.groupBox5.TabIndex = 1022;
            this.groupBox5.TabStop = false;
            // 
            // superTabStrip_ORders
            // 
            this.superTabStrip_ORders.AutoSelectAttachedControl = false;
            this.superTabStrip_ORders.BackColor = System.Drawing.Color.Gainsboro;
            // 
            // 
            // 
            this.superTabStrip_ORders.BackgroundStyle.BackColor = System.Drawing.Color.Gainsboro;
            this.superTabStrip_ORders.BackgroundStyle.BackColor2 = System.Drawing.Color.Gainsboro;
            this.superTabStrip_ORders.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.superTabStrip_ORders.ContainerControlProcessDialogKey = true;
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabStrip_ORders.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabStrip_ORders.ControlBox.MenuBox.Name = "";
            this.superTabStrip_ORders.ControlBox.Name = "";
            this.superTabStrip_ORders.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabStrip_ORders.ControlBox.MenuBox,
            this.superTabStrip_ORders.ControlBox.CloseBox});
            this.superTabStrip_ORders.ControlBox.Visible = false;
            this.superTabStrip_ORders.Location = new System.Drawing.Point(304, 344);
            this.superTabStrip_ORders.Name = "superTabStrip_ORders";
            this.superTabStrip_ORders.ReorderTabsEnabled = true;
            this.superTabStrip_ORders.SelectedTabFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.superTabStrip_ORders.SelectedTabIndex = 0;
            this.superTabStrip_ORders.Size = new System.Drawing.Size(973, 25);
            this.superTabStrip_ORders.TabCloseButtonHot = null;
            this.superTabStrip_ORders.TabFont = new System.Drawing.Font("Tahoma", 8F);
            this.superTabStrip_ORders.TabIndex = 1204;
            this.superTabStrip_ORders.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem1});
            superTabLinearGradientColorTable1.AdaptiveGradient = false;
            superTabLinearGradientColorTable1.Colors = new System.Drawing.Color[] {
        System.Drawing.Color.Gainsboro};
            superTabColorTable1.Background = superTabLinearGradientColorTable1;
            superTabControlBoxStateColorTable1.Background = System.Drawing.Color.Wheat;
            superTabColorTable1.ControlBoxDefault = superTabControlBoxStateColorTable1;
            superTabColorTable1.InnerBorder = System.Drawing.Color.Silver;
            this.superTabStrip_ORders.TabStripColor = superTabColorTable1;
            this.superTabStrip_ORders.Text = "superTabStrip1";
            // 
            // superTabItem1
            // 
            this.superTabItem1.GlobalItem = false;
            this.superTabItem1.Name = "superTabItem1";
            // 
            // c1BarCode1
            // 
            this.c1BarCode1.BarWide = 1;
            this.c1BarCode1.CodeType = C1.Win.C1BarCode.CodeTypeEnum.Code128;
            this.c1BarCode1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.c1BarCode1.Location = new System.Drawing.Point(891, -89);
            this.c1BarCode1.Name = "c1BarCode1";
            this.c1BarCode1.ShowText = true;
            this.c1BarCode1.Size = new System.Drawing.Size(142, 40);
            this.c1BarCode1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.c1BarCode1.TabIndex = 1124;
            this.c1BarCode1.Text = "1225";
            // 
            // button_GoodsDisbursedInv
            // 
            this.button_GoodsDisbursedInv.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.button_GoodsDisbursedInv.Checked = true;
            this.button_GoodsDisbursedInv.ColorTable = DevComponents.DotNetBar.eButtonColor.Office2007WithBackground;
            this.button_GoodsDisbursedInv.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button_GoodsDisbursedInv.Location = new System.Drawing.Point(6, 121);
            this.button_GoodsDisbursedInv.Name = "button_GoodsDisbursedInv";
            this.button_GoodsDisbursedInv.Size = new System.Drawing.Size(340, 63);
            this.button_GoodsDisbursedInv.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_GoodsDisbursedInv.Symbol = "";
            this.button_GoodsDisbursedInv.SymbolSize = 20F;
            this.button_GoodsDisbursedInv.TabIndex = 1094;
            this.button_GoodsDisbursedInv.Text = "فواتير صرف البضاعة";
            this.button_GoodsDisbursedInv.TextColor = System.Drawing.Color.SteelBlue;
            this.button_GoodsDisbursedInv.Visible = false;
            this.button_GoodsDisbursedInv.Click += new System.EventHandler(this.button_GoodsDisbursedInv_Click);
            // 
            // txtInvCost
            // 
            this.txtInvCost.AllowEmptyState = false;
            this.txtInvCost.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtInvCost.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtInvCost.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtInvCost.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtInvCost.DisplayFormat = "0.00";
            this.txtInvCost.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtInvCost.Increment = 0D;
            this.txtInvCost.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtInvCost.IsInputReadOnly = true;
            this.txtInvCost.Location = new System.Drawing.Point(795, 526);
            this.txtInvCost.Name = "txtInvCost";
            this.txtInvCost.Size = new System.Drawing.Size(109, 21);
            this.txtInvCost.TabIndex = 1059;
            // 
            // txtCustNet
            // 
            this.txtCustNet.AllowEmptyState = false;
            this.txtCustNet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtCustNet.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtCustNet.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtCustNet.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtCustNet.DisplayFormat = "0.00";
            this.txtCustNet.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtCustNet.Increment = 0D;
            this.txtCustNet.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtCustNet.IsInputReadOnly = true;
            this.txtCustNet.Location = new System.Drawing.Point(914, 536);
            this.txtCustNet.Name = "txtCustNet";
            this.txtCustNet.Size = new System.Drawing.Size(59, 21);
            this.txtCustNet.TabIndex = 1060;
            // 
            // txtCustRep
            // 
            this.txtCustRep.AllowEmptyState = false;
            this.txtCustRep.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtCustRep.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtCustRep.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtCustRep.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtCustRep.DisplayFormat = "0.00";
            this.txtCustRep.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtCustRep.Increment = 0D;
            this.txtCustRep.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtCustRep.IsInputReadOnly = true;
            this.txtCustRep.Location = new System.Drawing.Point(914, 553);
            this.txtCustRep.Name = "txtCustRep";
            this.txtCustRep.Size = new System.Drawing.Size(117, 21);
            this.txtCustRep.TabIndex = 1061;
            // 
            // textBox2
            // 
            this.textBox2.AllowEmptyState = false;
            this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.textBox2.BackgroundStyle.Class = "DateTimeInputBackground";
            this.textBox2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBox2.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.textBox2.DisplayFormat = "0.00";
            this.textBox2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.textBox2.Increment = 0D;
            this.textBox2.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.textBox2.IsInputReadOnly = true;
            this.textBox2.Location = new System.Drawing.Point(795, 582);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(109, 21);
            this.textBox2.TabIndex = 1063;
            // 
            // textBox1
            // 
            this.textBox1.AllowEmptyState = false;
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.textBox1.BackgroundStyle.Class = "DateTimeInputBackground";
            this.textBox1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBox1.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.textBox1.DisplayFormat = "0.00";
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.textBox1.Increment = 0D;
            this.textBox1.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.textBox1.IsInputReadOnly = true;
            this.textBox1.Location = new System.Drawing.Point(910, 584);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(109, 21);
            this.textBox1.TabIndex = 1056;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(388, 537);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 496;
            // 
            // txtItemName
            // 
            this.txtItemName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(217)))), ((int)(((byte)(243)))));
            this.txtItemName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtItemName.Location = new System.Drawing.Point(442, 198);
            this.txtItemName.Name = "txtItemName";
            this.txtItemName.ReadOnly = true;
            this.txtItemName.Size = new System.Drawing.Size(374, 13);
            this.txtItemName.TabIndex = 1078;
            this.txtItemName.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtDiscountVal);
            this.groupBox1.Controls.Add(this.txtTotTax);
            this.groupBox1.Location = new System.Drawing.Point(5, 380);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(288, 123);
            this.groupBox1.TabIndex = 1079;
            this.groupBox1.TabStop = false;
            // 
            // txtDiscountVal
            // 
            this.txtDiscountVal.AllowEmptyState = false;
            this.txtDiscountVal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtDiscountVal.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtDiscountVal.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDiscountVal.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtDiscountVal.DisplayFormat = "0.00";
            this.txtDiscountVal.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtDiscountVal.Increment = 0D;
            this.txtDiscountVal.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtDiscountVal.Location = new System.Drawing.Point(196, 38);
            this.txtDiscountVal.Name = "txtDiscountVal";
            this.txtDiscountVal.Size = new System.Drawing.Size(85, 21);
            this.txtDiscountVal.TabIndex = 1079;
            // 
            // txtTotTax
            // 
            this.txtTotTax.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtTotTax.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtTotTax.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTotTax.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtTotTax.DisplayFormat = "0.00";
            this.txtTotTax.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtTotTax.Increment = 0D;
            this.txtTotTax.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtTotTax.IsInputReadOnly = true;
            this.txtTotTax.Location = new System.Drawing.Point(110, 82);
            this.txtTotTax.MinValue = 0D;
            this.txtTotTax.Name = "txtTotTax";
            this.txtTotTax.Size = new System.Drawing.Size(85, 21);
            this.txtTotTax.TabIndex = 1141;
            // 
            // pictureBox_Credit
            // 
            this.pictureBox_Credit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_Credit.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Credit.Image")));
            this.pictureBox_Credit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox_Credit.Location = new System.Drawing.Point(5, 121);
            this.pictureBox_Credit.Name = "pictureBox_Credit";
            this.pictureBox_Credit.Size = new System.Drawing.Size(341, 62);
            this.pictureBox_Credit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Credit.TabIndex = 1069;
            this.pictureBox_Credit.TabStop = false;
            this.pictureBox_Credit.Visible = false;
            // 
            // pictureBox_Cash
            // 
            this.pictureBox_Cash.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_Cash.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Cash.Image")));
            this.pictureBox_Cash.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox_Cash.Location = new System.Drawing.Point(6, 122);
            this.pictureBox_Cash.Name = "pictureBox_Cash";
            this.pictureBox_Cash.Size = new System.Drawing.Size(340, 62);
            this.pictureBox_Cash.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Cash.TabIndex = 1068;
            this.pictureBox_Cash.TabStop = false;
            this.pictureBox_Cash.Visible = false;
            // 
            // pictureBox_NetWord
            // 
            this.pictureBox_NetWord.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_NetWord.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_NetWord.Image")));
            this.pictureBox_NetWord.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox_NetWord.Location = new System.Drawing.Point(6, 121);
            this.pictureBox_NetWord.Name = "pictureBox_NetWord";
            this.pictureBox_NetWord.Size = new System.Drawing.Size(341, 62);
            this.pictureBox_NetWord.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_NetWord.TabIndex = 1070;
            this.pictureBox_NetWord.TabStop = false;
            this.pictureBox_NetWord.Visible = false;
            // 
            // CmbUsers
            // 
            this.CmbUsers.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbUsers.DisplayMember = "Text";
            this.CmbUsers.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CmbUsers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbUsers.FormattingEnabled = true;
            this.CmbUsers.ItemHeight = 15;
            this.CmbUsers.Location = new System.Drawing.Point(352, 139);
            this.CmbUsers.Name = "CmbUsers";
            this.CmbUsers.Size = new System.Drawing.Size(230, 21);
            this.CmbUsers.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.CmbUsers.TabIndex = 1119;
            this.CmbUsers.Visible = false;
            // 
            // controlContainerItem2
            // 
            this.controlContainerItem2.AllowItemResize = false;
            this.controlContainerItem2.MenuVisibility = DevComponents.DotNetBar.eMenuVisibility.VisibleAlways;
            this.controlContainerItem2.Name = "controlContainerItem2";
            this.controlContainerItem2.Visible = false;
            // 
            // controlContainerItem3
            // 
            this.controlContainerItem3.AllowItemResize = false;
            this.controlContainerItem3.MenuVisibility = DevComponents.DotNetBar.eMenuVisibility.VisibleAlways;
            this.controlContainerItem3.Name = "controlContainerItem3";
            // 
            // checkBox_NetWork
            // 
            this.checkBox_NetWork.AutoSize = true;
            this.checkBox_NetWork.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.checkBox_NetWork.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.checkBox_NetWork.CheckBoxStyle = DevComponents.DotNetBar.eCheckBoxStyle.RadioButton;
            this.checkBox_NetWork.CheckSignSize = new System.Drawing.Size(14, 14);
            this.checkBox_NetWork.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox_NetWork.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.checkBox_NetWork.Location = new System.Drawing.Point(3, 3);
            this.checkBox_NetWork.Name = "checkBox_NetWork";
            this.checkBox_NetWork.Size = new System.Drawing.Size(63, 16);
            this.checkBox_NetWork.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.checkBox_NetWork.TabIndex = 1022;
            this.checkBox_NetWork.Text = "شبكـــة";
            this.checkBox_NetWork.CheckedChanged += new System.EventHandler(this.checkBox_NetWork_CheckedChanged);
            // 
            // checkBox_Chash
            // 
            this.checkBox_Chash.AutoSize = true;
            this.checkBox_Chash.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.checkBox_Chash.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.checkBox_Chash.BackgroundStyle.TextShadowColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox_Chash.BackgroundStyle.TextShadowOffset = new System.Drawing.Point(3, 3);
            this.checkBox_Chash.CheckBoxStyle = DevComponents.DotNetBar.eCheckBoxStyle.RadioButton;
            this.checkBox_Chash.CheckSignSize = new System.Drawing.Size(14, 14);
            this.checkBox_Chash.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox_Chash.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.checkBox_Chash.Location = new System.Drawing.Point(139, 3);
            this.checkBox_Chash.Name = "checkBox_Chash";
            this.checkBox_Chash.Size = new System.Drawing.Size(60, 16);
            this.checkBox_Chash.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.checkBox_Chash.TabIndex = 15;
            this.checkBox_Chash.Text = "نقـــدي";
            this.checkBox_Chash.CheckedChanged += new System.EventHandler(this.checkBox_Chash_CheckedChanged);
            // 
            // button_SrchCustADD
            // 
            this.button_SrchCustADD.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.button_SrchCustADD.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_SrchCustADD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_SrchCustADD.Location = new System.Drawing.Point(0, 0);
            this.button_SrchCustADD.Name = "button_SrchCustADD";
            this.button_SrchCustADD.Size = new System.Drawing.Size(43, 20);
            this.button_SrchCustADD.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_SrchCustADD.Symbol = "";
            this.button_SrchCustADD.SymbolSize = 12F;
            this.button_SrchCustADD.TabIndex = 1214;
            this.button_SrchCustADD.TextColor = System.Drawing.Color.SteelBlue;
            this.button_SrchCustADD.Tooltip = "إضافة عميل";
            this.button_SrchCustADD.Click += new System.EventHandler(this.button_SrchCustADD_Click);
            // 
            // button_SrchCustPoints
            // 
            this.button_SrchCustPoints.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.button_SrchCustPoints.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_SrchCustPoints.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_SrchCustPoints.Location = new System.Drawing.Point(3, 3);
            this.button_SrchCustPoints.Name = "button_SrchCustPoints";
            this.button_SrchCustPoints.Size = new System.Drawing.Size(54, 17);
            this.button_SrchCustPoints.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_SrchCustPoints.Symbol = "";
            this.button_SrchCustPoints.SymbolSize = 12F;
            this.button_SrchCustPoints.TabIndex = 1221;
            this.button_SrchCustPoints.TextColor = System.Drawing.Color.SteelBlue;
            this.button_SrchCustPoints.Click += new System.EventHandler(this.button_SrchCustPoints_Click);
            // 
            // txtDiscoundPointsLoc
            // 
            this.txtDiscoundPointsLoc.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtDiscoundPointsLoc.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(227)))), ((int)(((byte)(231)))));
            this.txtDiscoundPointsLoc.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtDiscoundPointsLoc.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDiscoundPointsLoc.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtDiscoundPointsLoc.DisplayFormat = "0.00";
            this.txtDiscoundPointsLoc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDiscoundPointsLoc.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txtDiscoundPointsLoc.Increment = 0D;
            this.txtDiscoundPointsLoc.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtDiscoundPointsLoc.IsInputReadOnly = true;
            this.txtDiscoundPointsLoc.Location = new System.Drawing.Point(63, 3);
            this.txtDiscoundPointsLoc.MinValue = 0D;
            this.txtDiscoundPointsLoc.Name = "txtDiscoundPointsLoc";
            this.txtDiscoundPointsLoc.Size = new System.Drawing.Size(135, 21);
            this.txtDiscoundPointsLoc.TabIndex = 1218;
            // 
            // txtDiscoundPoints
            // 
            this.txtDiscoundPoints.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtDiscoundPoints.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtDiscoundPoints.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDiscoundPoints.ButtonClear.Visible = true;
            this.txtDiscoundPoints.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtDiscoundPoints.DisplayFormat = "0.00";
            this.txtDiscoundPoints.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDiscoundPoints.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtDiscoundPoints.Increment = 0D;
            this.txtDiscoundPoints.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtDiscoundPoints.IsInputReadOnly = true;
            this.txtDiscoundPoints.Location = new System.Drawing.Point(204, 3);
            this.txtDiscoundPoints.MinValue = 0D;
            this.txtDiscoundPoints.Name = "txtDiscoundPoints";
            this.txtDiscoundPoints.Size = new System.Drawing.Size(98, 21);
            this.txtDiscoundPoints.TabIndex = 1220;
            this.txtDiscoundPoints.WatermarkAlignment = DevComponents.Editors.eTextAlignment.Center;
            this.txtDiscoundPoints.ValueChanged += new System.EventHandler(this.txtDiscoundPoints_ValueChanged);
            this.txtDiscoundPoints.ButtonClearClick += new System.ComponentModel.CancelEventHandler(this.txtDiscoundPoints_ButtonClearClick);
            // 
            // label40
            // 
            this.label40.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label40.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label40.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.label40.ForeColor = System.Drawing.Color.Black;
            this.label40.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label40.Location = new System.Drawing.Point(314, 130);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(91, 20);
            this.label40.TabIndex = 1219;
            this.label40.Text = "خصم النقـاط";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonItem_POSReturn
            // 
            this.buttonItem_POSReturn.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.buttonItem_POSReturn.Checked = true;
            this.buttonItem_POSReturn.ColorTable = DevComponents.DotNetBar.eButtonColor.Magenta;
            this.buttonItem_POSReturn.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.buttonItem_POSReturn.Location = new System.Drawing.Point(730, 3);
            this.buttonItem_POSReturn.Name = "buttonItem_POSReturn";
            this.buttonItem_POSReturn.Size = new System.Drawing.Size(295, 21);
            this.buttonItem_POSReturn.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonItem_POSReturn.SymbolSize = 12F;
            this.buttonItem_POSReturn.TabIndex = 1217;
            this.buttonItem_POSReturn.Text = "مرتجع";
            this.buttonItem_POSReturn.TextColor = System.Drawing.Color.Navy;
            this.buttonItem_POSReturn.Visible = false;
            this.buttonItem_POSReturn.Click += new System.EventHandler(this.buttonItem_POSReturn_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel10, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel9, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel1, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel2, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel8, 0, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1272, 194);
            this.tableLayoutPanel4.TabIndex = 1229;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 3;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.13876F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.62201F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel10.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.txtDueAmountLoc, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.tableLayoutPanel7, 2, 0);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 168);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(418, 23);
            this.tableLayoutPanel10.TabIndex = 1221;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label9.ForeColor = System.Drawing.Color.Navy;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(341, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 23);
            this.label9.TabIndex = 1092;
            this.label9.Text = "صافي الفاتورة";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDueAmountLoc
            // 
            this.txtDueAmountLoc.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtDueAmountLoc.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.txtDueAmountLoc.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtDueAmountLoc.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDueAmountLoc.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtDueAmountLoc.DisplayFormat = "0.00";
            this.txtDueAmountLoc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDueAmountLoc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtDueAmountLoc.Increment = 0D;
            this.txtDueAmountLoc.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtDueAmountLoc.IsInputReadOnly = true;
            this.txtDueAmountLoc.Location = new System.Drawing.Point(213, 3);
            this.txtDueAmountLoc.Name = "txtDueAmountLoc";
            this.txtDueAmountLoc.Size = new System.Drawing.Size(122, 21);
            this.txtDueAmountLoc.TabIndex = 1089;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 3;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel7.Controls.Add(this.checkBox_Chash, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.checkBox_Credit, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.checkBox_NetWork, 2, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(204, 17);
            this.tableLayoutPanel7.TabIndex = 1093;
            // 
            // checkBox_Credit
            // 
            this.checkBox_Credit.AutoSize = true;
            this.checkBox_Credit.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.checkBox_Credit.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.checkBox_Credit.CheckBoxStyle = DevComponents.DotNetBar.eCheckBoxStyle.RadioButton;
            this.checkBox_Credit.CheckSignSize = new System.Drawing.Size(14, 14);
            this.checkBox_Credit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox_Credit.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.checkBox_Credit.Location = new System.Drawing.Point(71, 3);
            this.checkBox_Credit.Name = "checkBox_Credit";
            this.checkBox_Credit.Size = new System.Drawing.Size(54, 16);
            this.checkBox_Credit.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.checkBox_Credit.TabIndex = 868;
            this.checkBox_Credit.Text = "أجـــل";
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 4;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.Controls.Add(this.label33, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.txtTotTaxLoc, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.label17, 2, 0);
            this.tableLayoutPanel9.Controls.Add(this.txtTotalAm, 3, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(427, 168);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(418, 23);
            this.tableLayoutPanel9.TabIndex = 1220;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.Transparent;
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label33.ForeColor = System.Drawing.Color.Navy;
            this.label33.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label33.Location = new System.Drawing.Point(317, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(98, 23);
            this.label33.TabIndex = 1151;
            this.label33.Text = "الضريبة VAT:";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTotTaxLoc
            // 
            this.txtTotTaxLoc.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtTotTaxLoc.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(227)))), ((int)(((byte)(231)))));
            this.txtTotTaxLoc.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtTotTaxLoc.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTotTaxLoc.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtTotTaxLoc.DisplayFormat = "0.00";
            this.txtTotTaxLoc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTotTaxLoc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtTotTaxLoc.Increment = 0D;
            this.txtTotTaxLoc.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtTotTaxLoc.IsInputReadOnly = true;
            this.txtTotTaxLoc.Location = new System.Drawing.Point(213, 3);
            this.txtTotTaxLoc.MinValue = 0D;
            this.txtTotTaxLoc.Name = "txtTotTaxLoc";
            this.txtTotTaxLoc.Size = new System.Drawing.Size(98, 21);
            this.txtTotTaxLoc.TabIndex = 1142;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label17.ForeColor = System.Drawing.Color.Navy;
            this.label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label17.Location = new System.Drawing.Point(109, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 23);
            this.label17.TabIndex = 1082;
            this.label17.Text = "قيمة الفاتـــورة :";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTotalAm
            // 
            this.txtTotalAm.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtTotalAm.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(227)))), ((int)(((byte)(231)))));
            this.txtTotalAm.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtTotalAm.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTotalAm.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtTotalAm.DisplayFormat = "0.00";
            this.txtTotalAm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTotalAm.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtTotalAm.Increment = 0D;
            this.txtTotalAm.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtTotalAm.IsInputReadOnly = true;
            this.txtTotalAm.Location = new System.Drawing.Point(3, 3);
            this.txtTotalAm.Name = "txtTotalAm";
            this.txtTotalAm.Size = new System.Drawing.Size(100, 21);
            this.txtTotalAm.TabIndex = 1080;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.6235F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 79.3765F));
            this.tableLayoutPanel3.Controls.Add(this.MndobCommValue, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.label55, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.Label1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.Label2, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label7, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label15, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.splitContainer2, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.splitContainer5, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.splitContainer6, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.splitContainer8, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.splitContainer9, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.label18, 0, 3);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(851, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 6;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(418, 159);
            this.tableLayoutPanel3.TabIndex = 1218;
            // 
            // MndobCommValue
            // 
            this.MndobCommValue.AllowEmptyState = false;
            // 
            // 
            // 
            this.MndobCommValue.BackgroundStyle.Class = "DateTimeInputBackground";
            this.MndobCommValue.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.MndobCommValue.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.MndobCommValue.DisplayFormat = "0.00";
            this.MndobCommValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MndobCommValue.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.MndobCommValue.Increment = 0D;
            this.MndobCommValue.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.MndobCommValue.Location = new System.Drawing.Point(3, 107);
            this.MndobCommValue.Name = "MndobCommValue";
            this.MndobCommValue.Size = new System.Drawing.Size(326, 21);
            this.MndobCommValue.TabIndex = 1223;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Bold);
            this.label55.ForeColor = System.Drawing.Color.White;
            this.label55.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label55.Location = new System.Drawing.Point(335, 104);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(80, 26);
            this.label55.TabIndex = 1115;
            this.label55.Text = "عمولة المندوب";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label1
            // 
            this.Label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.Color.Transparent;
            this.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.Label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Label1.Location = new System.Drawing.Point(335, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(66, 13);
            this.Label1.TabIndex = 479;
            this.Label1.Text = "رقم الفاتورة :";
            this.Label1.Click += new System.EventHandler(this.Label1_Click);
            this.Label1.DoubleClick += new System.EventHandler(this.Label1_DoubleClick);
            // 
            // Label2
            // 
            this.Label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label2.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Label2.Location = new System.Drawing.Point(335, 26);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(66, 13);
            this.Label2.TabIndex = 480;
            this.Label2.Text = "التاريــــــــخ :";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(335, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 482;
            this.label7.Text = "رقم المرجع :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(335, 130);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 29);
            this.label15.TabIndex = 497;
            this.label15.Text = "مركز التكلفـــــة ";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(3, 29);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.txtGDate);
            this.splitContainer2.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer2.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer2.Size = new System.Drawing.Size(326, 20);
            this.splitContainer2.SplitterDistance = 163;
            this.splitContainer2.TabIndex = 1218;
            // 
            // txtGDate
            // 
            this.txtGDate.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtGDate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGDate.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txtGDate.Location = new System.Drawing.Point(0, 0);
            this.txtGDate.Mask = "0000/00/00";
            this.txtGDate.Name = "txtGDate";
            this.txtGDate.Size = new System.Drawing.Size(163, 21);
            this.txtGDate.TabIndex = 1093;
            this.txtGDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.txtHDate);
            this.splitContainer3.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.txtTime);
            this.splitContainer3.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer3.Size = new System.Drawing.Size(159, 20);
            this.splitContainer3.SplitterDistance = 105;
            this.splitContainer3.TabIndex = 0;
            // 
            // txtHDate
            // 
            this.txtHDate.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtHDate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtHDate.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txtHDate.Location = new System.Drawing.Point(0, 0);
            this.txtHDate.Mask = "0000/00/00";
            this.txtHDate.Name = "txtHDate";
            this.txtHDate.Size = new System.Drawing.Size(105, 21);
            this.txtHDate.TabIndex = 1094;
            this.txtHDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTime
            // 
            this.txtTime.BackColor = System.Drawing.Color.White;
            this.txtTime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTime.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txtTime.Location = new System.Drawing.Point(0, 0);
            this.txtTime.Mask = "##:##";
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(50, 21);
            this.txtTime.TabIndex = 1095;
            this.txtTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.Location = new System.Drawing.Point(0, 78);
            this.splitContainer5.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer5.Name = "splitContainer5";
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.CmbLegate);
            this.splitContainer5.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer5.Panel1MinSize = 0;
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.CmbInvSide);
            this.splitContainer5.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer5.Size = new System.Drawing.Size(332, 26);
            this.splitContainer5.SplitterDistance = 153;
            this.splitContainer5.TabIndex = 1219;
            // 
            // CmbLegate
            // 
            this.CmbLegate.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbLegate.DisplayMember = "Text";
            this.CmbLegate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CmbLegate.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CmbLegate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbLegate.FormattingEnabled = true;
            this.CmbLegate.ItemHeight = 15;
            this.CmbLegate.Location = new System.Drawing.Point(0, 0);
            this.CmbLegate.Name = "CmbLegate";
            this.CmbLegate.Size = new System.Drawing.Size(153, 21);
            this.CmbLegate.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.CmbLegate.TabIndex = 9;
            // 
            // CmbInvSide
            // 
            this.CmbInvSide.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbInvSide.DisplayMember = "Text";
            this.CmbInvSide.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CmbInvSide.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CmbInvSide.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbInvSide.FormattingEnabled = true;
            this.CmbInvSide.ItemHeight = 15;
            this.CmbInvSide.Location = new System.Drawing.Point(0, 0);
            this.CmbInvSide.Name = "CmbInvSide";
            this.CmbInvSide.Size = new System.Drawing.Size(175, 21);
            this.CmbInvSide.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.CmbInvSide.TabIndex = 1094;
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.Location = new System.Drawing.Point(3, 133);
            this.splitContainer6.Name = "splitContainer6";
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.CmbCostC);
            this.splitContainer6.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.splitContainer7);
            this.splitContainer6.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer6.Size = new System.Drawing.Size(326, 23);
            this.splitContainer6.SplitterDistance = 163;
            this.splitContainer6.TabIndex = 1220;
            // 
            // CmbCostC
            // 
            this.CmbCostC.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbCostC.DisplayMember = "Text";
            this.CmbCostC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CmbCostC.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CmbCostC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCostC.FormattingEnabled = true;
            this.CmbCostC.ItemHeight = 15;
            this.CmbCostC.Location = new System.Drawing.Point(0, 0);
            this.CmbCostC.Name = "CmbCostC";
            this.CmbCostC.Size = new System.Drawing.Size(163, 21);
            this.CmbCostC.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.CmbCostC.TabIndex = 1219;
            // 
            // splitContainer7
            // 
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.Location = new System.Drawing.Point(0, 0);
            this.splitContainer7.Name = "splitContainer7";
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.label5);
            this.splitContainer7.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.CmbInvPrice);
            this.splitContainer7.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer7.Size = new System.Drawing.Size(159, 23);
            this.splitContainer7.SplitterDistance = 94;
            this.splitContainer7.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 13);
            this.label5.TabIndex = 1218;
            this.label5.Text = "السعر المعتمــد :";
            // 
            // CmbInvPrice
            // 
            this.CmbInvPrice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbInvPrice.DisplayMember = "Text";
            this.CmbInvPrice.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CmbInvPrice.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CmbInvPrice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbInvPrice.FormattingEnabled = true;
            this.CmbInvPrice.ItemHeight = 15;
            this.CmbInvPrice.Location = new System.Drawing.Point(0, 0);
            this.CmbInvPrice.Name = "CmbInvPrice";
            this.CmbInvPrice.Size = new System.Drawing.Size(61, 21);
            this.CmbInvPrice.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.CmbInvPrice.TabIndex = 1217;
            // 
            // splitContainer8
            // 
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.Location = new System.Drawing.Point(3, 3);
            this.splitContainer8.Name = "splitContainer8";
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.Controls.Add(this.textBox_ID);
            this.splitContainer8.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.Controls.Add(this.tableLayoutPanel5);
            this.splitContainer8.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer8.Size = new System.Drawing.Size(326, 20);
            this.splitContainer8.SplitterDistance = 162;
            this.splitContainer8.TabIndex = 1221;
            // 
            // textBox_ID
            // 
            // 
            // 
            // 
            this.textBox_ID.Border.Class = "TextBoxBorder";
            this.textBox_ID.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBox_ID.ButtonCustom.Visible = true;
            this.textBox_ID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_ID.Location = new System.Drawing.Point(0, 0);
            this.textBox_ID.Name = "textBox_ID";
            this.textBox_ID.Size = new System.Drawing.Size(162, 20);
            this.textBox_ID.TabIndex = 1228;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.switchButton_Lock, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.button_SrchInvNoBarcod, 1, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(160, 20);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // switchButton_Lock
            // 
            // 
            // 
            // 
            this.switchButton_Lock.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.switchButton_Lock.Font = new System.Drawing.Font("Tahoma", 7F);
            this.switchButton_Lock.Location = new System.Drawing.Point(83, 3);
            this.switchButton_Lock.Name = "switchButton_Lock";
            this.switchButton_Lock.OffBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(80)))), ((int)(((byte)(77)))));
            this.switchButton_Lock.OffText = "لم يتم الموافقة";
            this.switchButton_Lock.OffTextColor = System.Drawing.Color.White;
            this.switchButton_Lock.OnText = "تمت الموافقة";
            this.switchButton_Lock.Size = new System.Drawing.Size(74, 14);
            this.switchButton_Lock.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.switchButton_Lock.TabIndex = 1227;
            // 
            // button_SrchInvNoBarcod
            // 
            this.button_SrchInvNoBarcod.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.button_SrchInvNoBarcod.ColorTable = DevComponents.DotNetBar.eButtonColor.Blue;
            this.button_SrchInvNoBarcod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_SrchInvNoBarcod.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button_SrchInvNoBarcod.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.button_SrchInvNoBarcod.Location = new System.Drawing.Point(3, 3);
            this.button_SrchInvNoBarcod.Name = "button_SrchInvNoBarcod";
            this.button_SrchInvNoBarcod.PopupSide = DevComponents.DotNetBar.ePopupSide.Top;
            this.button_SrchInvNoBarcod.Size = new System.Drawing.Size(74, 14);
            this.button_SrchInvNoBarcod.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_SrchInvNoBarcod.Symbol = "";
            this.button_SrchInvNoBarcod.SymbolSize = 8F;
            this.button_SrchInvNoBarcod.TabIndex = 1226;
            this.button_SrchInvNoBarcod.Text = "بحث";
            this.button_SrchInvNoBarcod.TextColor = System.Drawing.Color.SteelBlue;
            this.button_SrchInvNoBarcod.Click += new System.EventHandler(this.button_SrchInvNoBarcod_Click);
            // 
            // splitContainer9
            // 
            this.splitContainer9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer9.Location = new System.Drawing.Point(3, 55);
            this.splitContainer9.Name = "splitContainer9";
            // 
            // splitContainer9.Panel1
            // 
            this.splitContainer9.Panel1.Controls.Add(this.txtRef);
            this.splitContainer9.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer9.Panel2
            // 
            this.splitContainer9.Panel2.Controls.Add(this.label_Pay);
            this.splitContainer9.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer9.Size = new System.Drawing.Size(326, 20);
            this.splitContainer9.SplitterDistance = 231;
            this.splitContainer9.TabIndex = 1222;
            // 
            // txtRef
            // 
            this.txtRef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtRef.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txtRef.Location = new System.Drawing.Point(0, 0);
            this.txtRef.Name = "txtRef";
            this.txtRef.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtRef.Size = new System.Drawing.Size(231, 21);
            this.txtRef.TabIndex = 7;
            // 
            // label_Pay
            // 
            this.label_Pay.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.label_Pay.Checked = true;
            this.label_Pay.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.label_Pay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_Pay.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.label_Pay.Location = new System.Drawing.Point(0, 0);
            this.label_Pay.Name = "label_Pay";
            this.label_Pay.Size = new System.Drawing.Size(91, 20);
            this.label_Pay.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.label_Pay.SymbolSize = 20F;
            this.label_Pay.TabIndex = 1216;
            this.label_Pay.Text = "تسديد";
            this.label_Pay.TextColor = System.Drawing.Color.SteelBlue;
            this.label_Pay.Visible = false;
            this.label_Pay.Click += new System.EventHandler(this.label_Pay_Click);
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label18.Location = new System.Drawing.Point(335, 78);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 13);
            this.label18.TabIndex = 1048;
            this.label18.Text = "المنـــــدوب :";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.65947F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.34053F));
            this.tableLayoutPanel1.Controls.Add(this.splitContainer4, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtCustName, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtAddress, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Label_Mobile, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.splitContainer11, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label40, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel6, 1, 5);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(427, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(418, 159);
            this.tableLayoutPanel1.TabIndex = 1216;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(3, 3);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.txtCustNo);
            this.splitContainer4.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.splitContainer13);
            this.splitContainer4.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer4.Size = new System.Drawing.Size(305, 20);
            this.splitContainer4.SplitterDistance = 209;
            this.splitContainer4.TabIndex = 0;
            // 
            // txtCustNo
            // 
            this.txtCustNo.BackColor = System.Drawing.Color.White;
            this.txtCustNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCustNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtCustNo.Location = new System.Drawing.Point(0, 0);
            this.txtCustNo.MaxLength = 30;
            this.txtCustNo.Name = "txtCustNo";
            this.txtCustNo.ReadOnly = true;
            this.txtCustNo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtCustNo.Size = new System.Drawing.Size(209, 20);
            this.txtCustNo.TabIndex = 10;
            this.txtCustNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // splitContainer13
            // 
            this.splitContainer13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer13.Location = new System.Drawing.Point(0, 0);
            this.splitContainer13.Name = "splitContainer13";
            // 
            // splitContainer13.Panel1
            // 
            this.splitContainer13.Panel1.Controls.Add(this.button_SrchCustNo);
            this.splitContainer13.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer13.Panel2
            // 
            this.splitContainer13.Panel2.Controls.Add(this.button_SrchCustADD);
            this.splitContainer13.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer13.Size = new System.Drawing.Size(92, 20);
            this.splitContainer13.SplitterDistance = 45;
            this.splitContainer13.TabIndex = 0;
            // 
            // button_SrchCustNo
            // 
            this.button_SrchCustNo.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_SrchCustNo.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_SrchCustNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_SrchCustNo.Location = new System.Drawing.Point(0, 0);
            this.button_SrchCustNo.Name = "button_SrchCustNo";
            this.button_SrchCustNo.Size = new System.Drawing.Size(45, 20);
            this.button_SrchCustNo.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_SrchCustNo.Symbol = "";
            this.button_SrchCustNo.SymbolSize = 12F;
            this.button_SrchCustNo.TabIndex = 11;
            this.button_SrchCustNo.TextColor = System.Drawing.Color.SteelBlue;
            this.button_SrchCustNo.Click += new System.EventHandler(this.button_SrchCustNo_Click_1);
            // 
            // txtCustName
            // 
            this.txtCustName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCustName.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txtCustName.Location = new System.Drawing.Point(3, 29);
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtCustName.Size = new System.Drawing.Size(305, 21);
            this.txtCustName.TabIndex = 12;
            this.txtCustName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Detials_CarPanel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 107);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(305, 20);
            this.panel2.TabIndex = 1217;
            // 
            // Detials_CarPanel
            // 
            this.Detials_CarPanel.Controls.Add(this.Txt_Email);
            this.Detials_CarPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Detials_CarPanel.Location = new System.Drawing.Point(0, 0);
            this.Detials_CarPanel.Name = "Detials_CarPanel";
            this.Detials_CarPanel.Size = new System.Drawing.Size(305, 20);
            this.Detials_CarPanel.TabIndex = 1217;
            // 
            // Txt_Email
            // 
            this.Txt_Email.BackColor = System.Drawing.Color.White;
            this.Txt_Email.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Txt_Email.Location = new System.Drawing.Point(0, 0);
            this.Txt_Email.MaxLength = 100;
            this.Txt_Email.Name = "Txt_Email";
            this.Txt_Email.Size = new System.Drawing.Size(305, 20);
            this.Txt_Email.TabIndex = 1214;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(314, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 13);
            this.label8.TabIndex = 493;
            this.label8.Text = "حساب العميــل :";
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.Color.White;
            this.txtAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAddress.Location = new System.Drawing.Point(3, 55);
            this.txtAddress.MaxLength = 100;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(305, 20);
            this.txtAddress.TabIndex = 13;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(314, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 13);
            this.label10.TabIndex = 495;
            this.label10.Text = "اسم العميـــــل :";
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label13.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label13.Location = new System.Drawing.Point(314, 52);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 13);
            this.label13.TabIndex = 1053;
            this.label13.Text = "عنوان العميل :";
            // 
            // Label_Mobile
            // 
            this.Label_Mobile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Mobile.AutoSize = true;
            this.Label_Mobile.BackColor = System.Drawing.Color.Transparent;
            this.Label_Mobile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Label_Mobile.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.Label_Mobile.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Label_Mobile.Location = new System.Drawing.Point(314, 78);
            this.Label_Mobile.Name = "Label_Mobile";
            this.Label_Mobile.Size = new System.Drawing.Size(45, 13);
            this.Label_Mobile.TabIndex = 1210;
            this.Label_Mobile.Text = " الجوال :";
            // 
            // splitContainer11
            // 
            this.splitContainer11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer11.Location = new System.Drawing.Point(3, 81);
            this.splitContainer11.Name = "splitContainer11";
            // 
            // splitContainer11.Panel1
            // 
            this.splitContainer11.Panel1.Controls.Add(this.text_Mobile);
            this.splitContainer11.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer11.Panel2
            // 
            this.splitContainer11.Panel2.Controls.Add(this.splitContainer12);
            this.splitContainer11.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer11.Size = new System.Drawing.Size(305, 20);
            this.splitContainer11.SplitterDistance = 101;
            this.splitContainer11.TabIndex = 1218;
            // 
            // text_Mobile
            // 
            this.text_Mobile.BackColor = System.Drawing.Color.White;
            this.text_Mobile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.text_Mobile.Location = new System.Drawing.Point(0, 0);
            this.text_Mobile.MaxLength = 30;
            this.text_Mobile.Name = "text_Mobile";
            this.text_Mobile.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.text_Mobile.Size = new System.Drawing.Size(101, 20);
            this.text_Mobile.TabIndex = 1209;
            this.text_Mobile.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // splitContainer12
            // 
            this.splitContainer12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer12.Location = new System.Drawing.Point(0, 0);
            this.splitContainer12.Name = "splitContainer12";
            // 
            // splitContainer12.Panel1
            // 
            this.splitContainer12.Panel1.Controls.Add(this.label12);
            this.splitContainer12.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer12.Panel2
            // 
            this.splitContainer12.Panel2.Controls.Add(this.txtTele);
            this.splitContainer12.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer12.Size = new System.Drawing.Size(200, 20);
            this.splitContainer12.SplitterDistance = 66;
            this.splitContainer12.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label12.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label12.Location = new System.Drawing.Point(18, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 13);
            this.label12.TabIndex = 1054;
            this.label12.Text = "هاتف :";
            // 
            // txtTele
            // 
            this.txtTele.BackColor = System.Drawing.Color.White;
            this.txtTele.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTele.Location = new System.Drawing.Point(0, 0);
            this.txtTele.MaxLength = 30;
            this.txtTele.Name = "txtTele";
            this.txtTele.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtTele.Size = new System.Drawing.Size(130, 20);
            this.txtTele.TabIndex = 14;
            this.txtTele.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(314, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 1080;
            this.label4.Text = "الايميل";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 3;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.17722F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.55738F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.34426F));
            this.tableLayoutPanel6.Controls.Add(this.txtDiscoundPoints, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.txtDiscoundPointsLoc, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.button_SrchCustPoints, 2, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 133);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(305, 23);
            this.tableLayoutPanel6.TabIndex = 1220;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.65947F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.34053F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel15, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.TxtPlateNo, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.splitContainer14, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.CmbCarType, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label36, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label43, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label42, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.panel3, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.TxtCarModel, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label50, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label51, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label52, 0, 3);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 6;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(418, 159);
            this.tableLayoutPanel2.TabIndex = 1217;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 3;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.2994F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.7006F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 137F));
            this.tableLayoutPanel15.Controls.Add(this.CmbCarComp, 2, 0);
            this.tableLayoutPanel15.Controls.Add(this.textBox4, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.label19, 1, 0);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 1;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(305, 20);
            this.tableLayoutPanel15.TabIndex = 1223;
            // 
            // CmbCarComp
            // 
            this.CmbCarComp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbCarComp.DisplayMember = "Text";
            this.CmbCarComp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CmbCarComp.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CmbCarComp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCarComp.FormattingEnabled = true;
            this.CmbCarComp.ItemHeight = 15;
            this.CmbCarComp.Location = new System.Drawing.Point(3, 3);
            this.CmbCarComp.Name = "CmbCarComp";
            this.CmbCarComp.Size = new System.Drawing.Size(132, 21);
            this.CmbCarComp.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.CmbCarComp.TabIndex = 1220;
            this.CmbCarComp.SelectedValueChanged += new System.EventHandler(this.CmbCarComp_SelectedValueChanged);
            // 
            // textBox4
            // 
            this.textBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox4.Location = new System.Drawing.Point(224, 3);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(78, 20);
            this.textBox4.TabIndex = 0;
            this.textBox4.RightToLeftChanged += new System.EventHandler(this.textBox4_RightToLeftChanged);
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            this.textBox4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox4_KeyDown);
            this.textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox4_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label19.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label19.Location = new System.Drawing.Point(141, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 20);
            this.label19.TabIndex = 493;
            this.label19.Text = "شركة المركبة";
            // 
            // TxtPlateNo
            // 
            this.TxtPlateNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TxtPlateNo.Location = new System.Drawing.Point(3, 81);
            this.TxtPlateNo.Mask = "L-L-L-0000";
            this.TxtPlateNo.Name = "TxtPlateNo";
            this.TxtPlateNo.RejectInputOnFirstFailure = true;
            this.TxtPlateNo.Size = new System.Drawing.Size(305, 20);
            this.TxtPlateNo.TabIndex = 1096;
            this.TxtPlateNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // splitContainer14
            // 
            this.splitContainer14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer14.Location = new System.Drawing.Point(3, 133);
            this.splitContainer14.Name = "splitContainer14";
            // 
            // splitContainer14.Panel1
            // 
            this.splitContainer14.Panel1.Controls.Add(this.cmbColors);
            this.splitContainer14.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer14.Panel2
            // 
            this.splitContainer14.Panel2.Controls.Add(this.splitContainer15);
            this.splitContainer14.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer14.Size = new System.Drawing.Size(305, 23);
            this.splitContainer14.SplitterDistance = 99;
            this.splitContainer14.TabIndex = 1221;
            // 
            // cmbColors
            // 
            this.cmbColors.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbColors.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbColors.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbColors.FormattingEnabled = true;
            this.cmbColors.Location = new System.Drawing.Point(0, 0);
            this.cmbColors.Name = "cmbColors";
            this.cmbColors.Size = new System.Drawing.Size(99, 21);
            this.cmbColors.TabIndex = 1215;
            this.cmbColors.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbColors_KeyDown);
            // 
            // splitContainer15
            // 
            this.splitContainer15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer15.Location = new System.Drawing.Point(0, 0);
            this.splitContainer15.Name = "splitContainer15";
            // 
            // splitContainer15.Panel1
            // 
            this.splitContainer15.Panel1.Controls.Add(this.label53);
            this.splitContainer15.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer15.Panel2
            // 
            this.splitContainer15.Panel2.Controls.Add(this.DeleveryDatePickers);
            this.splitContainer15.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer15.Size = new System.Drawing.Size(202, 23);
            this.splitContainer15.SplitterDistance = 78;
            this.splitContainer15.TabIndex = 0;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.Transparent;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label53.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label53.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label53.Location = new System.Drawing.Point(0, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(69, 13);
            this.label53.TabIndex = 1081;
            this.label53.Text = "تاريخ التسليم";
            // 
            // DeleveryDatePickers
            // 
            this.DeleveryDatePickers.CustomFormat = "dddd MM,yyyy";
            this.DeleveryDatePickers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DeleveryDatePickers.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DeleveryDatePickers.Location = new System.Drawing.Point(0, 0);
            this.DeleveryDatePickers.MinDate = new System.DateTime(2001, 1, 1, 0, 0, 0, 0);
            this.DeleveryDatePickers.Name = "DeleveryDatePickers";
            this.DeleveryDatePickers.Size = new System.Drawing.Size(120, 20);
            this.DeleveryDatePickers.TabIndex = 1215;
            // 
            // CmbCarType
            // 
            this.CmbCarType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbCarType.DisplayMember = "Text";
            this.CmbCarType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CmbCarType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CmbCarType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCarType.FormattingEnabled = true;
            this.CmbCarType.ItemHeight = 15;
            this.CmbCarType.Location = new System.Drawing.Point(3, 29);
            this.CmbCarType.Name = "CmbCarType";
            this.CmbCarType.Size = new System.Drawing.Size(305, 21);
            this.CmbCarType.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.CmbCarType.TabIndex = 1219;
            // 
            // label36
            // 
            this.label36.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label36.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label36.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label36.Location = new System.Drawing.Point(314, 130);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 13);
            this.label36.TabIndex = 1080;
            this.label36.Text = "اللون";
            // 
            // label43
            // 
            this.label43.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label43.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label43.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label43.Location = new System.Drawing.Point(314, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(60, 13);
            this.label43.TabIndex = 493;
            this.label43.Text = "رقم المركبه";
            this.label43.Click += new System.EventHandler(this.label43_Click);
            // 
            // label42
            // 
            this.label42.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label42.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label42.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label42.Location = new System.Drawing.Point(314, 104);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(57, 13);
            this.label42.TabIndex = 1054;
            this.label42.Text = "رقم الهيكل";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 107);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(305, 20);
            this.panel3.TabIndex = 1217;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.TxtChessNum);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(305, 20);
            this.panel4.TabIndex = 1217;
            // 
            // TxtChessNum
            // 
            this.TxtChessNum.BackColor = System.Drawing.Color.White;
            this.TxtChessNum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TxtChessNum.Location = new System.Drawing.Point(0, 0);
            this.TxtChessNum.MaxLength = 30;
            this.TxtChessNum.Name = "TxtChessNum";
            this.TxtChessNum.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TxtChessNum.Size = new System.Drawing.Size(305, 20);
            this.TxtChessNum.TabIndex = 14;
            this.TxtChessNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TxtCarModel
            // 
            this.TxtCarModel.BackColor = System.Drawing.Color.White;
            this.TxtCarModel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TxtCarModel.Location = new System.Drawing.Point(3, 55);
            this.TxtCarModel.MaxLength = 100;
            this.TxtCarModel.Name = "TxtCarModel";
            this.TxtCarModel.Size = new System.Drawing.Size(305, 20);
            this.TxtCarModel.TabIndex = 13;
            // 
            // label50
            // 
            this.label50.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Transparent;
            this.label50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label50.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label50.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label50.Location = new System.Drawing.Point(314, 26);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(62, 13);
            this.label50.TabIndex = 495;
            this.label50.Text = "نوع المركبة:";
            // 
            // label51
            // 
            this.label51.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.Transparent;
            this.label51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label51.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label51.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label51.Location = new System.Drawing.Point(314, 52);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(41, 13);
            this.label51.TabIndex = 1053;
            this.label51.Text = "الموديل";
            // 
            // label52
            // 
            this.label52.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.Transparent;
            this.label52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label52.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label52.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label52.Location = new System.Drawing.Point(314, 78);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(55, 13);
            this.label52.TabIndex = 1210;
            this.label52.Text = "رقم اللوحة";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 4;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.Controls.Add(this.Label26, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.label54, 2, 0);
            this.tableLayoutPanel8.Controls.Add(this.txtDiscountValLoc, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.txtDiscountP, 3, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(851, 168);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(418, 23);
            this.tableLayoutPanel8.TabIndex = 1219;
            // 
            // Label26
            // 
            this.Label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Label26.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.Label26.ForeColor = System.Drawing.Color.White;
            this.Label26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Label26.Location = new System.Drawing.Point(317, 0);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(98, 23);
            this.Label26.TabIndex = 1114;
            this.Label26.Text = "قيمة الخصم";
            this.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label54.ForeColor = System.Drawing.Color.White;
            this.label54.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label54.Location = new System.Drawing.Point(109, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(98, 23);
            this.label54.TabIndex = 1114;
            this.label54.Text = "نسبة الخصم";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDiscountValLoc
            // 
            this.txtDiscountValLoc.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtDiscountValLoc.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(227)))), ((int)(((byte)(231)))));
            this.txtDiscountValLoc.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtDiscountValLoc.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDiscountValLoc.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtDiscountValLoc.DisplayFormat = "0.00";
            this.txtDiscountValLoc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDiscountValLoc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtDiscountValLoc.Increment = 0D;
            this.txtDiscountValLoc.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtDiscountValLoc.IsInputReadOnly = true;
            this.txtDiscountValLoc.Location = new System.Drawing.Point(213, 3);
            this.txtDiscountValLoc.Name = "txtDiscountValLoc";
            this.txtDiscountValLoc.Size = new System.Drawing.Size(98, 21);
            this.txtDiscountValLoc.TabIndex = 1090;
            // 
            // txtDiscountP
            // 
            this.txtDiscountP.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtDiscountP.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtDiscountP.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDiscountP.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtDiscountP.DisplayFormat = "0.00";
            this.txtDiscountP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDiscountP.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtDiscountP.Increment = 0D;
            this.txtDiscountP.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtDiscountP.Location = new System.Drawing.Point(3, 3);
            this.txtDiscountP.Name = "txtDiscountP";
            this.txtDiscountP.Size = new System.Drawing.Size(100, 21);
            this.txtDiscountP.TabIndex = 1078;
            // 
            // CmbCurr
            // 
            this.CmbCurr.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CmbCurr.DisplayMember = "Text";
            this.CmbCurr.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CmbCurr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCurr.FormattingEnabled = true;
            this.CmbCurr.ItemHeight = 15;
            this.CmbCurr.Location = new System.Drawing.Point(846, 51);
            this.CmbCurr.Name = "CmbCurr";
            this.CmbCurr.Size = new System.Drawing.Size(301, 21);
            this.CmbCurr.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.CmbCurr.TabIndex = 8;
            this.CmbCurr.Visible = false;
            // 
            // doubleInput_Rate
            // 
            this.doubleInput_Rate.AllowEmptyState = false;
            // 
            // 
            // 
            this.doubleInput_Rate.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(227)))), ((int)(((byte)(231)))));
            this.doubleInput_Rate.BackgroundStyle.Class = "DateTimeInputBackground";
            this.doubleInput_Rate.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.doubleInput_Rate.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.doubleInput_Rate.DisplayFormat = "0.00";
            this.doubleInput_Rate.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Bold);
            this.doubleInput_Rate.Increment = 0D;
            this.doubleInput_Rate.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.doubleInput_Rate.IsInputReadOnly = true;
            this.doubleInput_Rate.Location = new System.Drawing.Point(899, 0);
            this.doubleInput_Rate.Name = "doubleInput_Rate";
            this.doubleInput_Rate.Size = new System.Drawing.Size(27, 19);
            this.doubleInput_Rate.TabIndex = 1082;
            this.doubleInput_Rate.Visible = false;
            // 
            // txtDueAmount
            // 
            this.txtDueAmount.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtDueAmount.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(227)))), ((int)(((byte)(231)))));
            this.txtDueAmount.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtDueAmount.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDueAmount.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtDueAmount.DisplayFormat = "0.00";
            this.txtDueAmount.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtDueAmount.Increment = 0D;
            this.txtDueAmount.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtDueAmount.IsInputReadOnly = true;
            this.txtDueAmount.Location = new System.Drawing.Point(43, 45);
            this.txtDueAmount.Name = "txtDueAmount";
            this.txtDueAmount.Size = new System.Drawing.Size(100, 21);
            this.txtDueAmount.TabIndex = 1081;
            this.txtDueAmount.Visible = false;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.SteelBlue;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(130, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 23);
            this.label3.TabIndex = 1091;
            this.label3.Text = "بالريــال";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Visible = false;
            // 
            // FlxDat
            // 
            this.FlxDat.AllowEditing = false;
            this.FlxDat.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.FlxDat.ColumnInfo = resources.GetString("FlxDat.ColumnInfo");
            this.FlxDat.Font = new System.Drawing.Font("Tahoma", 8F);
            this.FlxDat.Location = new System.Drawing.Point(418, 220);
            this.FlxDat.Name = "FlxDat";
            this.FlxDat.Rows.DefaultSize = 19;
            this.FlxDat.Size = new System.Drawing.Size(229, 96);
            this.FlxDat.StyleInfo = resources.GetString("FlxDat.StyleInfo");
            this.FlxDat.TabIndex = 1025;
            this.FlxDat.Visible = false;
            this.FlxDat.VisualStyle = C1.Win.C1FlexGrid.VisualStyle.Office2007Black;
            // 
            // FlxInv
            // 
            this.FlxInv.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.FlxInv.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.FlxInv.ColumnInfo = resources.GetString("FlxInv.ColumnInfo");
            this.FlxInv.ExtendLastCol = true;
            this.FlxInv.Font = new System.Drawing.Font("Tahoma", 8F);
            this.FlxInv.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.None;
            this.FlxInv.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
            this.FlxInv.Location = new System.Drawing.Point(0, 203);
            this.FlxInv.Name = "FlxInv";
            this.FlxInv.Rows.Count = 13;
            this.FlxInv.Rows.DefaultSize = 19;
            this.FlxInv.ShowSortPosition = C1.Win.C1FlexGrid.ShowSortPositionEnum.None;
            this.FlxInv.Size = new System.Drawing.Size(1275, 135);
            this.FlxInv.StyleInfo = resources.GetString("FlxInv.StyleInfo");
            this.FlxInv.TabIndex = 17;
            this.FlxInv.VisualStyle = C1.Win.C1FlexGrid.VisualStyle.System;
            this.FlxInv.StartEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.FlxInv_StartEdit);
            this.FlxInv.LeaveEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.FlxInv_LeaveEdit);
            this.FlxInv.ChangeEdit += new System.EventHandler(this.FlxInv_ChangeEdit);
            this.FlxInv.CellChanged += new C1.Win.C1FlexGrid.RowColEventHandler(this.FlxInv_CellChanged);
            this.FlxInv.TextChanged += new System.EventHandler(this.FlxInv_TextChanged);
            this.FlxInv.Click += new System.EventHandler(this.FlxInv_Click_1);
            // 
            // superTabControl_Info
            // 
            this.superTabControl_Info.BackColor = System.Drawing.Color.Red;
            // 
            // 
            // 
            this.superTabControl_Info.ControlBox.Category = null;
            // 
            // 
            // 
            this.superTabControl_Info.ControlBox.CloseBox.Category = null;
            this.superTabControl_Info.ControlBox.CloseBox.Description = null;
            this.superTabControl_Info.ControlBox.CloseBox.Name = "";
            this.superTabControl_Info.ControlBox.Description = null;
            // 
            // 
            // 
            this.superTabControl_Info.ControlBox.MenuBox.Category = null;
            this.superTabControl_Info.ControlBox.MenuBox.Description = null;
            this.superTabControl_Info.ControlBox.MenuBox.Name = "";
            this.superTabControl_Info.ControlBox.Name = "";
            this.superTabControl_Info.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl_Info.ControlBox.CloseBox,
            this.superTabControl_Info.ControlBox.MenuBox});
            this.superTabControl_Info.Controls.Add(this.superTabControlPanel3);
            this.superTabControl_Info.Controls.Add(this.superTabControlPanel1);
            this.superTabControl_Info.Controls.Add(this.superTabControlPanel9);
            this.superTabControl_Info.Controls.Add(this.superTabControlPanel5);
            this.superTabControl_Info.Controls.Add(this.superTabControlPanel2);
            this.superTabControl_Info.Controls.Add(this.superTabControlPanel4);
            this.superTabControl_Info.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControl_Info.ForeColor = System.Drawing.Color.Black;
            this.superTabControl_Info.Location = new System.Drawing.Point(3, 38);
            this.superTabControl_Info.Name = "superTabControl_Info";
            this.superTabControl_Info.ReorderTabsEnabled = true;
            this.superTabControl_Info.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superTabControl_Info.SelectedTabFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.superTabControl_Info.SelectedTabIndex = 0;
            this.superTabControl_Info.Size = new System.Drawing.Size(1266, 111);
            this.superTabControl_Info.TabAlignment = DevComponents.DotNetBar.eTabStripAlignment.Bottom;
            this.superTabControl_Info.TabFont = new System.Drawing.Font("Tahoma", 8F);
            this.superTabControl_Info.TabHorizontalSpacing = 11;
            this.superTabControl_Info.TabIndex = 1086;
            this.superTabControl_Info.TabLayoutType = DevComponents.DotNetBar.eSuperTabLayoutType.SingleLineFit;
            this.superTabControl_Info.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem_items,
            this.superTabItem_Detiles,
            this.superTabItem_Note,
            this.superTabItem_Gaids});
            this.superTabControl_Info.TabStyle = DevComponents.DotNetBar.eSuperTabStyle.OneNote2007;
            this.superTabControl_Info.TextAlignment = DevComponents.DotNetBar.eItemAlignment.Far;
            // 
            // superTabControlPanel3
            // 
            this.superTabControlPanel3.Controls.Add(this.label32);
            this.superTabControlPanel3.Controls.Add(this.txtVSerial);
            this.superTabControlPanel3.Controls.Add(this.txtUnit);
            this.superTabControlPanel3.Controls.Add(this.txtLPrice);
            this.superTabControlPanel3.Controls.Add(this.label25);
            this.superTabControlPanel3.Controls.Add(this.label22);
            this.superTabControlPanel3.Controls.Add(this.label23);
            this.superTabControlPanel3.Controls.Add(this.label24);
            this.superTabControlPanel3.Controls.Add(this.txtLCost);
            this.superTabControlPanel3.Controls.Add(this.txtVCost);
            this.superTabControlPanel3.Controls.Add(this.FlxStkQty);
            this.superTabControlPanel3.Controls.Add(this.txtLocItem);
            this.superTabControlPanel3.Controls.Add(this.dataGridView_ItemDet);
            this.superTabControlPanel3.Controls.Add(this.txtPointCount);
            this.superTabControlPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel3.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel3.Name = "superTabControlPanel3";
            superTabLinearGradientColorTable2.Colors = new System.Drawing.Color[] {
        System.Drawing.Color.Gray,
        System.Drawing.Color.White};
            superTabLinearGradientColorTable2.GradientAngle = 80;
            superTabPanelItemColorTable1.Background = superTabLinearGradientColorTable2;
            superTabPanelColorTable1.Bottom = superTabPanelItemColorTable1;
            this.superTabControlPanel3.PanelColor = superTabPanelColorTable1;
            this.superTabControlPanel3.Size = new System.Drawing.Size(1266, 88);
            this.superTabControlPanel3.TabIndex = 0;
            this.superTabControlPanel3.TabItem = this.superTabItem_items;
            // 
            // label32
            // 
            this.label32.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Font = new System.Drawing.Font("Tahoma", 7F);
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label32.Location = new System.Drawing.Point(1006, 70);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(41, 12);
            this.label32.TabIndex = 1083;
            this.label32.Text = "السيريال";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label32.Visible = false;
            // 
            // txtVSerial
            // 
            this.txtVSerial.BackColor = System.Drawing.Color.AliceBlue;
            this.txtVSerial.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVSerial.Location = new System.Drawing.Point(579, 70);
            this.txtVSerial.Name = "txtVSerial";
            this.txtVSerial.ReadOnly = true;
            this.txtVSerial.Size = new System.Drawing.Size(123, 13);
            this.txtVSerial.TabIndex = 1082;
            this.txtVSerial.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtVSerial.Visible = false;
            // 
            // txtUnit
            // 
            this.txtUnit.BackColor = System.Drawing.Color.AliceBlue;
            this.txtUnit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUnit.Location = new System.Drawing.Point(336, 69);
            this.txtUnit.Name = "txtUnit";
            this.txtUnit.ReadOnly = true;
            this.txtUnit.Size = new System.Drawing.Size(68, 13);
            this.txtUnit.TabIndex = 60;
            this.txtUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLPrice
            // 
            this.txtLPrice.BackColor = System.Drawing.Color.AliceBlue;
            this.txtLPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLPrice.Location = new System.Drawing.Point(336, 49);
            this.txtLPrice.Name = "txtLPrice";
            this.txtLPrice.ReadOnly = true;
            this.txtLPrice.Size = new System.Drawing.Size(68, 13);
            this.txtLPrice.TabIndex = 4;
            this.txtLPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Tahoma", 7F);
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label25.Location = new System.Drawing.Point(710, 70);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(31, 12);
            this.label25.TabIndex = 1078;
            this.label25.Text = "الوحدة";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Tahoma", 7F);
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label22.Location = new System.Drawing.Point(710, 50);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(56, 12);
            this.label22.TabIndex = 1077;
            this.label22.Text = "سعر اخر بيع";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Tahoma", 7F);
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label23.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label23.Location = new System.Drawing.Point(710, 30);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 12);
            this.label23.TabIndex = 1076;
            this.label23.Text = "أخر تكلفة";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Tahoma", 7F);
            this.label24.ForeColor = System.Drawing.Color.Maroon;
            this.label24.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label24.Location = new System.Drawing.Point(710, 10);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(67, 12);
            this.label24.TabIndex = 1075;
            this.label24.Text = "متوسط التكلفة";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtLCost
            // 
            this.txtLCost.BackColor = System.Drawing.Color.AliceBlue;
            this.txtLCost.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLCost.Location = new System.Drawing.Point(336, 29);
            this.txtLCost.Name = "txtLCost";
            this.txtLCost.ReadOnly = true;
            this.txtLCost.Size = new System.Drawing.Size(68, 13);
            this.txtLCost.TabIndex = 59;
            this.txtLCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVCost
            // 
            this.txtVCost.BackColor = System.Drawing.Color.AliceBlue;
            this.txtVCost.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVCost.Location = new System.Drawing.Point(336, 9);
            this.txtVCost.Name = "txtVCost";
            this.txtVCost.ReadOnly = true;
            this.txtVCost.Size = new System.Drawing.Size(68, 13);
            this.txtVCost.TabIndex = 57;
            this.txtVCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FlxStkQty
            // 
            this.FlxStkQty.AllowEditing = false;
            this.FlxStkQty.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FlxStkQty.BackColor = System.Drawing.Color.Transparent;
            this.FlxStkQty.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.FixedSingle;
            this.FlxStkQty.ColumnInfo = resources.GetString("FlxStkQty.ColumnInfo");
            this.FlxStkQty.Font = new System.Drawing.Font("Tahoma", 8F);
            this.FlxStkQty.Location = new System.Drawing.Point(1053, 3);
            this.FlxStkQty.Name = "FlxStkQty";
            this.FlxStkQty.Rows.DefaultSize = 19;
            this.FlxStkQty.Size = new System.Drawing.Size(208, 93);
            this.FlxStkQty.StyleInfo = resources.GetString("FlxStkQty.StyleInfo");
            this.FlxStkQty.TabIndex = 1;
            this.FlxStkQty.VisualStyle = C1.Win.C1FlexGrid.VisualStyle.Office2007Black;
            // 
            // txtLocItem
            // 
            this.txtLocItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtLocItem.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLocItem.Location = new System.Drawing.Point(-72, 114);
            this.txtLocItem.Name = "txtLocItem";
            this.txtLocItem.ReadOnly = true;
            this.txtLocItem.Size = new System.Drawing.Size(533, 13);
            this.txtLocItem.TabIndex = 1223;
            this.txtLocItem.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dataGridView_ItemDet
            // 
            this.dataGridView_ItemDet.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.dataGridView_ItemDet.AllowEditing = false;
            this.dataGridView_ItemDet.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.XpThemes;
            this.dataGridView_ItemDet.ColumnInfo = resources.GetString("dataGridView_ItemDet.ColumnInfo");
            this.dataGridView_ItemDet.ExtendLastCol = true;
            this.dataGridView_ItemDet.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dataGridView_ItemDet.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.None;
            this.dataGridView_ItemDet.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
            this.dataGridView_ItemDet.Location = new System.Drawing.Point(4, 17);
            this.dataGridView_ItemDet.Name = "dataGridView_ItemDet";
            this.dataGridView_ItemDet.Rows.Count = 13;
            this.dataGridView_ItemDet.Rows.DefaultSize = 19;
            this.dataGridView_ItemDet.ShowSortPosition = C1.Win.C1FlexGrid.ShowSortPositionEnum.None;
            this.dataGridView_ItemDet.Size = new System.Drawing.Size(734, 96);
            this.dataGridView_ItemDet.StyleInfo = resources.GetString("dataGridView_ItemDet.StyleInfo");
            this.dataGridView_ItemDet.TabIndex = 1079;
            this.dataGridView_ItemDet.Visible = false;
            this.dataGridView_ItemDet.VisualStyle = C1.Win.C1FlexGrid.VisualStyle.System;
            this.dataGridView_ItemDet.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dataGridView_ItemDet_MouseDown);
            // 
            // txtPointCount
            // 
            this.txtPointCount.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtPointCount.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtPointCount.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtPointCount.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtPointCount.DisplayFormat = "0.00";
            this.txtPointCount.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtPointCount.Increment = 0D;
            this.txtPointCount.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtPointCount.IsInputReadOnly = true;
            this.txtPointCount.Location = new System.Drawing.Point(242, 41);
            this.txtPointCount.Name = "txtPointCount";
            this.txtPointCount.Size = new System.Drawing.Size(85, 21);
            this.txtPointCount.TabIndex = 1222;
            this.txtPointCount.Visible = false;
            // 
            // superTabItem_items
            // 
            this.superTabItem_items.AttachedControl = this.superTabControlPanel3;
            this.superTabItem_items.GlobalItem = false;
            this.superTabItem_items.Name = "superTabItem_items";
            superTabLinearGradientColorTable3.Colors = new System.Drawing.Color[] {
        System.Drawing.Color.White};
            superTabItemStateColorTable1.Background = superTabLinearGradientColorTable3;
            superTabColorStates1.Normal = superTabItemStateColorTable1;
            superTabItemColorTable1.Bottom = superTabColorStates1;
            this.superTabItem_items.TabColor = superTabItemColorTable1;
            this.superTabItem_items.Text = "م.الصنف";
            // 
            // superTabControlPanel1
            // 
            this.superTabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel1.Name = "superTabControlPanel1";
            superTabLinearGradientColorTable4.Colors = new System.Drawing.Color[] {
        System.Drawing.Color.Gray,
        System.Drawing.Color.White};
            superTabPanelItemColorTable2.Background = superTabLinearGradientColorTable4;
            superTabPanelColorTable2.Bottom = superTabPanelItemColorTable2;
            this.superTabControlPanel1.PanelColor = superTabPanelColorTable2;
            this.superTabControlPanel1.Size = new System.Drawing.Size(1266, 88);
            this.superTabControlPanel1.TabIndex = 1;
            // 
            // superTabControlPanel9
            // 
            this.superTabControlPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel9.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel9.Name = "superTabControlPanel9";
            this.superTabControlPanel9.Size = new System.Drawing.Size(1266, 88);
            this.superTabControlPanel9.TabIndex = 4;
            // 
            // superTabControlPanel5
            // 
            this.superTabControlPanel5.Controls.Add(this.superTabControl_CostSts);
            this.superTabControlPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel5.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel5.Name = "superTabControlPanel5";
            this.superTabControlPanel5.Size = new System.Drawing.Size(1266, 88);
            this.superTabControlPanel5.TabIndex = 5;
            this.superTabControlPanel5.TabItem = this.superTabItem_Gaids;
            // 
            // superTabControl_CostSts
            // 
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabControl_CostSts.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabControl_CostSts.ControlBox.MenuBox.Name = "";
            this.superTabControl_CostSts.ControlBox.Name = "";
            this.superTabControl_CostSts.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl_CostSts.ControlBox.MenuBox,
            this.superTabControl_CostSts.ControlBox.CloseBox});
            this.superTabControl_CostSts.ControlBox.Visible = false;
            this.superTabControl_CostSts.Controls.Add(this.superTabControlPanel11);
            this.superTabControl_CostSts.Controls.Add(this.superTabControlPanel7);
            this.superTabControl_CostSts.Controls.Add(this.superTabControlPanel6);
            this.superTabControl_CostSts.Controls.Add(this.superTabControlPanel8);
            this.superTabControl_CostSts.Controls.Add(this.superTabControlPanel10);
            this.superTabControl_CostSts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControl_CostSts.Location = new System.Drawing.Point(0, 0);
            this.superTabControl_CostSts.Name = "superTabControl_CostSts";
            this.superTabControl_CostSts.ReorderTabsEnabled = true;
            this.superTabControl_CostSts.SelectedTabFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.superTabControl_CostSts.SelectedTabIndex = 0;
            this.superTabControl_CostSts.Size = new System.Drawing.Size(1266, 88);
            this.superTabControl_CostSts.TabFont = new System.Drawing.Font("Tahoma", 8F);
            this.superTabControl_CostSts.TabIndex = 1024;
            this.superTabControl_CostSts.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem_Pay,
            this.superTabItem_Dis,
            this.superTabItem_Tax,
            this.superTabItem_LocalComm,
            this.switchButton_TaxLines,
            this.switchButton_TaxByTotal,
            this.switchButton_TaxByNet,
            this.textBoxItem_TaxByNetValue,
            this.labelItem_TaxByNetPer,
            this.ChkPriceIncludeTax});
            this.superTabControl_CostSts.TabStyle = DevComponents.DotNetBar.eSuperTabStyle.WinMediaPlayer12;
            this.superTabControl_CostSts.Text = "superTabControl3";
            this.superTabControl_CostSts.SelectedTabChanged += new System.EventHandler<DevComponents.DotNetBar.SuperTabStripSelectedTabChangedEventArgs>(this.superTabControl_CostSts_SelectedTabChanged);
            // 
            // superTabControlPanel11
            // 
            this.superTabControlPanel11.Controls.Add(this.button_CustC1);
            this.superTabControlPanel11.Controls.Add(this.panelBalanceBottom);
            this.superTabControlPanel11.Controls.Add(this.button_CustC3);
            this.superTabControlPanel11.Controls.Add(this.button_CustC2);
            this.superTabControlPanel11.Controls.Add(this.txtDebit2);
            this.superTabControlPanel11.Controls.Add(this.txtCredit1);
            this.superTabControlPanel11.Controls.Add(this.doubleInput_NetWorkLoc);
            this.superTabControlPanel11.Controls.Add(this.txtCredit2);
            this.superTabControlPanel11.Controls.Add(this.txtPaymentLoc);
            this.superTabControlPanel11.Controls.Add(this.txtCredit3);
            this.superTabControlPanel11.Controls.Add(this.labelC1);
            this.superTabControlPanel11.Controls.Add(this.doubleInput_CreditLoc);
            this.superTabControlPanel11.Controls.Add(this.label14);
            this.superTabControlPanel11.Controls.Add(this.labelC2);
            this.superTabControlPanel11.Controls.Add(this.label11);
            this.superTabControlPanel11.Controls.Add(this.label6);
            this.superTabControlPanel11.Controls.Add(this.labelC3);
            this.superTabControlPanel11.Controls.Add(this.txtDebit1);
            this.superTabControlPanel11.Controls.Add(this.button_CustD1);
            this.superTabControlPanel11.Controls.Add(this.txtDebit3);
            this.superTabControlPanel11.Controls.Add(this.labelD1);
            this.superTabControlPanel11.Controls.Add(this.labelD3);
            this.superTabControlPanel11.Controls.Add(this.button_CustD3);
            this.superTabControlPanel11.Controls.Add(this.button_CustD2);
            this.superTabControlPanel11.Controls.Add(this.labelD2);
            this.superTabControlPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel11.Location = new System.Drawing.Point(0, 25);
            this.superTabControlPanel11.Name = "superTabControlPanel11";
            this.superTabControlPanel11.Size = new System.Drawing.Size(1266, 63);
            this.superTabControlPanel11.TabIndex = 1;
            this.superTabControlPanel11.TabItem = this.superTabItem_Pay;
            // 
            // button_CustC1
            // 
            this.button_CustC1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_CustC1.Checked = true;
            this.button_CustC1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_CustC1.Location = new System.Drawing.Point(29, 7);
            this.button_CustC1.Name = "button_CustC1";
            this.button_CustC1.Size = new System.Drawing.Size(15, 15);
            this.button_CustC1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_CustC1.Symbol = "";
            this.button_CustC1.SymbolSize = 7F;
            this.button_CustC1.TabIndex = 1123;
            this.button_CustC1.TextColor = System.Drawing.Color.SteelBlue;
            this.button_CustC1.Tooltip = "حساب العميل";
            // 
            // panelBalanceBottom
            // 
            this.panelBalanceBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelBalanceBottom.Controls.Add(this.textBox_AccBalanceBottom);
            this.panelBalanceBottom.Controls.Add(this.labelBalanceBottom);
            this.panelBalanceBottom.Location = new System.Drawing.Point(492, 10);
            this.panelBalanceBottom.Name = "panelBalanceBottom";
            this.panelBalanceBottom.Size = new System.Drawing.Size(146, 34);
            this.panelBalanceBottom.TabIndex = 1224;
            this.panelBalanceBottom.Visible = false;
            // 
            // textBox_AccBalanceBottom
            // 
            this.textBox_AccBalanceBottom.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.textBox_AccBalanceBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_AccBalanceBottom.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.textBox_AccBalanceBottom.ForeColor = System.Drawing.Color.White;
            this.textBox_AccBalanceBottom.Location = new System.Drawing.Point(0, 0);
            this.textBox_AccBalanceBottom.Multiline = true;
            this.textBox_AccBalanceBottom.Name = "textBox_AccBalanceBottom";
            this.textBox_AccBalanceBottom.ReadOnly = true;
            this.textBox_AccBalanceBottom.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_AccBalanceBottom.Size = new System.Drawing.Size(97, 32);
            this.textBox_AccBalanceBottom.TabIndex = 1094;
            this.textBox_AccBalanceBottom.Text = "0";
            this.textBox_AccBalanceBottom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelBalanceBottom
            // 
            this.labelBalanceBottom.BackColor = System.Drawing.Color.Red;
            this.labelBalanceBottom.Dock = System.Windows.Forms.DockStyle.Right;
            this.labelBalanceBottom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelBalanceBottom.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelBalanceBottom.ForeColor = System.Drawing.Color.White;
            this.labelBalanceBottom.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelBalanceBottom.Location = new System.Drawing.Point(97, 0);
            this.labelBalanceBottom.Name = "labelBalanceBottom";
            this.labelBalanceBottom.Size = new System.Drawing.Size(47, 32);
            this.labelBalanceBottom.TabIndex = 1093;
            this.labelBalanceBottom.Text = "الرصيـد ";
            this.labelBalanceBottom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_CustC3
            // 
            this.button_CustC3.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_CustC3.Checked = true;
            this.button_CustC3.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_CustC3.Location = new System.Drawing.Point(29, 53);
            this.button_CustC3.Name = "button_CustC3";
            this.button_CustC3.Size = new System.Drawing.Size(15, 15);
            this.button_CustC3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_CustC3.Symbol = "";
            this.button_CustC3.SymbolSize = 7F;
            this.button_CustC3.TabIndex = 1122;
            this.button_CustC3.TextColor = System.Drawing.Color.SteelBlue;
            this.button_CustC3.Tooltip = "حساب العميل";
            // 
            // button_CustC2
            // 
            this.button_CustC2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_CustC2.Checked = true;
            this.button_CustC2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_CustC2.Location = new System.Drawing.Point(29, 30);
            this.button_CustC2.Name = "button_CustC2";
            this.button_CustC2.Size = new System.Drawing.Size(15, 15);
            this.button_CustC2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_CustC2.Symbol = "";
            this.button_CustC2.SymbolSize = 7F;
            this.button_CustC2.TabIndex = 1121;
            this.button_CustC2.TextColor = System.Drawing.Color.SteelBlue;
            this.button_CustC2.Tooltip = "حساب العميل";
            // 
            // txtDebit2
            // 
            this.txtDebit2.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtDebit2.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDebit2.ButtonCustom.Checked = true;
            this.txtDebit2.ButtonCustom.Visible = true;
            this.txtDebit2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtDebit2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtDebit2.Location = new System.Drawing.Point(438, 29);
            this.txtDebit2.Name = "txtDebit2";
            this.txtDebit2.ReadOnly = true;
            this.txtDebit2.Size = new System.Drawing.Size(341, 14);
            this.txtDebit2.TabIndex = 1113;
            this.txtDebit2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDebit2.MouseLeave += new System.EventHandler(this.txtCustNo_MouseLeave);
            this.txtDebit2.MouseHover += new System.EventHandler(this.txtDebit2_MouseHover);
            // 
            // txtCredit1
            // 
            this.txtCredit1.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtCredit1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtCredit1.ButtonCustom.Visible = true;
            this.txtCredit1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCredit1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtCredit1.Location = new System.Drawing.Point(47, 7);
            this.txtCredit1.Name = "txtCredit1";
            this.txtCredit1.ReadOnly = true;
            this.txtCredit1.Size = new System.Drawing.Size(308, 14);
            this.txtCredit1.TabIndex = 1115;
            this.txtCredit1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCredit1.MouseLeave += new System.EventHandler(this.txtCustNo_MouseLeave);
            this.txtCredit1.MouseHover += new System.EventHandler(this.txtCredit1_MouseHover);
            // 
            // doubleInput_NetWorkLoc
            // 
            this.doubleInput_NetWorkLoc.AllowEmptyState = false;
            // 
            // 
            // 
            this.doubleInput_NetWorkLoc.BackgroundStyle.Class = "DateTimeInputBackground";
            this.doubleInput_NetWorkLoc.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.doubleInput_NetWorkLoc.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.doubleInput_NetWorkLoc.DisplayFormat = "0.00";
            this.doubleInput_NetWorkLoc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.doubleInput_NetWorkLoc.Increment = 0D;
            this.doubleInput_NetWorkLoc.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.doubleInput_NetWorkLoc.Location = new System.Drawing.Point(860, 51);
            this.doubleInput_NetWorkLoc.MinValue = 0D;
            this.doubleInput_NetWorkLoc.Name = "doubleInput_NetWorkLoc";
            this.doubleInput_NetWorkLoc.Size = new System.Drawing.Size(49, 21);
            this.doubleInput_NetWorkLoc.TabIndex = 1091;
            this.doubleInput_NetWorkLoc.ValueChanged += new System.EventHandler(this.FrmInvices_CheckFouce);
            // 
            // txtCredit2
            // 
            this.txtCredit2.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtCredit2.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtCredit2.ButtonCustom.Visible = true;
            this.txtCredit2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCredit2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtCredit2.Location = new System.Drawing.Point(47, 30);
            this.txtCredit2.Name = "txtCredit2";
            this.txtCredit2.ReadOnly = true;
            this.txtCredit2.Size = new System.Drawing.Size(308, 14);
            this.txtCredit2.TabIndex = 1116;
            this.txtCredit2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCredit2.MouseLeave += new System.EventHandler(this.txtCustNo_MouseLeave);
            this.txtCredit2.MouseHover += new System.EventHandler(this.txtCredit2_MouseHover);
            // 
            // txtPaymentLoc
            // 
            this.txtPaymentLoc.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtPaymentLoc.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtPaymentLoc.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtPaymentLoc.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtPaymentLoc.DisplayFormat = "0.00";
            this.txtPaymentLoc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtPaymentLoc.Increment = 0D;
            this.txtPaymentLoc.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtPaymentLoc.Location = new System.Drawing.Point(860, 5);
            this.txtPaymentLoc.MinValue = 0D;
            this.txtPaymentLoc.Name = "txtPaymentLoc";
            this.txtPaymentLoc.Size = new System.Drawing.Size(49, 21);
            this.txtPaymentLoc.TabIndex = 1089;
            // 
            // txtCredit3
            // 
            this.txtCredit3.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtCredit3.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtCredit3.ButtonCustom.Visible = true;
            this.txtCredit3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCredit3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtCredit3.Location = new System.Drawing.Point(47, 53);
            this.txtCredit3.Name = "txtCredit3";
            this.txtCredit3.ReadOnly = true;
            this.txtCredit3.Size = new System.Drawing.Size(308, 14);
            this.txtCredit3.TabIndex = 1117;
            this.txtCredit3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCredit3.MouseLeave += new System.EventHandler(this.txtCustNo_MouseLeave);
            this.txtCredit3.MouseHover += new System.EventHandler(this.txtCredit3_MouseHover);
            // 
            // labelC1
            // 
            this.labelC1.AutoSize = true;
            this.labelC1.BackColor = System.Drawing.Color.Transparent;
            this.labelC1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelC1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelC1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelC1.Location = new System.Drawing.Point(364, 7);
            this.labelC1.Name = "labelC1";
            this.labelC1.Size = new System.Drawing.Size(49, 13);
            this.labelC1.TabIndex = 1099;
            this.labelC1.Text = "الدائـــن :";
            // 
            // doubleInput_CreditLoc
            // 
            this.doubleInput_CreditLoc.AllowEmptyState = false;
            // 
            // 
            // 
            this.doubleInput_CreditLoc.BackgroundStyle.Class = "DateTimeInputBackground";
            this.doubleInput_CreditLoc.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.doubleInput_CreditLoc.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.doubleInput_CreditLoc.DisplayFormat = "0.00";
            this.doubleInput_CreditLoc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.doubleInput_CreditLoc.Increment = 0D;
            this.doubleInput_CreditLoc.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.doubleInput_CreditLoc.Location = new System.Drawing.Point(860, 28);
            this.doubleInput_CreditLoc.MinValue = 0D;
            this.doubleInput_CreditLoc.Name = "doubleInput_CreditLoc";
            this.doubleInput_CreditLoc.Size = new System.Drawing.Size(49, 21);
            this.doubleInput_CreditLoc.TabIndex = 1092;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(910, 54);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 14);
            this.label14.TabIndex = 1046;
            this.label14.Text = "شبكة :";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelC2
            // 
            this.labelC2.AutoSize = true;
            this.labelC2.BackColor = System.Drawing.Color.Transparent;
            this.labelC2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelC2.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelC2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelC2.Location = new System.Drawing.Point(364, 30);
            this.labelC2.Name = "labelC2";
            this.labelC2.Size = new System.Drawing.Size(49, 13);
            this.labelC2.TabIndex = 1105;
            this.labelC2.Text = "الدائـــن :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(910, 31);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 14);
            this.label11.TabIndex = 1044;
            this.label11.Text = "آجــل :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(909, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 1042;
            this.label6.Text = "نقــــداّ :";
            // 
            // labelC3
            // 
            this.labelC3.AutoSize = true;
            this.labelC3.BackColor = System.Drawing.Color.Transparent;
            this.labelC3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelC3.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelC3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelC3.Location = new System.Drawing.Point(364, 53);
            this.labelC3.Name = "labelC3";
            this.labelC3.Size = new System.Drawing.Size(49, 13);
            this.labelC3.TabIndex = 1111;
            this.labelC3.Text = "الدائـــن :";
            // 
            // txtDebit1
            // 
            this.txtDebit1.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtDebit1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDebit1.ButtonCustom.Visible = true;
            this.txtDebit1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtDebit1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtDebit1.Location = new System.Drawing.Point(438, 6);
            this.txtDebit1.Name = "txtDebit1";
            this.txtDebit1.ReadOnly = true;
            this.txtDebit1.Size = new System.Drawing.Size(341, 14);
            this.txtDebit1.TabIndex = 1112;
            this.txtDebit1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDebit1.MouseLeave += new System.EventHandler(this.txtCustNo_MouseLeave);
            this.txtDebit1.MouseHover += new System.EventHandler(this.txtDebit1_MouseHover);
            // 
            // button_CustD1
            // 
            this.button_CustD1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_CustD1.Checked = true;
            this.button_CustD1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_CustD1.Location = new System.Drawing.Point(419, 6);
            this.button_CustD1.Name = "button_CustD1";
            this.button_CustD1.Size = new System.Drawing.Size(15, 15);
            this.button_CustD1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_CustD1.Symbol = "";
            this.button_CustD1.SymbolSize = 7F;
            this.button_CustD1.TabIndex = 1120;
            this.button_CustD1.TextColor = System.Drawing.Color.SteelBlue;
            this.button_CustD1.Tooltip = "حساب العميل";
            // 
            // txtDebit3
            // 
            this.txtDebit3.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtDebit3.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDebit3.ButtonCustom.Visible = true;
            this.txtDebit3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtDebit3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtDebit3.Location = new System.Drawing.Point(438, 52);
            this.txtDebit3.Name = "txtDebit3";
            this.txtDebit3.ReadOnly = true;
            this.txtDebit3.Size = new System.Drawing.Size(341, 14);
            this.txtDebit3.TabIndex = 1114;
            this.txtDebit3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDebit3.MouseLeave += new System.EventHandler(this.txtCustNo_MouseLeave);
            this.txtDebit3.MouseHover += new System.EventHandler(this.txtDebit3_MouseHover);
            // 
            // labelD1
            // 
            this.labelD1.AutoSize = true;
            this.labelD1.BackColor = System.Drawing.Color.Transparent;
            this.labelD1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelD1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelD1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelD1.Location = new System.Drawing.Point(800, 6);
            this.labelD1.Name = "labelD1";
            this.labelD1.Size = new System.Drawing.Size(53, 13);
            this.labelD1.TabIndex = 1096;
            this.labelD1.Text = "المـــدين :";
            // 
            // labelD3
            // 
            this.labelD3.AutoSize = true;
            this.labelD3.BackColor = System.Drawing.Color.Transparent;
            this.labelD3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelD3.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelD3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelD3.Location = new System.Drawing.Point(800, 52);
            this.labelD3.Name = "labelD3";
            this.labelD3.Size = new System.Drawing.Size(53, 13);
            this.labelD3.TabIndex = 1108;
            this.labelD3.Text = "المـــدين :";
            // 
            // button_CustD3
            // 
            this.button_CustD3.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_CustD3.Checked = true;
            this.button_CustD3.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_CustD3.Location = new System.Drawing.Point(419, 52);
            this.button_CustD3.Name = "button_CustD3";
            this.button_CustD3.Size = new System.Drawing.Size(15, 15);
            this.button_CustD3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_CustD3.Symbol = "";
            this.button_CustD3.SymbolSize = 7F;
            this.button_CustD3.TabIndex = 1119;
            this.button_CustD3.TextColor = System.Drawing.Color.SteelBlue;
            this.button_CustD3.Tooltip = "حساب العميل";
            // 
            // button_CustD2
            // 
            this.button_CustD2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_CustD2.Checked = true;
            this.button_CustD2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_CustD2.Location = new System.Drawing.Point(419, 29);
            this.button_CustD2.Name = "button_CustD2";
            this.button_CustD2.Size = new System.Drawing.Size(15, 15);
            this.button_CustD2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_CustD2.Symbol = "";
            this.button_CustD2.SymbolSize = 7F;
            this.button_CustD2.TabIndex = 1118;
            this.button_CustD2.TextColor = System.Drawing.Color.SteelBlue;
            this.button_CustD2.Tooltip = "حساب العميل";
            // 
            // labelD2
            // 
            this.labelD2.AutoSize = true;
            this.labelD2.BackColor = System.Drawing.Color.Transparent;
            this.labelD2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelD2.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelD2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelD2.Location = new System.Drawing.Point(800, 29);
            this.labelD2.Name = "labelD2";
            this.labelD2.Size = new System.Drawing.Size(53, 13);
            this.labelD2.TabIndex = 1102;
            this.labelD2.Text = "المـــدين :";
            // 
            // superTabItem_Pay
            // 
            this.superTabItem_Pay.AttachedControl = this.superTabControlPanel11;
            this.superTabItem_Pay.GlobalItem = false;
            this.superTabItem_Pay.Name = "superTabItem_Pay";
            this.superTabItem_Pay.Text = "الدفع";
            // 
            // superTabControlPanel7
            // 
            this.superTabControlPanel7.Controls.Add(this.switchButton_Dis);
            this.superTabControlPanel7.Controls.Add(this.label31);
            this.superTabControlPanel7.Controls.Add(this.label37);
            this.superTabControlPanel7.Controls.Add(this.label38);
            this.superTabControlPanel7.Controls.Add(this.txtCredit6);
            this.superTabControlPanel7.Controls.Add(this.txtDebit6);
            this.superTabControlPanel7.Controls.Add(this.label39);
            this.superTabControlPanel7.Controls.Add(this.txtTotDis);
            this.superTabControlPanel7.Controls.Add(this.txtTotDisLoc);
            this.superTabControlPanel7.Controls.Add(this.checkBox_GaidDis);
            this.superTabControlPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel7.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel7.Name = "superTabControlPanel7";
            this.superTabControlPanel7.Size = new System.Drawing.Size(1266, 88);
            this.superTabControlPanel7.TabIndex = 0;
            this.superTabControlPanel7.TabItem = this.superTabItem_Dis;
            // 
            // switchButton_Dis
            // 
            // 
            // 
            // 
            this.switchButton_Dis.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.switchButton_Dis.Font = new System.Drawing.Font("Tahoma", 7F);
            this.switchButton_Dis.Location = new System.Drawing.Point(7, 19);
            this.switchButton_Dis.Name = "switchButton_Dis";
            this.switchButton_Dis.OffBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(80)))), ((int)(((byte)(77)))));
            this.switchButton_Dis.OffText = "+ السطــور";
            this.switchButton_Dis.OffTextColor = System.Drawing.Color.White;
            this.switchButton_Dis.OnText = "+ السطــور";
            this.switchButton_Dis.Size = new System.Drawing.Size(104, 21);
            this.switchButton_Dis.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.switchButton_Dis.TabIndex = 1164;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.Transparent;
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label31.ForeColor = System.Drawing.Color.Navy;
            this.label31.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label31.Location = new System.Drawing.Point(852, 19);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(99, 21);
            this.label31.TabIndex = 1163;
            this.label31.Text = "إجمالي القيمة";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label37.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label37.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label37.Location = new System.Drawing.Point(694, 46);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(55, 13);
            this.label37.TabIndex = 1162;
            this.label37.Text = "الدائـــــن :";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Transparent;
            this.label38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label38.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label38.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label38.Location = new System.Drawing.Point(694, 23);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(53, 13);
            this.label38.TabIndex = 1161;
            this.label38.Text = "المـــدين :";
            // 
            // txtCredit6
            // 
            this.txtCredit6.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtCredit6.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtCredit6.ButtonCustom.Visible = true;
            this.txtCredit6.Enabled = false;
            this.txtCredit6.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCredit6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtCredit6.Location = new System.Drawing.Point(116, 49);
            this.txtCredit6.Name = "txtCredit6";
            this.txtCredit6.ReadOnly = true;
            this.txtCredit6.Size = new System.Drawing.Size(572, 14);
            this.txtCredit6.TabIndex = 1159;
            this.txtCredit6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDebit6
            // 
            this.txtDebit6.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtDebit6.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDebit6.ButtonCustom.Visible = true;
            this.txtDebit6.Enabled = false;
            this.txtDebit6.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtDebit6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtDebit6.Location = new System.Drawing.Point(116, 26);
            this.txtDebit6.Name = "txtDebit6";
            this.txtDebit6.ReadOnly = true;
            this.txtDebit6.Size = new System.Drawing.Size(572, 14);
            this.txtDebit6.TabIndex = 1157;
            this.txtDebit6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label39.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label39.Location = new System.Drawing.Point(751, 19);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(99, 21);
            this.label39.TabIndex = 1155;
            this.label39.Text = "بالريــــال";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTotDis
            // 
            this.txtTotDis.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtTotDis.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtTotDis.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTotDis.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtTotDis.DisplayFormat = "0.00";
            this.txtTotDis.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtTotDis.Increment = 0D;
            this.txtTotDis.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtTotDis.IsInputReadOnly = true;
            this.txtTotDis.Location = new System.Drawing.Point(852, 42);
            this.txtTotDis.MinValue = 0D;
            this.txtTotDis.Name = "txtTotDis";
            this.txtTotDis.Size = new System.Drawing.Size(99, 21);
            this.txtTotDis.TabIndex = 1153;
            // 
            // txtTotDisLoc
            // 
            this.txtTotDisLoc.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtTotDisLoc.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(227)))), ((int)(((byte)(231)))));
            this.txtTotDisLoc.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtTotDisLoc.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTotDisLoc.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtTotDisLoc.DisplayFormat = "0.00";
            this.txtTotDisLoc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtTotDisLoc.Increment = 0D;
            this.txtTotDisLoc.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtTotDisLoc.IsInputReadOnly = true;
            this.txtTotDisLoc.Location = new System.Drawing.Point(751, 42);
            this.txtTotDisLoc.MinValue = 0D;
            this.txtTotDisLoc.Name = "txtTotDisLoc";
            this.txtTotDisLoc.Size = new System.Drawing.Size(99, 21);
            this.txtTotDisLoc.TabIndex = 1154;
            // 
            // checkBox_GaidDis
            // 
            this.checkBox_GaidDis.AutoSize = true;
            this.checkBox_GaidDis.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.checkBox_GaidDis.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.checkBox_GaidDis.BackgroundStyle.TextShadowColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox_GaidDis.BackgroundStyle.TextShadowOffset = new System.Drawing.Point(3, 3);
            this.checkBox_GaidDis.CheckSignSize = new System.Drawing.Size(14, 14);
            this.checkBox_GaidDis.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.checkBox_GaidDis.Location = new System.Drawing.Point(7, 44);
            this.checkBox_GaidDis.Name = "checkBox_GaidDis";
            this.checkBox_GaidDis.Size = new System.Drawing.Size(97, 16);
            this.checkBox_GaidDis.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.checkBox_GaidDis.TabIndex = 1156;
            this.checkBox_GaidDis.Text = "سند محاسبي";
            // 
            // superTabItem_Dis
            // 
            this.superTabItem_Dis.AttachedControl = this.superTabControlPanel7;
            this.superTabItem_Dis.GlobalItem = false;
            this.superTabItem_Dis.Name = "superTabItem_Dis";
            this.superTabItem_Dis.Text = "الخصـــــم";
            // 
            // superTabControlPanel6
            // 
            this.superTabControlPanel6.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2013;
            this.superTabControlPanel6.Controls.Add(this.switchButton_Tax);
            this.superTabControlPanel6.Controls.Add(this.label34);
            this.superTabControlPanel6.Controls.Add(this.label35);
            this.superTabControlPanel6.Controls.Add(this.button_CustC5);
            this.superTabControlPanel6.Controls.Add(this.txtCredit5);
            this.superTabControlPanel6.Controls.Add(this.button_CustD5);
            this.superTabControlPanel6.Controls.Add(this.txtDebit5);
            this.superTabControlPanel6.Controls.Add(this.checkBox_CostGaidTax);
            this.superTabControlPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel6.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel6.Name = "superTabControlPanel6";
            this.superTabControlPanel6.Size = new System.Drawing.Size(1266, 88);
            this.superTabControlPanel6.TabIndex = 1;
            this.superTabControlPanel6.TabItem = this.superTabItem_Tax;
            // 
            // switchButton_Tax
            // 
            // 
            // 
            // 
            this.switchButton_Tax.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.switchButton_Tax.Font = new System.Drawing.Font("Tahoma", 7F);
            this.switchButton_Tax.Location = new System.Drawing.Point(6, 20);
            this.switchButton_Tax.Name = "switchButton_Tax";
            this.switchButton_Tax.OffBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(80)))), ((int)(((byte)(77)))));
            this.switchButton_Tax.OffText = "غير معتمد";
            this.switchButton_Tax.OffTextColor = System.Drawing.Color.White;
            this.switchButton_Tax.OnText = "معتمد";
            this.switchButton_Tax.Size = new System.Drawing.Size(104, 21);
            this.switchButton_Tax.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.switchButton_Tax.TabIndex = 1152;
            this.switchButton_Tax.Value = true;
            this.switchButton_Tax.ValueObject = "Y";
            this.switchButton_Tax.ValueChanged += new System.EventHandler(this.switchButton_Tax_ValueChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.Transparent;
            this.label34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label34.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label34.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label34.Location = new System.Drawing.Point(706, 45);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(55, 13);
            this.label34.TabIndex = 1150;
            this.label34.Text = "الدائـــــن :";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.Transparent;
            this.label35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label35.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label35.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label35.Location = new System.Drawing.Point(706, 22);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(53, 13);
            this.label35.TabIndex = 1149;
            this.label35.Text = "المـــدين :";
            // 
            // button_CustC5
            // 
            this.button_CustC5.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_CustC5.Checked = true;
            this.button_CustC5.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_CustC5.Enabled = false;
            this.button_CustC5.Location = new System.Drawing.Point(295, 45);
            this.button_CustC5.Name = "button_CustC5";
            this.button_CustC5.Size = new System.Drawing.Size(15, 15);
            this.button_CustC5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_CustC5.Symbol = "";
            this.button_CustC5.SymbolSize = 7F;
            this.button_CustC5.TabIndex = 1148;
            this.button_CustC5.TextColor = System.Drawing.Color.SteelBlue;
            this.button_CustC5.Tooltip = "حساب العميل";
            // 
            // txtCredit5
            // 
            this.txtCredit5.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtCredit5.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtCredit5.ButtonCustom.Visible = true;
            this.txtCredit5.Enabled = false;
            this.txtCredit5.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCredit5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtCredit5.Location = new System.Drawing.Point(320, 44);
            this.txtCredit5.Name = "txtCredit5";
            this.txtCredit5.ReadOnly = true;
            this.txtCredit5.Size = new System.Drawing.Size(386, 14);
            this.txtCredit5.TabIndex = 1147;
            this.txtCredit5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_CustD5
            // 
            this.button_CustD5.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_CustD5.Checked = true;
            this.button_CustD5.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_CustD5.Enabled = false;
            this.button_CustD5.Location = new System.Drawing.Point(295, 22);
            this.button_CustD5.Name = "button_CustD5";
            this.button_CustD5.Size = new System.Drawing.Size(15, 15);
            this.button_CustD5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_CustD5.Symbol = "";
            this.button_CustD5.SymbolSize = 7F;
            this.button_CustD5.TabIndex = 1146;
            this.button_CustD5.TextColor = System.Drawing.Color.SteelBlue;
            this.button_CustD5.Tooltip = "حساب العميل";
            // 
            // txtDebit5
            // 
            this.txtDebit5.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtDebit5.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtDebit5.ButtonCustom.Visible = true;
            this.txtDebit5.Enabled = false;
            this.txtDebit5.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtDebit5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtDebit5.Location = new System.Drawing.Point(320, 21);
            this.txtDebit5.Name = "txtDebit5";
            this.txtDebit5.ReadOnly = true;
            this.txtDebit5.Size = new System.Drawing.Size(386, 14);
            this.txtDebit5.TabIndex = 1145;
            this.txtDebit5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // checkBox_CostGaidTax
            // 
            this.checkBox_CostGaidTax.AutoSize = true;
            this.checkBox_CostGaidTax.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.checkBox_CostGaidTax.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.checkBox_CostGaidTax.BackgroundStyle.TextShadowColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox_CostGaidTax.BackgroundStyle.TextShadowOffset = new System.Drawing.Point(3, 3);
            this.checkBox_CostGaidTax.CheckSignSize = new System.Drawing.Size(14, 14);
            this.checkBox_CostGaidTax.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.checkBox_CostGaidTax.Location = new System.Drawing.Point(7, 44);
            this.checkBox_CostGaidTax.Name = "checkBox_CostGaidTax";
            this.checkBox_CostGaidTax.Size = new System.Drawing.Size(97, 16);
            this.checkBox_CostGaidTax.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.checkBox_CostGaidTax.TabIndex = 1144;
            this.checkBox_CostGaidTax.Text = "سند محاسبي";
            this.checkBox_CostGaidTax.CheckedChanged += new System.EventHandler(this.checkBox_CostGaidTax_CheckedChanged);
            // 
            // superTabItem_Tax
            // 
            this.superTabItem_Tax.AttachedControl = this.superTabControlPanel6;
            this.superTabItem_Tax.GlobalItem = false;
            this.superTabItem_Tax.Name = "superTabItem_Tax";
            this.superTabItem_Tax.Text = "الضـــرائب";
            // 
            // superTabControlPanel8
            // 
            this.superTabControlPanel8.Controls.Add(this.label48);
            this.superTabControlPanel8.Controls.Add(this.label41);
            this.superTabControlPanel8.Controls.Add(this.txtCredit7);
            this.superTabControlPanel8.Controls.Add(this.label49);
            this.superTabControlPanel8.Controls.Add(this.txtTotBankComm);
            this.superTabControlPanel8.Controls.Add(this.txtTotBankCommLoc);
            this.superTabControlPanel8.Controls.Add(this.checkBox_GaidBankComm);
            this.superTabControlPanel8.Controls.Add(this.switchButton_BankComm);
            this.superTabControlPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel8.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel8.Name = "superTabControlPanel8";
            this.superTabControlPanel8.Size = new System.Drawing.Size(1266, 88);
            this.superTabControlPanel8.TabIndex = 2;
            this.superTabControlPanel8.TabItem = this.superTabItem_LocalComm;
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.Color.Transparent;
            this.label48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label48.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label48.ForeColor = System.Drawing.Color.Navy;
            this.label48.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label48.Location = new System.Drawing.Point(839, 20);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(99, 21);
            this.label48.TabIndex = 1163;
            this.label48.Text = "إجمالي القيمة";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label41.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label41.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label41.Location = new System.Drawing.Point(681, 47);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(55, 13);
            this.label41.TabIndex = 1162;
            this.label41.Text = "الدائـــــن :";
            // 
            // txtCredit7
            // 
            this.txtCredit7.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtCredit7.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtCredit7.ButtonCustom.Visible = true;
            this.txtCredit7.Enabled = false;
            this.txtCredit7.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCredit7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtCredit7.Location = new System.Drawing.Point(116, 46);
            this.txtCredit7.Name = "txtCredit7";
            this.txtCredit7.ReadOnly = true;
            this.txtCredit7.Size = new System.Drawing.Size(559, 14);
            this.txtCredit7.TabIndex = 1159;
            this.txtCredit7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label49.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label49.ForeColor = System.Drawing.Color.White;
            this.label49.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label49.Location = new System.Drawing.Point(738, 20);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(99, 21);
            this.label49.TabIndex = 1155;
            this.label49.Text = "بالريــــال";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTotBankComm
            // 
            this.txtTotBankComm.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtTotBankComm.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtTotBankComm.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTotBankComm.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtTotBankComm.DisplayFormat = "0.00";
            this.txtTotBankComm.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtTotBankComm.Increment = 0D;
            this.txtTotBankComm.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtTotBankComm.IsInputReadOnly = true;
            this.txtTotBankComm.Location = new System.Drawing.Point(839, 43);
            this.txtTotBankComm.MinValue = 0D;
            this.txtTotBankComm.Name = "txtTotBankComm";
            this.txtTotBankComm.Size = new System.Drawing.Size(99, 21);
            this.txtTotBankComm.TabIndex = 1153;
            // 
            // txtTotBankCommLoc
            // 
            this.txtTotBankCommLoc.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtTotBankCommLoc.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(227)))), ((int)(((byte)(231)))));
            this.txtTotBankCommLoc.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtTotBankCommLoc.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTotBankCommLoc.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtTotBankCommLoc.DisplayFormat = "0.00";
            this.txtTotBankCommLoc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtTotBankCommLoc.Increment = 0D;
            this.txtTotBankCommLoc.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtTotBankCommLoc.IsInputReadOnly = true;
            this.txtTotBankCommLoc.Location = new System.Drawing.Point(738, 43);
            this.txtTotBankCommLoc.MinValue = 0D;
            this.txtTotBankCommLoc.Name = "txtTotBankCommLoc";
            this.txtTotBankCommLoc.Size = new System.Drawing.Size(99, 21);
            this.txtTotBankCommLoc.TabIndex = 1154;
            // 
            // checkBox_GaidBankComm
            // 
            this.checkBox_GaidBankComm.AutoSize = true;
            this.checkBox_GaidBankComm.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.checkBox_GaidBankComm.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.checkBox_GaidBankComm.BackgroundStyle.TextShadowColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox_GaidBankComm.BackgroundStyle.TextShadowOffset = new System.Drawing.Point(3, 3);
            this.checkBox_GaidBankComm.CheckSignSize = new System.Drawing.Size(14, 14);
            this.checkBox_GaidBankComm.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.checkBox_GaidBankComm.Location = new System.Drawing.Point(7, 45);
            this.checkBox_GaidBankComm.Name = "checkBox_GaidBankComm";
            this.checkBox_GaidBankComm.Size = new System.Drawing.Size(97, 16);
            this.checkBox_GaidBankComm.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.checkBox_GaidBankComm.TabIndex = 1156;
            this.checkBox_GaidBankComm.Text = "سند محاسبي";
            // 
            // switchButton_BankComm
            // 
            // 
            // 
            // 
            this.switchButton_BankComm.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.switchButton_BankComm.Font = new System.Drawing.Font("Tahoma", 8F);
            this.switchButton_BankComm.Location = new System.Drawing.Point(7, 20);
            this.switchButton_BankComm.Name = "switchButton_BankComm";
            this.switchButton_BankComm.OffBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(80)))), ((int)(((byte)(77)))));
            this.switchButton_BankComm.OffText = "عدم احتساب";
            this.switchButton_BankComm.OffTextColor = System.Drawing.Color.White;
            this.switchButton_BankComm.OnText = "احتساب";
            this.switchButton_BankComm.Size = new System.Drawing.Size(104, 21);
            this.switchButton_BankComm.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.switchButton_BankComm.SwitchWidth = 20;
            this.switchButton_BankComm.TabIndex = 1165;
            // 
            // superTabItem_LocalComm
            // 
            this.superTabItem_LocalComm.AttachedControl = this.superTabControlPanel8;
            this.superTabItem_LocalComm.GlobalItem = false;
            this.superTabItem_LocalComm.Name = "superTabItem_LocalComm";
            this.superTabItem_LocalComm.Text = "عمولات بنكية";
            // 
            // superTabControlPanel10
            // 
            this.superTabControlPanel10.Controls.Add(this.label44);
            this.superTabControlPanel10.Controls.Add(this.label45);
            this.superTabControlPanel10.Controls.Add(this.label46);
            this.superTabControlPanel10.Controls.Add(this.txtCredit8);
            this.superTabControlPanel10.Controls.Add(this.textBoxX4);
            this.superTabControlPanel10.Controls.Add(this.label47);
            this.superTabControlPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel10.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel10.Name = "superTabControlPanel10";
            this.superTabControlPanel10.Size = new System.Drawing.Size(1266, 88);
            this.superTabControlPanel10.TabIndex = 3;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.Color.Transparent;
            this.label44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label44.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label44.ForeColor = System.Drawing.Color.Navy;
            this.label44.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label44.Location = new System.Drawing.Point(437, 6);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(99, 21);
            this.label44.TabIndex = 1163;
            this.label44.Text = "إجمالي القيمة";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Transparent;
            this.label45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label45.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label45.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label45.Location = new System.Drawing.Point(279, 33);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(55, 13);
            this.label45.TabIndex = 1162;
            this.label45.Text = "الدائـــــن :";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label46.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label46.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label46.Location = new System.Drawing.Point(279, 10);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(53, 13);
            this.label46.TabIndex = 1161;
            this.label46.Text = "المـــدين :";
            // 
            // txtCredit8
            // 
            this.txtCredit8.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.txtCredit8.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtCredit8.ButtonCustom.Visible = true;
            this.txtCredit8.Enabled = false;
            this.txtCredit8.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCredit8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtCredit8.Location = new System.Drawing.Point(116, 32);
            this.txtCredit8.Name = "txtCredit8";
            this.txtCredit8.ReadOnly = true;
            this.txtCredit8.Size = new System.Drawing.Size(163, 14);
            this.txtCredit8.TabIndex = 1159;
            this.txtCredit8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxX4
            // 
            this.textBoxX4.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.textBoxX4.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX4.ButtonCustom.Visible = true;
            this.textBoxX4.Enabled = false;
            this.textBoxX4.Font = new System.Drawing.Font("Tahoma", 8F);
            this.textBoxX4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBoxX4.Location = new System.Drawing.Point(116, 9);
            this.textBoxX4.Name = "textBoxX4";
            this.textBoxX4.ReadOnly = true;
            this.textBoxX4.Size = new System.Drawing.Size(163, 14);
            this.textBoxX4.TabIndex = 1157;
            this.textBoxX4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label47.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.label47.ForeColor = System.Drawing.Color.White;
            this.label47.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label47.Location = new System.Drawing.Point(336, 6);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(99, 21);
            this.label47.TabIndex = 1155;
            this.label47.Text = "بالريــــال";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // switchButton_TaxLines
            // 
            this.switchButton_TaxLines.ButtonWidth = 29;
            this.switchButton_TaxLines.Name = "switchButton_TaxLines";
            this.switchButton_TaxLines.OffBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(80)))), ((int)(((byte)(77)))));
            this.switchButton_TaxLines.OffText = "سطور الضريبة";
            this.switchButton_TaxLines.OffTextColor = System.Drawing.Color.White;
            this.switchButton_TaxLines.OnText = "سطور الضريبة";
            this.switchButton_TaxLines.SwitchWidth = 20;
            this.switchButton_TaxLines.Value = true;
            // 
            // switchButton_TaxByTotal
            // 
            this.switchButton_TaxByTotal.ButtonWidth = 110;
            this.switchButton_TaxByTotal.Name = "switchButton_TaxByTotal";
            this.switchButton_TaxByTotal.OffBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(80)))), ((int)(((byte)(77)))));
            this.switchButton_TaxByTotal.OffText = "إجمالي السطر";
            this.switchButton_TaxByTotal.OffTextColor = System.Drawing.Color.White;
            this.switchButton_TaxByTotal.OnText = "إجمالي السطر";
            this.switchButton_TaxByTotal.SwitchWidth = 20;
            // 
            // switchButton_TaxByNet
            // 
            this.switchButton_TaxByNet.ButtonWidth = 100;
            this.switchButton_TaxByNet.Name = "switchButton_TaxByNet";
            this.switchButton_TaxByNet.OffBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(80)))), ((int)(((byte)(77)))));
            this.switchButton_TaxByNet.OffText = "الصـافي";
            this.switchButton_TaxByNet.OffTextColor = System.Drawing.Color.White;
            this.switchButton_TaxByNet.OnText = "الصـافي";
            this.switchButton_TaxByNet.SwitchWidth = 20;
            // 
            // textBoxItem_TaxByNetValue
            // 
            this.textBoxItem_TaxByNetValue.Name = "textBoxItem_TaxByNetValue";
            this.textBoxItem_TaxByNetValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxItem_TaxByNetValue.Visible = false;
            this.textBoxItem_TaxByNetValue.WatermarkColor = System.Drawing.SystemColors.GrayText;
            this.textBoxItem_TaxByNetValue.WatermarkImageAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelItem_TaxByNetPer
            // 
            this.labelItem_TaxByNetPer.Name = "labelItem_TaxByNetPer";
            this.labelItem_TaxByNetPer.Text = "%";
            this.labelItem_TaxByNetPer.Visible = false;
            // 
            // ChkPriceIncludeTax
            // 
            this.ChkPriceIncludeTax.ButtonWidth = 155;
            this.ChkPriceIncludeTax.Name = "ChkPriceIncludeTax";
            this.ChkPriceIncludeTax.OffText = "السعر لا يشمل الضريبه";
            this.ChkPriceIncludeTax.OnText = "السعر شامل الضريبه";
            this.ChkPriceIncludeTax.SwitchWidth = 20;
            this.ChkPriceIncludeTax.ValueChanged += new System.EventHandler(this.ChkPriceIncludeTax_ValueChanged);
            // 
            // superTabItem_Gaids
            // 
            this.superTabItem_Gaids.AttachedControl = this.superTabControlPanel5;
            this.superTabItem_Gaids.GlobalItem = false;
            this.superTabItem_Gaids.Name = "superTabItem_Gaids";
            superTabLinearGradientColorTable5.Colors = new System.Drawing.Color[] {
        System.Drawing.Color.White};
            superTabItemStateColorTable2.Background = superTabLinearGradientColorTable5;
            superTabColorStates2.Normal = superTabItemStateColorTable2;
            superTabItemColorTable2.Bottom = superTabColorStates2;
            this.superTabItem_Gaids.TabColor = superTabItemColorTable2;
            this.superTabItem_Gaids.Text = "القيود";
            // 
            // superTabControlPanel2
            // 
            this.superTabControlPanel2.Controls.Add(this.txtSteel);
            this.superTabControlPanel2.Controls.Add(this.txtPayment);
            this.superTabControlPanel2.Controls.Add(this.label_LockeName);
            this.superTabControlPanel2.Controls.Add(this.label16);
            this.superTabControlPanel2.Controls.Add(this.label20);
            this.superTabControlPanel2.Controls.Add(this.label27);
            this.superTabControlPanel2.Controls.Add(this.doubleInput_LostOrWin);
            this.superTabControlPanel2.Controls.Add(this.label28);
            this.superTabControlPanel2.Controls.Add(this.txtTotalQ);
            this.superTabControlPanel2.Controls.Add(this.label30);
            this.superTabControlPanel2.Controls.Add(this.textBox_Usr);
            this.superTabControlPanel2.Controls.Add(this.label_Curr);
            this.superTabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel2.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel2.Name = "superTabControlPanel2";
            superTabLinearGradientColorTable6.Colors = new System.Drawing.Color[] {
        System.Drawing.Color.Gray,
        System.Drawing.Color.White};
            superTabPanelItemColorTable3.Background = superTabLinearGradientColorTable6;
            superTabPanelColorTable3.Bottom = superTabPanelItemColorTable3;
            this.superTabControlPanel2.PanelColor = superTabPanelColorTable3;
            this.superTabControlPanel2.Size = new System.Drawing.Size(1266, 88);
            this.superTabControlPanel2.TabIndex = 0;
            this.superTabControlPanel2.TabItem = this.superTabItem_Detiles;
            // 
            // txtSteel
            // 
            this.txtSteel.AllowEmptyState = false;
            this.txtSteel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtSteel.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtSteel.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtSteel.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtSteel.DisplayFormat = "0.00";
            this.txtSteel.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txtSteel.ForeColor = System.Drawing.Color.Black;
            this.txtSteel.Increment = 0D;
            this.txtSteel.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtSteel.IsInputReadOnly = true;
            this.txtSteel.Location = new System.Drawing.Point(735, 59);
            this.txtSteel.Name = "txtSteel";
            this.txtSteel.Size = new System.Drawing.Size(184, 21);
            this.txtSteel.TabIndex = 1121;
            this.txtSteel.ValueChanged += new System.EventHandler(this.txtSteel_ValueChanged);
            // 
            // txtPayment
            // 
            this.txtPayment.AllowEmptyState = false;
            this.txtPayment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtPayment.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtPayment.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtPayment.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtPayment.DisplayFormat = "0.00";
            this.txtPayment.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txtPayment.Increment = 0D;
            this.txtPayment.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtPayment.Location = new System.Drawing.Point(1015, 59);
            this.txtPayment.MinValue = 0D;
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.Size = new System.Drawing.Size(137, 21);
            this.txtPayment.TabIndex = 1120;
            this.txtPayment.Leave += new System.EventHandler(this.txtPayment_Leave);
            // 
            // label_LockeName
            // 
            this.label_LockeName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_LockeName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label_LockeName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_LockeName.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label_LockeName.ForeColor = System.Drawing.Color.Maroon;
            this.label_LockeName.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label_LockeName.Location = new System.Drawing.Point(384, 18);
            this.label_LockeName.Name = "label_LockeName";
            this.label_LockeName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label_LockeName.Size = new System.Drawing.Size(258, 43);
            this.label_LockeName.TabIndex = 1117;
            this.label_LockeName.Text = "--";
            this.label_LockeName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(920, 66);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 13);
            this.label16.TabIndex = 1116;
            this.label16.Text = "إجمالي المتبقي :";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label20.Location = new System.Drawing.Point(1154, 66);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(101, 13);
            this.label20.TabIndex = 1114;
            this.label20.Text = "المدفوع من العميل :";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label27.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label27.Location = new System.Drawing.Point(645, 66);
            this.label27.Name = "label27";
            this.label27.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label27.Size = new System.Drawing.Size(67, 14);
            this.label27.TabIndex = 1056;
            this.label27.Text = "المستخدم :";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // doubleInput_LostOrWin
            // 
            this.doubleInput_LostOrWin.AllowEmptyState = false;
            this.doubleInput_LostOrWin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.doubleInput_LostOrWin.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.doubleInput_LostOrWin.BackgroundStyle.Class = "DateTimeInputBackground";
            this.doubleInput_LostOrWin.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.doubleInput_LostOrWin.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.doubleInput_LostOrWin.DisplayFormat = "0.00";
            this.doubleInput_LostOrWin.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Bold);
            this.doubleInput_LostOrWin.ForeColor = System.Drawing.Color.White;
            this.doubleInput_LostOrWin.Increment = 0D;
            this.doubleInput_LostOrWin.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.doubleInput_LostOrWin.IsInputReadOnly = true;
            this.doubleInput_LostOrWin.Location = new System.Drawing.Point(736, 32);
            this.doubleInput_LostOrWin.Name = "doubleInput_LostOrWin";
            this.doubleInput_LostOrWin.Size = new System.Drawing.Size(184, 18);
            this.doubleInput_LostOrWin.TabIndex = 1055;
            // 
            // label28
            // 
            this.label28.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label28.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label28.Location = new System.Drawing.Point(920, 32);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(86, 14);
            this.label28.TabIndex = 1054;
            this.label28.Text = "صافـي الــربــح :";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTotalQ
            // 
            this.txtTotalQ.AllowEmptyState = false;
            this.txtTotalQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtTotalQ.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtTotalQ.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTotalQ.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtTotalQ.DisplayFormat = "0.00";
            this.txtTotalQ.Font = new System.Drawing.Font("Tahoma", 6.75F);
            this.txtTotalQ.Increment = 0D;
            this.txtTotalQ.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtTotalQ.IsInputReadOnly = true;
            this.txtTotalQ.Location = new System.Drawing.Point(1015, 32);
            this.txtTotalQ.Name = "txtTotalQ";
            this.txtTotalQ.Size = new System.Drawing.Size(137, 18);
            this.txtTotalQ.TabIndex = 1051;
            // 
            // label30
            // 
            this.label30.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label30.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label30.Location = new System.Drawing.Point(1154, 32);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(98, 14);
            this.label30.TabIndex = 1050;
            this.label30.Text = "إجمالــي الكميــة :";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox_Usr
            // 
            this.textBox_Usr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_Usr.BackColor = System.Drawing.Color.SteelBlue;
            this.textBox_Usr.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.textBox_Usr.ForeColor = System.Drawing.Color.White;
            this.textBox_Usr.Location = new System.Drawing.Point(383, 63);
            this.textBox_Usr.MaxLength = 30;
            this.textBox_Usr.Name = "textBox_Usr";
            this.textBox_Usr.ReadOnly = true;
            this.textBox_Usr.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox_Usr.Size = new System.Drawing.Size(259, 20);
            this.textBox_Usr.TabIndex = 1058;
            this.textBox_Usr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label_Curr
            // 
            this.label_Curr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Curr.BackColor = System.Drawing.Color.Transparent;
            this.label_Curr.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label_Curr.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label_Curr.Location = new System.Drawing.Point(645, 33);
            this.label_Curr.Name = "label_Curr";
            this.label_Curr.Size = new System.Drawing.Size(84, 14);
            this.label_Curr.TabIndex = 1059;
            this.label_Curr.Text = "العملة";
            this.label_Curr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // superTabItem_Detiles
            // 
            this.superTabItem_Detiles.AttachedControl = this.superTabControlPanel2;
            this.superTabItem_Detiles.GlobalItem = false;
            this.superTabItem_Detiles.Name = "superTabItem_Detiles";
            superTabLinearGradientColorTable7.Colors = new System.Drawing.Color[] {
        System.Drawing.Color.White};
            superTabItemStateColorTable3.Background = superTabLinearGradientColorTable7;
            superTabColorStates3.Normal = superTabItemStateColorTable3;
            superTabItemColorTable3.Bottom = superTabColorStates3;
            this.superTabItem_Detiles.TabColor = superTabItemColorTable3;
            this.superTabItem_Detiles.Text = "تفاصيل";
            // 
            // superTabControlPanel4
            // 
            this.superTabControlPanel4.Controls.Add(this.txtDescription);
            this.superTabControlPanel4.Controls.Add(this.label29);
            this.superTabControlPanel4.Controls.Add(this.label21);
            this.superTabControlPanel4.Controls.Add(this.txtDueDate);
            this.superTabControlPanel4.Controls.Add(this.labelPharmcy4);
            this.superTabControlPanel4.Controls.Add(this.label_Pharmacy5);
            this.superTabControlPanel4.Controls.Add(this.txtAllExchanged);
            this.superTabControlPanel4.Controls.Add(this.txtRemark);
            this.superTabControlPanel4.Controls.Add(this.label_Due);
            this.superTabControlPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel4.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel4.Name = "superTabControlPanel4";
            superTabLinearGradientColorTable8.Colors = new System.Drawing.Color[] {
        System.Drawing.Color.Gray,
        System.Drawing.Color.White};
            superTabPanelItemColorTable4.Background = superTabLinearGradientColorTable8;
            superTabPanelColorTable4.Bottom = superTabPanelItemColorTable4;
            this.superTabControlPanel4.PanelColor = superTabPanelColorTable4;
            this.superTabControlPanel4.Size = new System.Drawing.Size(1266, 88);
            this.superTabControlPanel4.TabIndex = 2;
            this.superTabControlPanel4.TabItem = this.superTabItem_Note;
            // 
            // txtDescription
            // 
            this.txtDescription.BackColor = System.Drawing.Color.Gainsboro;
            this.txtDescription.Location = new System.Drawing.Point(388, 75);
            this.txtDescription.MaxLength = 100;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(84, 20);
            this.txtDescription.TabIndex = 1125;
            // 
            // label29
            // 
            this.label29.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label29.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label29.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label29.Location = new System.Drawing.Point(1197, 79);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(64, 13);
            this.label29.TabIndex = 1126;
            this.label29.Text = "رقم الحاوية :";
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label21.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label21.Location = new System.Drawing.Point(99, 73);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(88, 22);
            this.label21.TabIndex = 482;
            this.label21.Text = "تاريخ الإستحقاق ";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDueDate
            // 
            this.txtDueDate.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtDueDate.Enabled = false;
            this.txtDueDate.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txtDueDate.Location = new System.Drawing.Point(5, 73);
            this.txtDueDate.Mask = "0000/00/00";
            this.txtDueDate.Name = "txtDueDate";
            this.txtDueDate.Size = new System.Drawing.Size(90, 21);
            this.txtDueDate.TabIndex = 481;
            this.txtDueDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDueDate.Click += new System.EventHandler(this.txtDueDate_Click);
            this.txtDueDate.Leave += new System.EventHandler(this.txtDueDate_Leave);
            // 
            // labelPharmcy4
            // 
            this.labelPharmcy4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelPharmcy4.AutoSize = true;
            this.labelPharmcy4.BackColor = System.Drawing.Color.Transparent;
            this.labelPharmcy4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelPharmcy4.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.labelPharmcy4.ForeColor = System.Drawing.Color.Black;
            this.labelPharmcy4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.labelPharmcy4.Location = new System.Drawing.Point(972, 209);
            this.labelPharmcy4.Name = "labelPharmcy4";
            this.labelPharmcy4.Size = new System.Drawing.Size(103, 15);
            this.labelPharmcy4.TabIndex = 1121;
            this.labelPharmcy4.Text = "المدفوع من العميل :";
            this.labelPharmcy4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Pharmacy5
            // 
            this.label_Pharmacy5.BackColor = System.Drawing.Color.Transparent;
            this.label_Pharmacy5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Pharmacy5.ForeColor = System.Drawing.Color.Black;
            this.label_Pharmacy5.Location = new System.Drawing.Point(622, 56);
            this.label_Pharmacy5.Name = "label_Pharmacy5";
            this.label_Pharmacy5.Size = new System.Drawing.Size(100, 23);
            this.label_Pharmacy5.TabIndex = 1124;
            // 
            // txtAllExchanged
            // 
            this.txtAllExchanged.AllowEmptyState = false;
            this.txtAllExchanged.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtAllExchanged.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtAllExchanged.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtAllExchanged.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtAllExchanged.DisplayFormat = "0.00";
            this.txtAllExchanged.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.txtAllExchanged.Increment = 0D;
            this.txtAllExchanged.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtAllExchanged.Location = new System.Drawing.Point(917, 202);
            this.txtAllExchanged.MinValue = 0D;
            this.txtAllExchanged.Name = "txtAllExchanged";
            this.txtAllExchanged.Size = new System.Drawing.Size(53, 21);
            this.txtAllExchanged.TabIndex = 1122;
            // 
            // txtRemark
            // 
            this.txtRemark.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtRemark.Border.Class = "TextBoxBorder";
            this.txtRemark.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtRemark.ButtonCustom.Image = ((System.Drawing.Image)(resources.GetObject("txtRemark.ButtonCustom.Image")));
            this.txtRemark.ButtonCustom.Visible = true;
            this.txtRemark.ButtonCustom2.Image = ((System.Drawing.Image)(resources.GetObject("txtRemark.ButtonCustom2.Image")));
            this.txtRemark.ButtonCustom2.Visible = true;
            this.txtRemark.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtRemark.ForeColor = System.Drawing.Color.Black;
            this.txtRemark.Location = new System.Drawing.Point(0, 0);
            this.txtRemark.Multiline = true;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(1266, 69);
            this.txtRemark.TabIndex = 480;
            this.txtRemark.WatermarkText = "ملاحظات الفاتورة";
            this.txtRemark.ButtonCustom2Click += new System.EventHandler(this.txtRemark_ButtonCustom2Click);
            // 
            // label_Due
            // 
            this.label_Due.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Due.BackColor = System.Drawing.Color.Transparent;
            this.label_Due.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Due.Font = new System.Drawing.Font("Tahoma", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label_Due.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label_Due.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label_Due.Location = new System.Drawing.Point(917, 73);
            this.label_Due.Name = "label_Due";
            this.label_Due.Size = new System.Drawing.Size(188, 22);
            this.label_Due.TabIndex = 483;
            this.label_Due.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // superTabItem_Note
            // 
            this.superTabItem_Note.AttachedControl = this.superTabControlPanel4;
            this.superTabItem_Note.GlobalItem = false;
            this.superTabItem_Note.Name = "superTabItem_Note";
            superTabLinearGradientColorTable9.Colors = new System.Drawing.Color[] {
        System.Drawing.Color.White};
            superTabItemStateColorTable4.Background = superTabLinearGradientColorTable9;
            superTabColorStates4.Normal = superTabItemStateColorTable4;
            superTabItemColorTable4.Bottom = superTabColorStates4;
            this.superTabItem_Note.TabColor = superTabItemColorTable4;
            this.superTabItem_Note.Text = "ملاحظات";
            // 
            // checkBoxItem_BarCode
            // 
            this.checkBoxItem_BarCode.Name = "checkBoxItem_BarCode";
            this.checkBoxItem_BarCode.ShowSubItems = false;
            this.checkBoxItem_BarCode.Text = "قراءه تلقائية";
            this.checkBoxItem_BarCode.CheckedChanged += new DevComponents.DotNetBar.CheckBoxChangeEventHandler(this.checkBoxItem_BarCode_CheckedChanged);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Magenta;
            this.imageList1.Images.SetKeyName(0, "");
            this.imageList1.Images.SetKeyName(1, "");
            this.imageList1.Images.SetKeyName(2, "");
            this.imageList1.Images.SetKeyName(3, "");
            this.imageList1.Images.SetKeyName(4, "");
            this.imageList1.Images.SetKeyName(5, "");
            this.imageList1.Images.SetKeyName(6, "");
            this.imageList1.Images.SetKeyName(7, "");
            this.imageList1.Images.SetKeyName(8, "");
            this.imageList1.Images.SetKeyName(9, "");
            this.imageList1.Images.SetKeyName(10, "");
            this.imageList1.Images.SetKeyName(11, "");
            this.imageList1.Images.SetKeyName(12, "");
            this.imageList1.Images.SetKeyName(13, "");
            this.imageList1.Images.SetKeyName(14, "");
            this.imageList1.Images.SetKeyName(15, "");
            this.imageList1.Images.SetKeyName(16, "");
            this.imageList1.Images.SetKeyName(17, "");
            this.imageList1.Images.SetKeyName(18, "");
            this.imageList1.Images.SetKeyName(19, "");
            this.imageList1.Images.SetKeyName(20, "");
            this.imageList1.Images.SetKeyName(21, "");
            this.imageList1.Images.SetKeyName(22, "");
            this.imageList1.Images.SetKeyName(23, "");
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_Det,
            this.ToolStripMenuItem_Rep});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextMenuStrip2.Size = new System.Drawing.Size(149, 48);
            // 
            // ToolStripMenuItem_Det
            // 
            this.ToolStripMenuItem_Det.Name = "ToolStripMenuItem_Det";
            this.ToolStripMenuItem_Det.Size = new System.Drawing.Size(148, 22);
            this.ToolStripMenuItem_Det.Text = "إظهار التفاصيل";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.DefaultExt = "*.rtf";
            this.openFileDialog1.Filter = "Text Files (*.txt)|*.txt|RTF Files (*.rtf)|*.rtf|All Files(*.*)|*.*";
            this.openFileDialog1.FilterIndex = 2;
            this.openFileDialog1.Title = "Open File";
            // 
            // timerInfoBallon
            // 
            this.timerInfoBallon.Interval = 3000;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "*.rtf";
            this.saveFileDialog1.FileName = "doc1";
            this.saveFileDialog1.Filter = "Text Files (*.txt)|*.txt|RTF Files (*.rtf)|*.rtf|All Files(*.*)|*.*";
            this.saveFileDialog1.FilterIndex = 2;
            this.saveFileDialog1.Title = "Save File";
            // 
            // panelEx3
            // 
            this.panelEx3.Controls.Add(this.DGV_Main);
            this.panelEx3.Controls.Add(this.ribbonBar_DGV);
            this.panelEx3.DisabledBackColor = System.Drawing.Color.Empty;
            this.panelEx3.Location = new System.Drawing.Point(0, -10);
            this.panelEx3.Name = "panelEx3";
            this.panelEx3.Size = new System.Drawing.Size(1163, 10);
            this.panelEx3.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx3.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.panelEx3.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground2;
            this.panelEx3.Style.BackgroundImagePosition = DevComponents.DotNetBar.eBackgroundImagePosition.Tile;
            this.panelEx3.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelEx3.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelEx3.Style.GradientAngle = 90;
            this.panelEx3.TabIndex = 2;
            this.panelEx3.Text = "Fill Panel";
            // 
            // DGV_Main
            // 
            this.DGV_Main.BackColor = System.Drawing.Color.Transparent;
            background1.BackFillType = DevComponents.DotNetBar.SuperGrid.Style.BackFillType.VerticalCenter;
            background1.Color1 = System.Drawing.Color.Silver;
            background1.Color2 = System.Drawing.Color.White;
            this.DGV_Main.DefaultVisualStyles.GroupByStyles.Default.Background = background1;
            background2.BackFillType = DevComponents.DotNetBar.SuperGrid.Style.BackFillType.Center;
            background2.Color1 = System.Drawing.Color.LightSteelBlue;
            this.DGV_Main.DefaultVisualStyles.RowStyles.Default.Background = background2;
            background3.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.DGV_Main.DefaultVisualStyles.RowStyles.MouseOver.Background = background3;
            this.DGV_Main.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.DGV_Main.Font = new System.Drawing.Font("Tahoma", 9F);
            this.DGV_Main.ForeColor = System.Drawing.Color.Black;
            this.DGV_Main.Location = new System.Drawing.Point(0, -10);
            this.DGV_Main.Name = "DGV_Main";
            // 
            // 
            // 
            this.DGV_Main.PrimaryGrid.ActiveRowIndicatorStyle = DevComponents.DotNetBar.SuperGrid.ActiveRowIndicatorStyle.Both;
            this.DGV_Main.PrimaryGrid.AllowEdit = false;
            // 
            // 
            // 
            this.DGV_Main.PrimaryGrid.Caption.BackgroundImageLayout = DevComponents.DotNetBar.SuperGrid.GridBackgroundImageLayout.Center;
            this.DGV_Main.PrimaryGrid.Caption.Text = "";
            this.DGV_Main.PrimaryGrid.Caption.Visible = false;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.AllowWrap = DevComponents.DotNetBar.SuperGrid.Style.Tbool.False;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.AlternateColumnCellStyles.Default.TextColor = System.Drawing.Color.Black;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.AllowWrap = DevComponents.DotNetBar.SuperGrid.Style.Tbool.False;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.AlternateRowCellStyles.Default.TextColor = System.Drawing.Color.Black;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.CaptionStyles.Default.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.CaptionStyles.Default.TextColor = System.Drawing.Color.White;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.CaptionStyles.ReadOnly.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.CellStyles.Selected.Alignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.ColumnHeaderRowStyles.Default.RowHeader.AllowWrap = DevComponents.DotNetBar.SuperGrid.Style.Tbool.True;
            borderColor1.Bottom = System.Drawing.Color.Black;
            borderColor1.Left = System.Drawing.Color.Black;
            borderColor1.Right = System.Drawing.Color.Black;
            borderColor1.Top = System.Drawing.Color.Black;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.BorderColor = borderColor1;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.ColumnHeaderStyles.Default.TextColor = System.Drawing.Color.SteelBlue;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.FilterColumnHeaderStyles.Default.TextColor = System.Drawing.Color.White;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.FooterStyles.Default.TextColor = System.Drawing.Color.White;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.GridPanelStyle.AllowWrap = DevComponents.DotNetBar.SuperGrid.Style.Tbool.False;
            borderColor2.Bottom = System.Drawing.Color.Black;
            borderColor2.Left = System.Drawing.Color.Black;
            borderColor2.Right = System.Drawing.Color.Black;
            borderColor2.Top = System.Drawing.Color.Black;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.GridPanelStyle.BorderColor = borderColor2;
            baseTreeButtonVisualStyle1.BorderColor = System.Drawing.Color.White;
            baseTreeButtonVisualStyle1.LineColor = System.Drawing.Color.White;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.GridPanelStyle.CircleTreeButtonStyle.ExpandButton = baseTreeButtonVisualStyle1;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.GridPanelStyle.HeaderHLinePattern = DevComponents.DotNetBar.SuperGrid.Style.LinePattern.None;
            background4.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            baseTreeButtonVisualStyle2.Background = background4;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.GridPanelStyle.SquareTreeButtonStyle.ExpandButton = baseTreeButtonVisualStyle2;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.GridPanelStyle.TextColor = System.Drawing.Color.White;
            this.DGV_Main.PrimaryGrid.DefaultVisualStyles.TitleStyles.Default.RowHeaderStyle.TextAlignment = DevComponents.DotNetBar.SuperGrid.Style.Alignment.MiddleCenter;
            // 
            // 
            // 
            this.DGV_Main.PrimaryGrid.GroupByRow.RowHeaderVisibility = DevComponents.DotNetBar.SuperGrid.RowHeaderVisibility.Never;
            this.DGV_Main.PrimaryGrid.GroupByRow.Text = "جميــع السجــــلات";
            this.DGV_Main.PrimaryGrid.GroupByRow.Visible = true;
            this.DGV_Main.PrimaryGrid.GroupByRow.WatermarkText = "";
            this.DGV_Main.PrimaryGrid.InitialActiveRow = DevComponents.DotNetBar.SuperGrid.RelativeRow.None;
            this.DGV_Main.PrimaryGrid.InitialSelection = DevComponents.DotNetBar.SuperGrid.RelativeSelection.None;
            this.DGV_Main.PrimaryGrid.MultiSelect = false;
            this.DGV_Main.PrimaryGrid.ShowRowGridIndex = true;
            // 
            // 
            // 
            this.DGV_Main.PrimaryGrid.Title.AllowSelection = false;
            this.DGV_Main.PrimaryGrid.Title.Text = "";
            this.DGV_Main.PrimaryGrid.Title.Visible = false;
            this.DGV_Main.PrimaryGrid.Visible = false;
            this.DGV_Main.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.DGV_Main.Size = new System.Drawing.Size(1160, 10);
            this.DGV_Main.TabIndex = 874;
            this.DGV_Main.Tag = "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            // 
            // ribbonBar_DGV
            // 
            this.ribbonBar_DGV.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar_DGV.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar_DGV.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar_DGV.ContainerControlProcessDialogKey = true;
            this.ribbonBar_DGV.Controls.Add(this.superTabControl_DGV);
            this.ribbonBar_DGV.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ribbonBar_DGV.DragDropSupport = true;
            this.ribbonBar_DGV.Location = new System.Drawing.Point(0, -41);
            this.ribbonBar_DGV.Name = "ribbonBar_DGV";
            this.ribbonBar_DGV.Size = new System.Drawing.Size(1163, 51);
            this.ribbonBar_DGV.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar_DGV.TabIndex = 875;
            this.ribbonBar_DGV.Tag = "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            // 
            // 
            // 
            this.ribbonBar_DGV.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar_DGV.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar_DGV.TitleVisible = false;
            // 
            // superTabControl_DGV
            // 
            this.superTabControl_DGV.BackColor = System.Drawing.Color.White;
            this.superTabControl_DGV.CausesValidation = false;
            // 
            // 
            // 
            this.superTabControl_DGV.ControlBox.Category = null;
            // 
            // 
            // 
            this.superTabControl_DGV.ControlBox.CloseBox.Category = null;
            this.superTabControl_DGV.ControlBox.CloseBox.Description = null;
            this.superTabControl_DGV.ControlBox.CloseBox.Name = "";
            this.superTabControl_DGV.ControlBox.Description = null;
            // 
            // 
            // 
            this.superTabControl_DGV.ControlBox.MenuBox.Category = null;
            this.superTabControl_DGV.ControlBox.MenuBox.Description = null;
            this.superTabControl_DGV.ControlBox.MenuBox.Name = "";
            this.superTabControl_DGV.ControlBox.Name = "";
            this.superTabControl_DGV.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl_DGV.ControlBox.MenuBox,
            this.superTabControl_DGV.ControlBox.CloseBox});
            this.superTabControl_DGV.ControlBox.Visible = false;
            this.superTabControl_DGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControl_DGV.ForeColor = System.Drawing.Color.Black;
            this.superTabControl_DGV.ItemPadding.Bottom = 4;
            this.superTabControl_DGV.ItemPadding.Left = 4;
            this.superTabControl_DGV.ItemPadding.Right = 4;
            this.superTabControl_DGV.ItemPadding.Top = 4;
            this.superTabControl_DGV.Location = new System.Drawing.Point(0, 0);
            this.superTabControl_DGV.Name = "superTabControl_DGV";
            this.superTabControl_DGV.ReorderTabsEnabled = true;
            this.superTabControl_DGV.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.superTabControl_DGV.SelectedTabFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.superTabControl_DGV.SelectedTabIndex = -1;
            this.superTabControl_DGV.Size = new System.Drawing.Size(1163, 51);
            this.superTabControl_DGV.TabFont = new System.Drawing.Font("Tahoma", 8F);
            this.superTabControl_DGV.TabIndex = 12;
            this.superTabControl_DGV.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.textBox_search,
            this.Button_ExportTable2,
            this.Button_PrintTable,
            this.Button_PrintTableMulti,
            this.labelItem3});
            this.superTabControl_DGV.TabStyle = DevComponents.DotNetBar.eSuperTabStyle.WinMediaPlayer12;
            this.superTabControl_DGV.Text = "superTabControl1";
            this.superTabControl_DGV.TextAlignment = DevComponents.DotNetBar.eItemAlignment.Center;
            // 
            // textBox_search
            // 
            this.textBox_search.ButtonCustom.Text = "...";
            this.textBox_search.ButtonCustom.Visible = true;
            this.textBox_search.Name = "textBox_search";
            this.textBox_search.TextBoxHeight = 44;
            this.textBox_search.TextBoxWidth = 150;
            this.textBox_search.WatermarkColor = System.Drawing.SystemColors.GrayText;
            // 
            // Button_ExportTable2
            // 
            this.Button_ExportTable2.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_ExportTable2.FontBold = true;
            this.Button_ExportTable2.FontItalic = true;
            this.Button_ExportTable2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Button_ExportTable2.Image = ((System.Drawing.Image)(resources.GetObject("Button_ExportTable2.Image")));
            this.Button_ExportTable2.ImageFixedSize = new System.Drawing.Size(32, 32);
            this.Button_ExportTable2.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_ExportTable2.Name = "Button_ExportTable2";
            this.Button_ExportTable2.SubItemsExpandWidth = 14;
            this.Button_ExportTable2.Symbol = "";
            this.Button_ExportTable2.SymbolSize = 15F;
            this.Button_ExportTable2.Text = "تصدير";
            this.Button_ExportTable2.Tooltip = "تصدير الى الأكسيل";
            // 
            // Button_PrintTable
            // 
            this.Button_PrintTable.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_PrintTable.Checked = true;
            this.Button_PrintTable.FontBold = true;
            this.Button_PrintTable.FontItalic = true;
            this.Button_PrintTable.Image = ((System.Drawing.Image)(resources.GetObject("Button_PrintTable.Image")));
            this.Button_PrintTable.ImageFixedSize = new System.Drawing.Size(32, 32);
            this.Button_PrintTable.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_PrintTable.Name = "Button_PrintTable";
            this.Button_PrintTable.SubItemsExpandWidth = 14;
            this.Button_PrintTable.Symbol = "";
            this.Button_PrintTable.SymbolSize = 15F;
            this.Button_PrintTable.Text = "طباعة";
            this.Button_PrintTable.Tooltip = "طباعة";
            // 
            // Button_PrintTableMulti
            // 
            this.Button_PrintTableMulti.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_PrintTableMulti.ColorTable = DevComponents.DotNetBar.eButtonColor.Office2007WithBackground;
            this.Button_PrintTableMulti.FontBold = true;
            this.Button_PrintTableMulti.FontItalic = true;
            this.Button_PrintTableMulti.Image = ((System.Drawing.Image)(resources.GetObject("Button_PrintTableMulti.Image")));
            this.Button_PrintTableMulti.ImageFixedSize = new System.Drawing.Size(32, 32);
            this.Button_PrintTableMulti.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_PrintTableMulti.Name = "Button_PrintTableMulti";
            this.Button_PrintTableMulti.SubItemsExpandWidth = 14;
            this.Button_PrintTableMulti.Symbol = "";
            this.Button_PrintTableMulti.SymbolSize = 15F;
            this.Button_PrintTableMulti.Text = "طباعة الفواتير المحددة";
            this.Button_PrintTableMulti.Tooltip = "طباعة الفواتير المحددة";
            this.Button_PrintTableMulti.Click += new System.EventHandler(this.Button_PrintTableMulti_Click);
            // 
            // labelItem3
            // 
            this.labelItem3.Name = "labelItem3";
            this.labelItem3.Width = 40;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            // 
            // panelEx2
            // 
            this.panelEx2.Controls.Add(this.ribbonBar1);
            this.panelEx2.DisabledBackColor = System.Drawing.Color.Empty;
            this.panelEx2.Location = new System.Drawing.Point(0, 57);
            this.panelEx2.MinimumSize = new System.Drawing.Size(824, 500);
            this.panelEx2.Name = "panelEx2";
            this.panelEx2.Size = new System.Drawing.Size(1109, 500);
            this.panelEx2.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx2.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelEx2.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelEx2.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelEx2.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelEx2.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelEx2.Style.GradientAngle = 90;
            this.panelEx2.TabIndex = 0;
            this.panelEx2.Text = "Click to collapse";
            // 
            // ribbonBar_Tasks
            // 
            this.ribbonBar_Tasks.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar_Tasks.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar_Tasks.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar_Tasks.ContainerControlProcessDialogKey = true;
            this.ribbonBar_Tasks.Controls.Add(this.superTabControl_Main1);
            this.ribbonBar_Tasks.Controls.Add(this.superTabControl_Main2);
            this.ribbonBar_Tasks.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ribbonBar_Tasks.DragDropSupport = true;
            this.ribbonBar_Tasks.Location = new System.Drawing.Point(3, 510);
            this.ribbonBar_Tasks.Name = "ribbonBar_Tasks";
            this.ribbonBar_Tasks.Size = new System.Drawing.Size(1272, 44);
            this.ribbonBar_Tasks.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar_Tasks.TabIndex = 871;
            this.ribbonBar_Tasks.Tag = "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            // 
            // 
            // 
            this.ribbonBar_Tasks.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar_Tasks.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar_Tasks.TitleVisible = false;
            // 
            // superTabControl_Main1
            // 
            this.superTabControl_Main1.BackColor = System.Drawing.Color.White;
            this.superTabControl_Main1.CausesValidation = false;
            // 
            // 
            // 
            this.superTabControl_Main1.ControlBox.Category = null;
            // 
            // 
            // 
            this.superTabControl_Main1.ControlBox.CloseBox.Category = null;
            this.superTabControl_Main1.ControlBox.CloseBox.Description = null;
            this.superTabControl_Main1.ControlBox.CloseBox.Name = "";
            this.superTabControl_Main1.ControlBox.Description = null;
            // 
            // 
            // 
            this.superTabControl_Main1.ControlBox.MenuBox.Category = null;
            this.superTabControl_Main1.ControlBox.MenuBox.Description = null;
            this.superTabControl_Main1.ControlBox.MenuBox.Name = "";
            this.superTabControl_Main1.ControlBox.Name = "";
            this.superTabControl_Main1.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl_Main1.ControlBox.MenuBox,
            this.superTabControl_Main1.ControlBox.CloseBox});
            this.superTabControl_Main1.ControlBox.Visible = false;
            this.superTabControl_Main1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControl_Main1.ForeColor = System.Drawing.Color.Black;
            this.superTabControl_Main1.ItemPadding.Bottom = 4;
            this.superTabControl_Main1.ItemPadding.Left = 2;
            this.superTabControl_Main1.ItemPadding.Top = 4;
            this.superTabControl_Main1.Location = new System.Drawing.Point(0, 0);
            this.superTabControl_Main1.Name = "superTabControl_Main1";
            this.superTabControl_Main1.ReorderTabsEnabled = true;
            this.superTabControl_Main1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.superTabControl_Main1.SelectedTabFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.superTabControl_Main1.SelectedTabIndex = -1;
            this.superTabControl_Main1.Size = new System.Drawing.Size(689, 44);
            this.superTabControl_Main1.TabFont = new System.Drawing.Font("Tahoma", 8F);
            this.superTabControl_Main1.TabIndex = 10;
            this.superTabControl_Main1.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Button_BarcodPrint,
            this.ButReturn,
            this.button_Repetition,
            this.Button_Close,
            this.buttonItem_Print,
            this.Button_Search,
            this.Button_Delete,
            this.Button_Save,
            this.Button_Add,
            this.ChkA4Cahir,
            this.checkBoxItem_BarCode,
            this.buttonItem2});
            superTabLinearGradientColorTable10.Colors = new System.Drawing.Color[] {
        System.Drawing.Color.White};
            superTabColorTable2.Background = superTabLinearGradientColorTable10;
            this.superTabControl_Main1.TabStripColor = superTabColorTable2;
            this.superTabControl_Main1.TabStyle = DevComponents.DotNetBar.eSuperTabStyle.WinMediaPlayer12;
            this.superTabControl_Main1.Text = "superTabControl3";
            this.superTabControl_Main1.TextAlignment = DevComponents.DotNetBar.eItemAlignment.Center;
            this.superTabControl_Main1.SelectedTabChanged += new System.EventHandler<DevComponents.DotNetBar.SuperTabStripSelectedTabChangedEventArgs>(this.superTabControl_Main1_SelectedTabChanged);
            // 
            // Button_BarcodPrint
            // 
            this.Button_BarcodPrint.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_BarcodPrint.ColorTable = DevComponents.DotNetBar.eButtonColor.Office2007WithBackground;
            this.Button_BarcodPrint.FontBold = true;
            this.Button_BarcodPrint.ForeColor = System.Drawing.Color.Black;
            this.Button_BarcodPrint.Image = ((System.Drawing.Image)(resources.GetObject("Button_BarcodPrint.Image")));
            this.Button_BarcodPrint.ImageFixedSize = new System.Drawing.Size(22, 22);
            this.Button_BarcodPrint.ImagePaddingVertical = 11;
            this.Button_BarcodPrint.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_BarcodPrint.Name = "Button_BarcodPrint";
            this.Button_BarcodPrint.Stretch = true;
            this.Button_BarcodPrint.SubItemsExpandWidth = 11;
            this.Button_BarcodPrint.Symbol = "";
            this.Button_BarcodPrint.SymbolSize = 14F;
            this.Button_BarcodPrint.Text = "BC";
            this.Button_BarcodPrint.Click += new System.EventHandler(this.Button_BarcodPrint_Click);
            // 
            // ButReturn
            // 
            this.ButReturn.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.ButReturn.Checked = true;
            this.ButReturn.FontBold = true;
            this.ButReturn.FontItalic = true;
            this.ButReturn.ForeColor = System.Drawing.Color.Crimson;
            this.ButReturn.Image = ((System.Drawing.Image)(resources.GetObject("ButReturn.Image")));
            this.ButReturn.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.ButReturn.ImagePaddingHorizontal = 15;
            this.ButReturn.ImagePaddingVertical = 11;
            this.ButReturn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.ButReturn.Name = "ButReturn";
            this.ButReturn.Stretch = true;
            this.ButReturn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.ButReturnShow,
            this.ButPurchaseShow,
            this.ButOutGoodShow,
            this.buttonItem1,
            this.ButEnterGoodShow});
            this.ButReturn.SubItemsExpandWidth = 14;
            this.ButReturn.Symbol = "";
            this.ButReturn.SymbolSize = 15F;
            this.ButReturn.Visible = false;
            this.ButReturn.Click += new System.EventHandler(this.ButReturn_Click);
            // 
            // ButReturnShow
            // 
            this.ButReturnShow.Checked = true;
            this.ButReturnShow.Name = "ButReturnShow";
            this.ButReturnShow.Symbol = "";
            this.ButReturnShow.Text = "عروض الأسعـــــار";
            this.ButReturnShow.Click += new System.EventHandler(this.ButReturnShow_Click);
            // 
            // ButPurchaseShow
            // 
            this.ButPurchaseShow.BeginGroup = true;
            this.ButPurchaseShow.Name = "ButPurchaseShow";
            this.ButPurchaseShow.Symbol = "";
            this.ButPurchaseShow.Text = "فواتير المشتريــات";
            this.ButPurchaseShow.Visible = false;
            this.ButPurchaseShow.Click += new System.EventHandler(this.ButPurchaseShow_Click);
            // 
            // ButOutGoodShow
            // 
            this.ButOutGoodShow.Name = "ButOutGoodShow";
            this.ButOutGoodShow.Symbol = "";
            this.ButOutGoodShow.Text = "فواتير إخراج بضاعة";
            this.ButOutGoodShow.Visible = false;
            this.ButOutGoodShow.Click += new System.EventHandler(this.ButOutGoodShow_Click);
            // 
            // buttonItem1
            // 
            this.buttonItem1.Name = "buttonItem1";
            this.buttonItem1.Text = "الفواتير المعلقة";
            this.buttonItem1.Visible = false;
            this.buttonItem1.Click += new System.EventHandler(this.buttonItem1_Click_1);
            // 
            // ButEnterGoodShow
            // 
            this.ButEnterGoodShow.Name = "ButEnterGoodShow";
            this.ButEnterGoodShow.Symbol = "";
            this.ButEnterGoodShow.Text = "فواتير إدخال بضاعة";
            this.ButEnterGoodShow.Visible = false;
            this.ButEnterGoodShow.Click += new System.EventHandler(this.ButEnterGoodShow_Click);
            // 
            // button_Repetition
            // 
            this.button_Repetition.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.button_Repetition.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueWithBackground;
            this.button_Repetition.FontBold = true;
            this.button_Repetition.FontItalic = true;
            this.button_Repetition.ForeColor = System.Drawing.Color.Maroon;
            this.button_Repetition.Image = ((System.Drawing.Image)(resources.GetObject("button_Repetition.Image")));
            this.button_Repetition.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.button_Repetition.ImagePaddingHorizontal = 15;
            this.button_Repetition.ImagePaddingVertical = 11;
            this.button_Repetition.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.button_Repetition.Name = "button_Repetition";
            this.button_Repetition.Stretch = true;
            this.button_Repetition.SubItemsExpandWidth = 14;
            this.button_Repetition.Symbol = "";
            this.button_Repetition.SymbolSize = 15F;
            this.button_Repetition.Text = "تكرار";
            this.button_Repetition.Click += new System.EventHandler(this.button_Repetition_Click);
            // 
            // Button_Close
            // 
            this.Button_Close.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_Close.Checked = true;
            this.Button_Close.FontBold = true;
            this.Button_Close.FontItalic = true;
            this.Button_Close.ForeColor = System.Drawing.Color.Black;
            this.Button_Close.Image = ((System.Drawing.Image)(resources.GetObject("Button_Close.Image")));
            this.Button_Close.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.Button_Close.ImagePaddingHorizontal = 15;
            this.Button_Close.ImagePaddingVertical = 11;
            this.Button_Close.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_Close.Name = "Button_Close";
            this.Button_Close.Stretch = true;
            this.Button_Close.SubItemsExpandWidth = 14;
            this.Button_Close.Symbol = "";
            this.Button_Close.SymbolSize = 15F;
            this.Button_Close.Text = "إغلاق";
            this.Button_Close.Tooltip = "إغلاق النافذة الحالية";
            // 
            // buttonItem_Print
            // 
            this.buttonItem_Print.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem_Print.FontBold = true;
            this.buttonItem_Print.FontItalic = true;
            this.buttonItem_Print.ForeColor = System.Drawing.Color.DimGray;
            this.buttonItem_Print.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem_Print.Image")));
            this.buttonItem_Print.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.buttonItem_Print.ImagePaddingHorizontal = 15;
            this.buttonItem_Print.ImagePaddingVertical = 11;
            this.buttonItem_Print.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem_Print.Name = "buttonItem_Print";
            this.buttonItem_Print.Stretch = true;
            this.buttonItem_Print.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.printerSetting});
            this.buttonItem_Print.SubItemsExpandWidth = 14;
            this.buttonItem_Print.Symbol = "";
            this.buttonItem_Print.SymbolSize = 15F;
            this.buttonItem_Print.Text = "طباعة";
            this.buttonItem_Print.Tooltip = "طباعة السجل الحالي";
            this.buttonItem_Print.Click += new System.EventHandler(this.buttonItem_Print_Click);
            // 
            // printerSetting
            // 
            this.printerSetting.Name = "printerSetting";
            this.printerSetting.Symbol = "";
            this.printerSetting.Text = "اعدادات الطابعة";
            this.printerSetting.Click += new System.EventHandler(this.printerSetting_Click);
            // 
            // Button_Search
            // 
            this.Button_Search.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_Search.FontBold = true;
            this.Button_Search.FontItalic = true;
            this.Button_Search.ForeColor = System.Drawing.Color.Green;
            this.Button_Search.Image = ((System.Drawing.Image)(resources.GetObject("Button_Search.Image")));
            this.Button_Search.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.Button_Search.ImagePaddingHorizontal = 15;
            this.Button_Search.ImagePaddingVertical = 11;
            this.Button_Search.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_Search.Name = "Button_Search";
            this.Button_Search.Stretch = true;
            this.Button_Search.SubItemsExpandWidth = 14;
            this.Button_Search.Symbol = "";
            this.Button_Search.SymbolSize = 15F;
            this.Button_Search.Text = "بحث";
            this.Button_Search.Tooltip = "البحث عن سجل ما";
            // 
            // Button_Delete
            // 
            this.Button_Delete.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_Delete.FontBold = true;
            this.Button_Delete.FontItalic = true;
            this.Button_Delete.ForeColor = System.Drawing.Color.SteelBlue;
            this.Button_Delete.Image = ((System.Drawing.Image)(resources.GetObject("Button_Delete.Image")));
            this.Button_Delete.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.Button_Delete.ImagePaddingHorizontal = 15;
            this.Button_Delete.ImagePaddingVertical = 11;
            this.Button_Delete.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_Delete.Name = "Button_Delete";
            this.Button_Delete.Stretch = true;
            this.Button_Delete.SubItemsExpandWidth = 14;
            this.Button_Delete.Symbol = "";
            this.Button_Delete.SymbolSize = 15F;
            this.Button_Delete.Text = "حذف";
            this.Button_Delete.Tooltip = "حذف السجل الحالي";
            // 
            // Button_Save
            // 
            this.Button_Save.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_Save.FontBold = true;
            this.Button_Save.FontItalic = true;
            this.Button_Save.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Button_Save.Image = ((System.Drawing.Image)(resources.GetObject("Button_Save.Image")));
            this.Button_Save.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.Button_Save.ImagePaddingHorizontal = 15;
            this.Button_Save.ImagePaddingVertical = 11;
            this.Button_Save.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_Save.Name = "Button_Save";
            this.Button_Save.Stretch = true;
            this.Button_Save.SubItemsExpandWidth = 14;
            this.Button_Save.Symbol = "";
            this.Button_Save.SymbolSize = 15F;
            this.Button_Save.Text = "حفظ";
            this.Button_Save.Tooltip = "حفظ التغييرات";
            this.Button_Save.Click += new System.EventHandler(this.Button_Save_Click_1);
            // 
            // Button_Add
            // 
            this.Button_Add.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_Add.FontBold = true;
            this.Button_Add.FontItalic = true;
            this.Button_Add.ForeColor = System.Drawing.Color.Blue;
            this.Button_Add.Image = ((System.Drawing.Image)(resources.GetObject("Button_Add.Image")));
            this.Button_Add.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.Button_Add.ImagePaddingHorizontal = 15;
            this.Button_Add.ImagePaddingVertical = 11;
            this.Button_Add.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_Add.Name = "Button_Add";
            this.Button_Add.Stretch = true;
            this.Button_Add.SubItemsExpandWidth = 14;
            this.Button_Add.Symbol = "";
            this.Button_Add.SymbolSize = 15F;
            this.Button_Add.Text = "إضافة";
            this.Button_Add.Tooltip = "إضافة سجل جديد";
            this.Button_Add.Click += new System.EventHandler(this.Button_Add_Click_1);
            // 
            // ChkA4Cahir
            // 
            this.ChkA4Cahir.CheckBoxPosition = DevComponents.DotNetBar.eCheckBoxPosition.Top;
            this.ChkA4Cahir.Name = "ChkA4Cahir";
            this.ChkA4Cahir.Text = "A4";
            this.ChkA4Cahir.Click += new System.EventHandler(this.checkBox_GaidBankComm_CheckedChanged);
            // 
            // buttonItem2
            // 
            this.buttonItem2.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem2.Name = "buttonItem2";
            this.buttonItem2.Symbol = "";
            this.buttonItem2.Text = "الطلبات";
            this.buttonItem2.Click += new System.EventHandler(this.buttonItem2_Click_1);
            // 
            // superTabControl_Main2
            // 
            this.superTabControl_Main2.BackColor = System.Drawing.Color.White;
            this.superTabControl_Main2.CausesValidation = false;
            // 
            // 
            // 
            this.superTabControl_Main2.ControlBox.Category = null;
            // 
            // 
            // 
            this.superTabControl_Main2.ControlBox.CloseBox.Category = null;
            this.superTabControl_Main2.ControlBox.CloseBox.Description = null;
            this.superTabControl_Main2.ControlBox.CloseBox.Name = "";
            this.superTabControl_Main2.ControlBox.Description = null;
            // 
            // 
            // 
            this.superTabControl_Main2.ControlBox.MenuBox.Category = null;
            this.superTabControl_Main2.ControlBox.MenuBox.Description = null;
            this.superTabControl_Main2.ControlBox.MenuBox.Name = "";
            this.superTabControl_Main2.ControlBox.Name = "";
            this.superTabControl_Main2.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl_Main2.ControlBox.MenuBox,
            this.superTabControl_Main2.ControlBox.CloseBox});
            this.superTabControl_Main2.ControlBox.Visible = false;
            this.superTabControl_Main2.Dock = System.Windows.Forms.DockStyle.Right;
            this.superTabControl_Main2.ForeColor = System.Drawing.Color.Black;
            this.superTabControl_Main2.ItemPadding.Bottom = 4;
            this.superTabControl_Main2.ItemPadding.Left = 4;
            this.superTabControl_Main2.ItemPadding.Right = 4;
            this.superTabControl_Main2.ItemPadding.Top = 4;
            this.superTabControl_Main2.Location = new System.Drawing.Point(689, 0);
            this.superTabControl_Main2.Name = "superTabControl_Main2";
            this.superTabControl_Main2.ReorderTabsEnabled = true;
            this.superTabControl_Main2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.superTabControl_Main2.SelectedTabFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.superTabControl_Main2.SelectedTabIndex = -1;
            this.superTabControl_Main2.Size = new System.Drawing.Size(583, 44);
            this.superTabControl_Main2.TabFont = new System.Drawing.Font("Tahoma", 8F);
            this.superTabControl_Main2.TabIndex = 11;
            this.superTabControl_Main2.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonShowKiewd,
            this.labelItem1,
            this.Button_First,
            this.Button_Prev,
            this.TextBox_Index,
            this.Label_Count,
            this.lable_Records,
            this.Button_Next,
            this.Button_Last});
            superTabLinearGradientColorTable11.Colors = new System.Drawing.Color[] {
        System.Drawing.Color.White};
            superTabColorTable3.Background = superTabLinearGradientColorTable11;
            this.superTabControl_Main2.TabStripColor = superTabColorTable3;
            this.superTabControl_Main2.TabStyle = DevComponents.DotNetBar.eSuperTabStyle.WinMediaPlayer12;
            this.superTabControl_Main2.Text = "superTabControl1";
            this.superTabControl_Main2.TextAlignment = DevComponents.DotNetBar.eItemAlignment.Center;
            // 
            // buttonShowKiewd
            // 
            this.buttonShowKiewd.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonShowKiewd.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonShowKiewd.Name = "buttonShowKiewd";
            this.buttonShowKiewd.SplitButton = true;
            this.buttonShowKiewd.Stretch = true;
            this.buttonShowKiewd.Symbol = "";
            this.buttonShowKiewd.SymbolSize = 15F;
            this.buttonShowKiewd.Text = "القيود";
            this.buttonShowKiewd.Visible = false;
            this.buttonShowKiewd.Click += new System.EventHandler(this.buttonItem1_Click);
            // 
            // labelItem1
            // 
            this.labelItem1.Name = "labelItem1";
            this.labelItem1.Width = 2;
            // 
            // Button_First
            // 
            this.Button_First.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_First.FontBold = true;
            this.Button_First.FontItalic = true;
            this.Button_First.ForeColor = System.Drawing.Color.SteelBlue;
            this.Button_First.Image = ((System.Drawing.Image)(resources.GetObject("Button_First.Image")));
            this.Button_First.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.Button_First.ImagePaddingHorizontal = 15;
            this.Button_First.ImagePaddingVertical = 11;
            this.Button_First.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_First.Name = "Button_First";
            this.Button_First.SplitButton = true;
            this.Button_First.Stretch = true;
            this.Button_First.SubItemsExpandWidth = 14;
            this.Button_First.Symbol = "";
            this.Button_First.SymbolSize = 15F;
            this.Button_First.Text = "الأول";
            this.Button_First.Tooltip = "السجل الاول";
            // 
            // Button_Prev
            // 
            this.Button_Prev.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_Prev.FontBold = true;
            this.Button_Prev.FontItalic = true;
            this.Button_Prev.ForeColor = System.Drawing.Color.SteelBlue;
            this.Button_Prev.Image = ((System.Drawing.Image)(resources.GetObject("Button_Prev.Image")));
            this.Button_Prev.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.Button_Prev.ImagePaddingHorizontal = 15;
            this.Button_Prev.ImagePaddingVertical = 11;
            this.Button_Prev.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_Prev.Name = "Button_Prev";
            this.Button_Prev.SplitButton = true;
            this.Button_Prev.Stretch = true;
            this.Button_Prev.SubItemsExpandWidth = 14;
            this.Button_Prev.Symbol = "";
            this.Button_Prev.SymbolSize = 15F;
            this.Button_Prev.Text = "السابق";
            this.Button_Prev.Tooltip = "السجل السابق";
            // 
            // TextBox_Index
            // 
            this.TextBox_Index.Name = "TextBox_Index";
            this.TextBox_Index.TextBoxWidth = 45;
            this.TextBox_Index.Visible = false;
            this.TextBox_Index.WatermarkColor = System.Drawing.SystemColors.GrayText;
            // 
            // Label_Count
            // 
            this.Label_Count.Name = "Label_Count";
            this.Label_Count.Visible = false;
            this.Label_Count.Width = 35;
            // 
            // lable_Records
            // 
            this.lable_Records.BackColor = System.Drawing.Color.SteelBlue;
            this.lable_Records.ForeColor = System.Drawing.Color.White;
            this.lable_Records.Name = "lable_Records";
            this.lable_Records.Text = "---";
            // 
            // Button_Next
            // 
            this.Button_Next.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_Next.FontBold = true;
            this.Button_Next.FontItalic = true;
            this.Button_Next.ForeColor = System.Drawing.Color.SteelBlue;
            this.Button_Next.Image = ((System.Drawing.Image)(resources.GetObject("Button_Next.Image")));
            this.Button_Next.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.Button_Next.ImagePaddingHorizontal = 15;
            this.Button_Next.ImagePaddingVertical = 11;
            this.Button_Next.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_Next.Name = "Button_Next";
            this.Button_Next.SplitButton = true;
            this.Button_Next.Stretch = true;
            this.Button_Next.SubItemsExpandWidth = 14;
            this.Button_Next.Symbol = "";
            this.Button_Next.SymbolSize = 15F;
            this.Button_Next.Text = "التالي";
            this.Button_Next.Tooltip = " السجل التالي";
            this.Button_Next.Click += new System.EventHandler(this.Button_Next_Click_2);
            // 
            // Button_Last
            // 
            this.Button_Last.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Button_Last.FontBold = true;
            this.Button_Last.FontItalic = true;
            this.Button_Last.ForeColor = System.Drawing.Color.SteelBlue;
            this.Button_Last.Image = ((System.Drawing.Image)(resources.GetObject("Button_Last.Image")));
            this.Button_Last.ImageFixedSize = new System.Drawing.Size(28, 28);
            this.Button_Last.ImagePaddingHorizontal = 15;
            this.Button_Last.ImagePaddingVertical = 11;
            this.Button_Last.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Button_Last.Name = "Button_Last";
            this.Button_Last.SplitButton = true;
            this.Button_Last.Stretch = true;
            this.Button_Last.SubItemsExpandWidth = 14;
            this.Button_Last.Symbol = "";
            this.Button_Last.SymbolSize = 15F;
            this.Button_Last.Text = "الأخير";
            this.Button_Last.Tooltip = " السجل الاخير";
            // 
            // expandableSplitter1
            // 
            this.expandableSplitter1.BackColor = System.Drawing.Color.Black;
            this.expandableSplitter1.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(147)))), ((int)(((byte)(207)))));
            this.expandableSplitter1.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.None;
            this.expandableSplitter1.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.None;
            this.expandableSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.expandableSplitter1.ExpandableControl = this.panelEx2;
            this.expandableSplitter1.ExpandFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(45)))), ((int)(((byte)(150)))));
            this.expandableSplitter1.ExpandFillColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandableSplitter1.ExpandLineColor = System.Drawing.SystemColors.ControlText;
            this.expandableSplitter1.ExpandLineColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.expandableSplitter1.ForeColor = System.Drawing.Color.Black;
            this.expandableSplitter1.GripDarkColor = System.Drawing.SystemColors.ControlText;
            this.expandableSplitter1.GripDarkColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.expandableSplitter1.GripLightColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.expandableSplitter1.GripLightColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.expandableSplitter1.HotBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(142)))), ((int)(((byte)(75)))));
            this.expandableSplitter1.HotBackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(207)))), ((int)(((byte)(139)))));
            this.expandableSplitter1.HotBackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemPressedBackground2;
            this.expandableSplitter1.HotBackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemPressedBackground;
            this.expandableSplitter1.HotExpandFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(45)))), ((int)(((byte)(150)))));
            this.expandableSplitter1.HotExpandFillColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandableSplitter1.HotExpandLineColor = System.Drawing.SystemColors.ControlText;
            this.expandableSplitter1.HotExpandLineColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.expandableSplitter1.HotGripDarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(45)))), ((int)(((byte)(150)))));
            this.expandableSplitter1.HotGripDarkColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandableSplitter1.HotGripLightColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.expandableSplitter1.HotGripLightColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.expandableSplitter1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.expandableSplitter1.Location = new System.Drawing.Point(1161, 0);
            this.expandableSplitter1.Name = "expandableSplitter1";
            this.expandableSplitter1.Size = new System.Drawing.Size(14, 284);
            this.expandableSplitter1.TabIndex = 1;
            this.expandableSplitter1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panelEx3);
            this.panel1.Controls.Add(this.expandableSplitter1);
            this.panel1.Controls.Add(this.panelEx2);
            this.panel1.Location = new System.Drawing.Point(103, 273);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1175, 284);
            this.panel1.TabIndex = 877;
            // 
            // button_opendraft
            // 
            this.button_opendraft.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_opendraft.Checked = true;
            this.button_opendraft.ColorTable = DevComponents.DotNetBar.eButtonColor.Office2007WithBackground;
            this.button_opendraft.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button_opendraft.Location = new System.Drawing.Point(1031, 3);
            this.button_opendraft.Name = "button_opendraft";
            this.button_opendraft.Size = new System.Drawing.Size(113, 24);
            this.button_opendraft.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_opendraft.TabIndex = 1237;
            this.button_opendraft.Text = "الفواتير المعلقة";
            this.button_opendraft.Click += new System.EventHandler(this.button_opendraft_Click);
            // 
            // button_Draft
            // 
            this.button_Draft.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Draft.Checked = true;
            this.button_Draft.ColorTable = DevComponents.DotNetBar.eButtonColor.Office2007WithBackground;
            this.button_Draft.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button_Draft.Location = new System.Drawing.Point(1150, 3);
            this.button_Draft.Name = "button_Draft";
            this.button_Draft.Size = new System.Drawing.Size(113, 24);
            this.button_Draft.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Draft.TabIndex = 1236;
            this.button_Draft.Text = "تعليق الفاتورة";
            this.button_Draft.Click += new System.EventHandler(this.button_Draft_click);
            // 
            // prnt_prev
            // 
            this.prnt_prev.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.prnt_prev.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.prnt_prev.ClientSize = new System.Drawing.Size(400, 300);
            this.prnt_prev.Document = this.prnt_doc;
            this.prnt_prev.Enabled = true;
            this.prnt_prev.Icon = ((System.Drawing.Icon)(resources.GetObject("prnt_prev.Icon")));
            this.prnt_prev.Name = "prnt_prev";
            this.prnt_prev.Visible = false;
            // 
            // prnt_doc
            // 
            this.prnt_doc.BeginPrint += new System.Drawing.Printing.PrintEventHandler(this.prnt_doc_BeginPrint);
            this.prnt_doc.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.prnt_doc_PrintPage);
            // 
            // controlContainerItem1
            // 
            this.controlContainerItem1.AllowItemResize = true;
            this.controlContainerItem1.MenuVisibility = DevComponents.DotNetBar.eMenuVisibility.VisibleAlways;
            this.controlContainerItem1.Name = "controlContainerItem1";
            // 
            // prnt_doc2
            // 
            this.prnt_doc2.BeginPrint += new System.Drawing.Printing.PrintEventHandler(this.prnt_doc2_BeginPrint);
            this.prnt_doc2.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.prnt_doc2_PrintPage);
            // 
            // printDialog1
            // 
            this.printDialog1.AllowSelection = true;
            this.printDialog1.AllowSomePages = true;
            this.printDialog1.Document = this.prnt_doc;
            this.printDialog1.UseEXDialog = true;
            // 
            // FlxInvToCopy
            // 
            this.FlxInvToCopy.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.FlxInvToCopy.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.FlxInvToCopy.ColumnInfo = resources.GetString("FlxInvToCopy.ColumnInfo");
            this.FlxInvToCopy.ExtendLastCol = true;
            this.FlxInvToCopy.Font = new System.Drawing.Font("Tahoma", 8F);
            this.FlxInvToCopy.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.None;
            this.FlxInvToCopy.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
            this.FlxInvToCopy.Location = new System.Drawing.Point(6, 152);
            this.FlxInvToCopy.Name = "FlxInvToCopy";
            this.FlxInvToCopy.Rows.Count = 1;
            this.FlxInvToCopy.Rows.DefaultSize = 19;
            this.FlxInvToCopy.ShowSortPosition = C1.Win.C1FlexGrid.ShowSortPositionEnum.None;
            this.FlxInvToCopy.Size = new System.Drawing.Size(813, 117);
            this.FlxInvToCopy.StyleInfo = resources.GetString("FlxInvToCopy.StyleInfo");
            this.FlxInvToCopy.TabIndex = 1219;
            this.FlxInvToCopy.Visible = false;
            this.FlxInvToCopy.VisualStyle = C1.Win.C1FlexGrid.VisualStyle.System;
            // 
            // CarPanelDet
            // 
            this.CarPanelDet.Controls.Add(this.doubleInput_Rate);
            this.CarPanelDet.Controls.Add(this.CmbCurr);
            this.CarPanelDet.Controls.Add(this.txtDueAmount);
            this.CarPanelDet.Controls.Add(this.label3);
            this.CarPanelDet.Controls.Add(this.txtTotalAmLoc);
            this.CarPanelDet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CarPanelDet.Location = new System.Drawing.Point(0, 0);
            this.CarPanelDet.Name = "CarPanelDet";
            this.CarPanelDet.Size = new System.Drawing.Size(1272, 143);
            this.CarPanelDet.TabIndex = 1093;
            this.CarPanelDet.Paint += new System.Windows.Forms.PaintEventHandler(this.CarPanelDet_Paint);
            // 
            // txtTotalAmLoc
            // 
            this.txtTotalAmLoc.AllowEmptyState = false;
            // 
            // 
            // 
            this.txtTotalAmLoc.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtTotalAmLoc.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTotalAmLoc.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtTotalAmLoc.DisplayFormat = "0.00";
            this.txtTotalAmLoc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtTotalAmLoc.Increment = 0D;
            this.txtTotalAmLoc.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.txtTotalAmLoc.IsInputReadOnly = true;
            this.txtTotalAmLoc.Location = new System.Drawing.Point(43, 111);
            this.txtTotalAmLoc.Name = "txtTotalAmLoc";
            this.txtTotalAmLoc.Size = new System.Drawing.Size(63, 21);
            this.txtTotalAmLoc.TabIndex = 1095;
            this.txtTotalAmLoc.Visible = false;
            // 
            // InvDetailsPanel
            // 
            this.InvDetailsPanel.Controls.Add(this.CarPanelDet);
            this.InvDetailsPanel.Controls.Add(this.FlxInv);
            this.InvDetailsPanel.Controls.Add(this.FlxDat);
            this.InvDetailsPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.InvDetailsPanel.Location = new System.Drawing.Point(3, 203);
            this.InvDetailsPanel.Name = "InvDetailsPanel";
            this.InvDetailsPanel.Size = new System.Drawing.Size(1272, 143);
            this.InvDetailsPanel.TabIndex = 1218;
            // 
            // TableLayOutOFKewd
            // 
            this.TableLayOutOFKewd.BackColor = System.Drawing.SystemColors.Control;
            this.TableLayOutOFKewd.ColumnCount = 1;
            this.TableLayOutOFKewd.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayOutOFKewd.Controls.Add(this.superTabControl_Info, 0, 1);
            this.TableLayOutOFKewd.Controls.Add(this.kiewadbuttonspanel, 0, 0);
            this.TableLayOutOFKewd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayOutOFKewd.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.AddColumns;
            this.TableLayOutOFKewd.Location = new System.Drawing.Point(3, 352);
            this.TableLayOutOFKewd.Name = "TableLayOutOFKewd";
            this.TableLayOutOFKewd.RowCount = 2;
            this.TableLayOutOFKewd.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.TableLayOutOFKewd.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayOutOFKewd.Size = new System.Drawing.Size(1272, 152);
            this.TableLayOutOFKewd.TabIndex = 1216;
            // 
            // kiewadbuttonspanel
            // 
            this.kiewadbuttonspanel.Controls.Add(this.button_Draft);
            this.kiewadbuttonspanel.Controls.Add(this.button_opendraft);
            this.kiewadbuttonspanel.Controls.Add(this.buttonItem_POSReturn);
            this.kiewadbuttonspanel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.kiewadbuttonspanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kiewadbuttonspanel.Location = new System.Drawing.Point(3, 3);
            this.kiewadbuttonspanel.Name = "kiewadbuttonspanel";
            this.kiewadbuttonspanel.Size = new System.Drawing.Size(1266, 29);
            this.kiewadbuttonspanel.TabIndex = 1087;
            // 
            // TableLayoutOFALLControls
            // 
            this.TableLayoutOFALLControls.ColumnCount = 1;
            this.TableLayoutOFALLControls.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutOFALLControls.Controls.Add(this.TableLayOutOFKewd, 0, 2);
            this.TableLayoutOFALLControls.Controls.Add(this.ribbonBar_Tasks, 0, 3);
            this.TableLayoutOFALLControls.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.TableLayoutOFALLControls.Controls.Add(this.InvDetailsPanel, 0, 1);
            this.TableLayoutOFALLControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutOFALLControls.Location = new System.Drawing.Point(0, 0);
            this.TableLayoutOFALLControls.Name = "TableLayoutOFALLControls";
            this.TableLayoutOFALLControls.RowCount = 4;
            this.TableLayoutOFALLControls.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.TableLayoutOFALLControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.5342F));
            this.TableLayoutOFALLControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.4658F));
            this.TableLayoutOFALLControls.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.TableLayoutOFALLControls.Size = new System.Drawing.Size(1278, 557);
            this.TableLayoutOFALLControls.TabIndex = 1080;
            // 
            // FrmInvSaleCar
            // 
            this.ClientSize = new System.Drawing.Size(1278, 557);
            this.Controls.Add(this.TableLayoutOFALLControls);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.FlxInvToCopy);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = global::InvAcc.Properties.Resources.favicon;
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(834, 505);
            this.Name = "FrmInvSaleCar";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فاتورة مبيعات";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmInvSale_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmInvSale_FormClosed);
            this.Load += new System.EventHandler(this.FrmInvSale_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Frm_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Frm_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FrmInvSale_KeyUp);
            this.ribbonBar1.ResumeLayout(false);
            this.ribbonBar1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FlxPrice)).EndInit();
            this.panelBalance.ResumeLayout(false);
            this.panelBalance.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FlxSerial)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.superTabStrip_ORders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInvCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCustNet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCustRep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtDiscountVal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotTax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Credit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Cash)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_NetWord)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiscoundPointsLoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiscoundPoints)).EndInit();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDueAmountLoc)).EndInit();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotTaxLoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalAm)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MndobCommValue)).EndInit();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            this.splitContainer5.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            this.splitContainer6.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel1.PerformLayout();
            this.splitContainer7.Panel2.ResumeLayout(false);
            this.splitContainer7.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel2.ResumeLayout(false);
            this.splitContainer8.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.splitContainer9.Panel1.ResumeLayout(false);
            this.splitContainer9.Panel1.PerformLayout();
            this.splitContainer9.Panel2.ResumeLayout(false);
            this.splitContainer9.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer13.Panel1.ResumeLayout(false);
            this.splitContainer13.Panel2.ResumeLayout(false);
            this.splitContainer13.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.Detials_CarPanel.ResumeLayout(false);
            this.Detials_CarPanel.PerformLayout();
            this.splitContainer11.Panel1.ResumeLayout(false);
            this.splitContainer11.Panel1.PerformLayout();
            this.splitContainer11.Panel2.ResumeLayout(false);
            this.splitContainer11.ResumeLayout(false);
            this.splitContainer12.Panel1.ResumeLayout(false);
            this.splitContainer12.Panel1.PerformLayout();
            this.splitContainer12.Panel2.ResumeLayout(false);
            this.splitContainer12.Panel2.PerformLayout();
            this.splitContainer12.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            this.splitContainer14.Panel1.ResumeLayout(false);
            this.splitContainer14.Panel2.ResumeLayout(false);
            this.splitContainer14.ResumeLayout(false);
            this.splitContainer15.Panel1.ResumeLayout(false);
            this.splitContainer15.Panel1.PerformLayout();
            this.splitContainer15.Panel2.ResumeLayout(false);
            this.splitContainer15.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtDiscountValLoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiscountP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_Rate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDueAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FlxDat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FlxInv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_Info)).EndInit();
            this.superTabControl_Info.ResumeLayout(false);
            this.superTabControlPanel3.ResumeLayout(false);
            this.superTabControlPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FlxStkQty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ItemDet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPointCount)).EndInit();
            this.superTabControlPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_CostSts)).EndInit();
            this.superTabControl_CostSts.ResumeLayout(false);
            this.superTabControlPanel11.ResumeLayout(false);
            this.superTabControlPanel11.PerformLayout();
            this.panelBalanceBottom.ResumeLayout(false);
            this.panelBalanceBottom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_NetWorkLoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaymentLoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_CreditLoc)).EndInit();
            this.superTabControlPanel7.ResumeLayout(false);
            this.superTabControlPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotDis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotDisLoc)).EndInit();
            this.superTabControlPanel6.ResumeLayout(false);
            this.superTabControlPanel6.PerformLayout();
            this.superTabControlPanel8.ResumeLayout(false);
            this.superTabControlPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotBankComm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotBankCommLoc)).EndInit();
            this.superTabControlPanel10.ResumeLayout(false);
            this.superTabControlPanel10.PerformLayout();
            this.superTabControlPanel2.ResumeLayout(false);
            this.superTabControlPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSteel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_LostOrWin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalQ)).EndInit();
            this.superTabControlPanel4.ResumeLayout(false);
            this.superTabControlPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtAllExchanged)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            this.panelEx3.ResumeLayout(false);
            this.ribbonBar_DGV.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_DGV)).EndInit();
            this.panelEx2.ResumeLayout(false);
            this.ribbonBar_Tasks.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_Main1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_Main2)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.FlxInvToCopy)).EndInit();
            this.CarPanelDet.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalAmLoc)).EndInit();
            this.InvDetailsPanel.ResumeLayout(false);
            this.TableLayOutOFKewd.ResumeLayout(false);
            this.kiewadbuttonspanel.ResumeLayout(false);
            this.TableLayoutOFALLControls.ResumeLayout(false);
            this.ResumeLayout(false);

        }//###########&&&&&&&&&&

}
}
