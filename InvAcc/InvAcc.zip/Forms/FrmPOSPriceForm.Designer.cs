namespace InvAcc.Forms
{
    partial class FrmPOSPriceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.button_Unit2 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.button_Close = new DevComponents.DotNetBar.ButtonX();
            this.button_Unit1 = new DevComponents.DotNetBar.ButtonX();
            this.Tot_Text = new DevComponents.Editors.DoubleInput();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4E = new System.Windows.Forms.Label();
            this.label5E = new System.Windows.Forms.Label();
            this.button_Unit5 = new DevComponents.DotNetBar.ButtonX();
            this.button_Unit4 = new DevComponents.DotNetBar.ButtonX();
            this.groupPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Tot_Text)).BeginInit();
            this.SuspendLayout();
            // 
            // groupPanel1
            // 
            this.groupPanel1.BackColor = System.Drawing.Color.AliceBlue;
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.button_Unit2);
            this.groupPanel1.Controls.Add(this.button_Unit4);
            this.groupPanel1.Controls.Add(this.button_Unit5);
            this.groupPanel1.Controls.Add(this.label5E);
            this.groupPanel1.Controls.Add(this.label4E);
            this.groupPanel1.Controls.Add(this.label5);
            this.groupPanel1.Controls.Add(this.label4);
            this.groupPanel1.Controls.Add(this.buttonX1);
            this.groupPanel1.Controls.Add(this.button_Close);
            this.groupPanel1.Controls.Add(this.label3);
            this.groupPanel1.Controls.Add(this.button_Unit1);
            this.groupPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupPanel1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.groupPanel1.Location = new System.Drawing.Point(0, 0);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(400, 171);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1.TabIndex = 1;
            this.groupPanel1.Text = "السعر - Price";
            this.groupPanel1.Click += new System.EventHandler(this.groupPanel1_Click);
            // 
            // button_Unit2
            // 
            this.button_Unit2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Unit2.Checked = true;
            this.button_Unit2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_Unit2.Location = new System.Drawing.Point(27, 17);
            this.button_Unit2.Name = "button_Unit2";
            this.button_Unit2.Size = new System.Drawing.Size(39, 48);
            this.button_Unit2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Unit2.Symbol = "";
            this.button_Unit2.TabIndex = 1174;
            this.button_Unit2.Click += new System.EventHandler(this.button_Unit2_Click);
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.buttonX1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.buttonX1.Location = new System.Drawing.Point(-2, 106);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(186, 45);
            this.buttonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1.Symbol = "";
            this.buttonX1.SymbolSize = 18F;
            this.buttonX1.TabIndex = 1162;
            this.buttonX1.Text = "تــــراجــــــع";
            this.buttonX1.TextColor = System.Drawing.Color.White;
            this.buttonX1.Click += new System.EventHandler(this.buttonX1_Click);
            // 
            // button_Close
            // 
            this.button_Close.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Close.ColorTable = DevComponents.DotNetBar.eButtonColor.Office2007WithBackground;
            this.button_Close.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.button_Close.Location = new System.Drawing.Point(190, 106);
            this.button_Close.Name = "button_Close";
            this.button_Close.Size = new System.Drawing.Size(201, 45);
            this.button_Close.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Close.Symbol = "";
            this.button_Close.SymbolSize = 18F;
            this.button_Close.TabIndex = 1162;
            this.button_Close.Text = "موافق";
            this.button_Close.TextColor = System.Drawing.Color.White;
            this.button_Close.Click += new System.EventHandler(this.button_Close_Click);
            // 
            // button_Unit1
            // 
            this.button_Unit1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Unit1.Checked = true;
            this.button_Unit1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_Unit1.Location = new System.Drawing.Point(326, 17);
            this.button_Unit1.Name = "button_Unit1";
            this.button_Unit1.Size = new System.Drawing.Size(39, 48);
            this.button_Unit1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Unit1.Symbol = "";
            this.button_Unit1.TabIndex = 1170;
            this.button_Unit1.Click += new System.EventHandler(this.button_Unit1_Click);
            // 
            // Tot_Text
            // 
            this.Tot_Text.AllowEmptyState = false;
            // 
            // 
            // 
            this.Tot_Text.BackgroundStyle.Class = "DateTimeInputBackground";
            this.Tot_Text.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Tot_Text.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.Tot_Text.DisplayFormat = "0.00";
            this.Tot_Text.Font = new System.Drawing.Font("Tahoma", 20F, System.Drawing.FontStyle.Bold);
            this.Tot_Text.Increment = 0D;
            this.Tot_Text.InputHorizontalAlignment = DevComponents.Editors.eHorizontalAlignment.Center;
            this.Tot_Text.Location = new System.Drawing.Point(75, 41);
            this.Tot_Text.MinValue = 0D;
            this.Tot_Text.Name = "Tot_Text";
            this.Tot_Text.Size = new System.Drawing.Size(248, 40);
            this.Tot_Text.TabIndex = 1143;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(205, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 48);
            this.label3.TabIndex = 1161;
            this.label3.Text = "كبـــير";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(205, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 48);
            this.label4.TabIndex = 1163;
            this.label4.Text = "وســـط";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(205, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 48);
            this.label5.TabIndex = 1164;
            this.label5.Text = "كبـــير";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4E
            // 
            this.label4E.BackColor = System.Drawing.Color.Transparent;
            this.label4E.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label4E.ForeColor = System.Drawing.Color.Black;
            this.label4E.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4E.Location = new System.Drawing.Point(12, 185);
            this.label4E.Name = "label4E";
            this.label4E.Size = new System.Drawing.Size(82, 48);
            this.label4E.TabIndex = 1168;
            this.label4E.Text = "وســـط";
            this.label4E.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5E
            // 
            this.label5E.BackColor = System.Drawing.Color.Transparent;
            this.label5E.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label5E.ForeColor = System.Drawing.Color.Black;
            this.label5E.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5E.Location = new System.Drawing.Point(12, 241);
            this.label5E.Name = "label5E";
            this.label5E.Size = new System.Drawing.Size(82, 48);
            this.label5E.TabIndex = 1169;
            this.label5E.Text = "كبـــير";
            this.label5E.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_Unit5
            // 
            this.button_Unit5.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Unit5.Checked = true;
            this.button_Unit5.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_Unit5.Location = new System.Drawing.Point(100, 241);
            this.button_Unit5.Name = "button_Unit5";
            this.button_Unit5.Size = new System.Drawing.Size(100, 48);
            this.button_Unit5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Unit5.Symbol = "";
            this.button_Unit5.TabIndex = 1171;
            // 
            // button_Unit4
            // 
            this.button_Unit4.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.button_Unit4.Checked = true;
            this.button_Unit4.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.button_Unit4.Location = new System.Drawing.Point(100, 185);
            this.button_Unit4.Name = "button_Unit4";
            this.button_Unit4.Size = new System.Drawing.Size(100, 48);
            this.button_Unit4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.button_Unit4.Symbol = "";
            this.button_Unit4.TabIndex = 1172;
            // 
            // FrmPOSPriceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 171);
            this.Controls.Add(this.Tot_Text);
            this.Controls.Add(this.groupPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmPOSPriceForm";
            this.Text = "FrmPOSPriceForm";
            this.Load += new System.EventHandler(this.FrmPOSPriceForm_Load);
            this.groupPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Tot_Text)).EndInit();
            this.Icon = ((System.Drawing.Icon)(InvAcc.Properties.Resources.favicon));
this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1;
        private DevComponents.DotNetBar.ButtonX button_Unit2;
        private DevComponents.DotNetBar.ButtonX button_Close;
        private DevComponents.DotNetBar.ButtonX button_Unit1;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private DevComponents.Editors.DoubleInput Tot_Text;
        private DevComponents.DotNetBar.ButtonX button_Unit4;
        private DevComponents.DotNetBar.ButtonX button_Unit5;
        protected System.Windows.Forms.Label label5E;
        protected System.Windows.Forms.Label label4E;
        protected System.Windows.Forms.Label label5;
        protected System.Windows.Forms.Label label4;
        protected System.Windows.Forms.Label label3;
    }
}